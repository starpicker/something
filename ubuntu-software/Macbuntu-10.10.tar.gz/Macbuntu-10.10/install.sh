#!/bin/bash

# Macbuntu - Mac OS X Transformation Pack
# Author: lookout, elmigueluno
# Send feedback to lookout@losoft.org, elmigueluno@gmail.com
# Homepage: http://www.losoft.org/macbuntu/
# 
# Copyright (c) 2010 Jan Komadowski
# 
# This program is free software. Feel free to redistribute and/or
# modify it under the terms of the GNU General Public License v3
# as published by the Free Software Foundation.
# This program is distributed in the hope that it will be useful
# but comes WITHOUT ANY WARRANTY; without even the implied warranty
# of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
# 
# See the GNU General Public License for more details.

UBUVER="10.10"
UBUNTU="Ubuntu $UBUVER"

MACBUNTU="Macbuntu-$UBUVER"
VERSION="2.3"

MACBUNTUHOME="$HOME/.macbuntu"

CURRENT="$MACBUNTUHOME/$UBUVER-$VERSION"
BACKUP="$MACBUNTUHOME/backup"
BACKUPDIR="$BACKUP/$(date +%Y-%m-%d-%H:%M)"
BACKUPCURRENT="$BACKUP/current"

COMPIZPID=$(ps -o pid= -C compiz)
DOCKYPID=$(ps -o pid= -C docky)
CAIROPID=$(ps -o pid= -C cairo-dock)
AWNPID=$(ps -o pid= -C avant-window-navigator)

RESOLUTION=$(xdpyinfo | grep -i dimensions: | sed 's/[^0-9]*pixels.*(.*).*//' | sed 's/[^0-9x]*//')
VRES=$(echo $RESOLUTION | sed 's/.*x//')
HRES=$(echo $RESOLUTION | sed 's/x.*//')

ARCH=$(uname -m)
ARCHDIR=`[ "$ARCH" == "x86_64" ] && echo "x64" || echo "x32"`

force=$1
tester=0

chk_user()
{
	echo ""
	echo "Checkin script user..."
	if [ $(whoami) = "root" ]
	then
		echo "Failed."
		echo "Root user not allowed, please run this script as a regular user."
		echo "Exiting..."
		exit 1;
	fi
	echo "Passed"
}

chk_root()
{
	echo ""
	echo "Checkin for a root access..."
	s=`sudo cat /etc/issue`
	if [ -n "$s" ]; then
		return
	fi
	echo "Authorization failed."
	echo "Exiting..."
	exit 1;
}

chk_system()
{
	echo ""
	echo "Checking Ubuntu version..."
	s=`cat /etc/issue | grep -i "$UBUNTU"`
	if [ ! -n "$s" ]; then
		echo "Failed. System not supported, script will end here"
		echo "To ignore their compatibility with current OS try ./install.sh force"
		echo "Exiting..."
		exit 1;
	fi
	echo "Passed"
}

chk_program()
{
	s=`dpkg --status $1 | grep -q not-installed`
	if [ ! -n "$s" ]; then
		return 1
	fi
	return 0
}

chk_version()
{
	echo ""
	echo "Checking currently installed version of $MACBUNTU..."
	d=$MACBUNTUHOME/current
	if [ -f "$d" ]; then
		s=`cat $MACBUNTUHOME/current | grep "$UBUVER-$VERSION"`
		if [ -n "$s" ]; then
			echo "You already have the latest versions. Do you want to reinstall components and settings [Y/n]?"
			read ans
			case "$ans" in
				n*|N*)
				echo "Exiting..."
				exit 0;
			esac
		fi
	fi
}

# Changing current to script dir
cd -- "$(dirname -- "$0")"

echo ""
echo "Macbuntu - Mac OS X Transformation Pack"
echo "The Macbuntu installation script automatically installs and configures"
echo "all necessary system components to mimic Mac OS X appearance on Ubuntu Linux"
echo ""
echo "$MACBUNTU v$VERSION"
echo ""
echo "Include"
echo " * Paw-OSX and Paw-Ubuntu Plymouth themes"
echo " * Macbuntu sound theme"
echo " * Macbuntu GTK theme based on GTK Leopard"
echo " * Macbuntu-Icons based on Mac4Lin and Faenza Icons"
echo " * Macbuntu-Cursors based on Shere Khan X"
echo " * Mac OS X backgrounds"
echo " * Mac OS X fonts"
echo ""
echo "Installation"
echo " * Compiz Extras"
echo " * Application Menu"
echo " * Docky"
echo " * Ubuntu-Tweak"
echo " * Cheese"
echo ""
echo "Configuration"
echo " * Login screen"
echo " * Metacity"
echo " * Compiz effects"
echo " * Window theme"
echo " * Backgrounds"
echo " * Cursors"
echo " * Icons"
echo " * Top panel"
echo ""
echo "Attention!"
echo "Script significantly changes the desktop."
echo "Not compatible with Ubuntu Netbook Edition."
echo "If a previous version of $MACBUNTU is installed it will be overwritten."

case "$force" in
	--force|force) ;;
	*) chk_system ;;
esac

chk_user
chk_version

echo ""
echo "This script will install and enable $MACBUNTU now"
echo "You must have root privileges to be able to install listed components."
echo ""
echo "Attention!"
echo "Running scripts with root privileges is dangerous, if you do not trust the software"
echo "or you are unsure about the origin of this software, please abort (Control+C)."
echo "Macbuntu guarantee the safe code only if the application comes from this address"
echo "https://sourceforge.net/projects/macbuntu/"
echo ""
echo "Do you want to continue [Y/n]?"
read ans
case "$ans" in
	n*|N*)
	echo "Installation aborted. Exiting..."
	exit 0;
esac

chk_root

if [ $tester == 0 ] ; then

echo ""
echo "Preparing backup..."
if [ ! -f "$CURRENT" ]; then
	mkdir -p "$CURRENT"
fi
if [ ! -f "$BACKUPDIR" ]; then
	mkdir -p "$BACKUPDIR"
fi
if [ ! -f "$BACKUPCURRENT" ]; then
	mkdir -p "$BACKUPCURRENT"
fi

rm -rf $CURRENT/*
rm -rf $BACKUPCURRENT/*

cp -r * $CURRENT

# Questions section
echo ""
echo "Please, take a breath and answer a few questions"
echo ""
echo "- Which font you want to install, otherwise a default (*) one will be selected?"
echo "* 1. Do nothing, I want to do it myself"
echo "  2. Latin"
echo "  3. Chinese"
read lgfont
case $lgfont in
	2*) ;;
	3*) ;;
	*) lgfont=1 ;;
esac

echo "- Which distributor logo you want to install, otherwise a default (*) one will be selected?"
echo "  1. Mac - small"
echo "* 2. Mac - middle"
echo "  3. Mac - big"
echo "  4. Ubuntu"
echo "  5. Gnome"
read dlogo

qwobbly=1
echo "- Do you want to enable wobbly windows [Y/n]?"
read ans
case "$ans" in
	n*|N*) qwobbly=0 ;;
esac

qshowdesktop=1
echo "- Enable left bottom corner to show desktop [Y/n]?"
read ans
case "$ans" in
	n*|N*) qshowdesktop=0 ;;
esac

qshowall=1
echo "- Enable right bottom corner to show all windows [Y/n]?"
read ans
case "$ans" in
	n*|N*) qshowall=0 ;;
esac

# Setup
echo "Setting up repository"
sudo cp -r tools/remove-apt-repository /usr/bin
sudo add-apt-repository ppa:tualatrix/ppa
# sudo add-apt-repository ppa:globalmenu-team/ppa
# sudo add-apt-repository ppa:canonical-dx-team/une
sudo apt-get update

echo ""
echo "Installing backgrounds..."
d=~/.backgrounds/
if [ ! -d "$d" ]; then
	mkdir "$d"
fi

cp -r backgrounds/* ~/.backgrounds/
sudo cp -r backgrounds/* /usr/share/backgrounds/

echo "Installing cursors..."
d=~/.icons/
if [ ! -d "$d" ]; then
	mkdir "$d"
fi
rm -rf ~/.icons/$MACBUNTU-Cursors/
rm -rf ~/.icons/Macbuntu-Cursors/
sudo rm -rf /usr/share/icons/$MACBUNTU-Cursors/
sudo rm -rf /usr/share/icons/Macbuntu-Cursors/
cp -r cursors/Macbuntu-Cursors ~/.icons/Macbuntu-Cursors
sudo cp -r cursors/Macbuntu-Cursors /usr/share/icons/Macbuntu-Cursors

echo "Installing icons..."
rm -rf ~/.icons/$MACBUNTU-Icons/
rm -rf ~/.icons/Macbuntu-Icons/
sudo rm -rf /usr/share/icons/$MACBUNTU-Icons/
sudo rm -rf /usr/share/icons/Macbuntu-Icons/
cp -r icons/Macbuntu-Icons ~/.icons/
sudo rm -f /usr/share/icons/applelogo.tif
sudo rm -f /usr/share/icons/LoginIcons/apps/64/applelogo.tif
sudo cp -r icons/Macbuntu-Icons /usr/share/icons/
sudo cp -r icons/applelogo.png /usr/share/icons/
sudo cp -r icons/applelogo-black.svg /usr/share/icons/
sudo cp -r icons/applelogo.png /usr/share/icons/LoginIcons/apps/64/
sudo cp -r icons/applelogo-black.svg /usr/share/icons/LoginIcons/apps/64/

echo "Installing themes..."
d=~/.themes/
if [ ! -d "$d" ]; then
	mkdir "$d"
fi
rm -rf ~/.themes/$MACBUNTU/
rm -rf ~/.themes/Macbuntu/
sudo rm -rf /usr/share/themes/$MACBUNTU/
sudo rm -rf /usr/share/themes/Macbuntu/
cp -r themes/Macbuntu ~/.themes/Macbuntu
sudo cp -r themes/Macbuntu /usr/share/themes/Macbuntu

echo "Installing new logo..."
case $dlogo in
	1*)
	cp -rf distributor-logo/mac-small/* ~/.icons/Macbuntu-Icons/places/scalable/
	sudo cp -rf distributor-logo/mac-small/* /usr/share/icons/Macbuntu-Icons/places/scalable/
	;;
	3*)
	cp -rf distributor-logo/mac-big/* ~/.icons/Macbuntu-Icons/places/scalable/
	sudo cp -rf distributor-logo/mac-big/* /usr/share/icons/Macbuntu-Icons/places/scalable/
	;;
	4*)
	cp -rf distributor-logo/ubuntu/* ~/.icons/Macbuntu-Icons/places/scalable/
	sudo cp -rf distributor-logo/ubuntu/* /usr/share/icons/Macbuntu-Icons/places/scalable/
	;;
	5*)
	cp -rf distributor-logo/gnome/* ~/.icons/Macbuntu-Icons/places/scalable/
	sudo cp -rf distributor-logo/gnome/* /usr/share/icons/Macbuntu-Icons/places/scalable/
	;;
	*)
	cp -rf distributor-logo/mac-middle/* ~/.icons/Macbuntu-Icons/places/scalable/
	sudo cp -rf distributor-logo/mac-middle/* /usr/share/icons/Macbuntu-Icons/places/scalable/
	;;
esac

# Fonts
if [ ! $lgfont = 1 ]; then
	sudo rm -rf /usr/share/fonts/mac/
	sudo cp -rf fonts/mac/ /usr/share/fonts/
	echo "Installing fonts..."
	case $lgfont in
		3*) sudo cp -rf fonts/gbk/* /usr/share/fonts/mac/ ;;
		*) sudo cp -rf fonts/latin/* /usr/share/fonts/mac/ ;;
	esac
	sudo fc-cache -f -v
	cp -f fonts/.fonts.conf ~/.fonts.conf
fi

# Plymouth theme
echo ""
echo "Installing Plymouth theme..."
sudo cp -r plymouth/Paw-Ubuntu/ /lib/plymouth/themes/
sudo cp -r plymouth/Paw-OSX/ /lib/plymouth/themes/

# Backuping
echo "Backuping..."
mkdir -p $BACKUPDIR/sounds
sudo cp -rf /usr/share/sounds/purple $BACKUPDIR/sounds/
mkdir -p $BACKUPCURRENT/sounds
cp -rf $BACKUPDIR/sounds/* $BACKUPCURRENT/sounds/

# Sound theme
echo "Installing Sound theme..."
sudo cp -rf sounds/macbuntu /usr/share/sounds/
sudo cp -rf sounds/purple /usr/share/sounds/

# Compiz
echo ""
echo "Installing Compiz Extras..."
sudo apt-get install compizconfig-settings-manager compiz-fusion-plugins-main compiz-fusion-plugins-extra fusion-icon

# Application Menu, Docky, Ubuntu-Tweak, Cheese
echo ""
echo "Installing Cheese, Ubuntu-Tweak, Application Menu..."
sudo apt-get install cheese ubuntu-tweak appmenu-gtk libqtgui4 indicator-applet-appmenu indicator-appmenu

# Installing Docky
if [ -z $CAIROPID ] && [ -z $AWNPID ] && [ -z $DOCKYPID ]; then
	echo "Installing Docky..."
	sudo apt-get install docky
fi

if [ ! -z $DOCKYPID ]; then
	killall docky
fi

if [ ! -z $CAIROPID ]; then
	killall cairo-dock
fi

if [ ! -z $AWNPID ]; then
	killall avant-window-navigator
fi

# Backuping
echo "Backuping..."
mkdir -p $BACKUPDIR/docky
gconftool-2 --dump /apps/docky-2 > $BACKUPDIR/docky/docky.entries
mkdir -p $BACKUPCURRENT/docky
cp $BACKUPDIR/docky/* $BACKUPCURRENT/docky/

echo ""
echo "Setting up Docky..."
gconftool-2 --set /apps/docky-2/Docky/Services/ThemeService/Theme --type string "Glass"
gconftool-2 --set /apps/docky-2/Docky/Services/ThemeService/UrgentHue --type int 150
gconftool-2 --set /apps/docky-2/Docky/DockController/Theme --type string "Glass"
gconftool-2 --set /apps/docky-2/Docky/DockController/UrgentHue --type int 150
gconftool-2 --set /apps/docky-2/Docky/Interface/DockPreferences/Dock1/IconSize --type int 48
gconftool-2 --set /apps/docky-2/Docky/Interface/DockPreferences/Dock1/Position --type string "Bottom"
gconftool-2 --set /apps/docky-2/Docky/Interface/DockPreferences/Dock1/IndicateMultipleWindows --type boolean true
gconftool-2 --set /apps/docky-2/Docky/Interface/DockPreferences/Dock1/ThreeDimensional --type boolean true
gconftool-2 --set /apps/docky-2/Docky/Interface/DockPreferences/Dock1/WindowManager --type boolean true
gconftool-2 --set /apps/docky-2/Docky/Interface/DockPreferences/Dock1/ZoomEnabled --type boolean true
gconftool-2 --set /apps/docky-2/Docky/Interface/DockPreferences/Dock1/ZoomPercent --type float 1.800
gconftool-2 --set /apps/docky-2/Docky/Interface/DockPreferences/Dock1/Plugins --type list --list-type string "[Trash]"
gconftool-2 --set /apps/docky-2/Docky/Interface/DockPreferences/FirstRun --type boolean false

echo "Adding Launchers..."
lnch="file:///usr/share/applications/nautilus.desktop"
sl="/usr/share/applications/nautilus.desktop"
d="/usr/share/applications/firefox.desktop"
if [ -f "$d" ]; then
	sl="$sl,$d"
	lnch="$lnch,file://$d"
fi
d="/usr/share/applications/google-chrome.desktop"
if [ -f "$d" ]; then
	sl="$sl,$d"
	lnch="$lnch,file://$d"
fi
d="/usr/share/applications/chromium-browser.desktop"
if [ -f "$d" ]; then
	sl="$sl,$d"
	lnch="$lnch,file://$d"
fi
d="/usr/share/applications/thunderbird.desktop"
if [ -f "$d" ]; then
	sl="$sl,$d"
	lnch="$lnch,file://$d"
fi
d="/usr/share/applications/evolution.desktop"
if [ -f "$d" ]; then
	sl="$sl,$d"
	lnch="$lnch,file://$d"
fi
d="/usr/share/applications/pidgin.desktop"
if [ -f "$d" ]; then
	sl="$sl,$d"
	lnch="$lnch,file://$d"
fi
d="/usr/share/applications/empathy.desktop"
if [ -f "$d" ]; then
	sl="$sl,$d"
	lnch="$lnch,file://$d"
fi
d="/usr/share/applications/skype.desktop"
if [ -f "$d" ]; then
	sl="$sl,$d"
	lnch="$lnch,file://$d"
fi
d="/usr/share/applications/rhythmbox.desktop"
if [ -f "$d" ]; then
	sl="$sl,$d"
	lnch="$lnch,file://$d"
fi
d="/usr/share/applications/vlc.desktop"
if [ -f "$d" ]; then
	sl="$sl,$d"
	lnch="$lnch,file://$d"
fi
d="/usr/share/applications/cheese.desktop"
if [ -f "$d" ]; then
	sl="$sl,$d"
	lnch="$lnch,file://$d"
fi
d="/usr/share/applications/eog.desktop"
if [ -f "$d" ]; then
	sl="$sl,$d"
	lnch="$lnch,file://$d"
fi
d="/usr/share/applications/f-spot.desktop"
if [ -f "$d" ]; then
	sl="$sl,$d"
	lnch="$lnch,file://$d"
fi
d="/usr/share/applications/gimp.desktop"
if [ -f "$d" ]; then
	sl="$sl,$d"
	lnch="$lnch,file://$d"
fi
d="/usr/share/applications/gnome-screenshot.desktop"
if [ -f "$d" ]; then
	sl="$sl,$d"
	lnch="$lnch,file://$d"
fi
d="/usr/share/applications/simple-scan.desktop"
if [ -f "$d" ]; then
	sl="$sl,$d"
	lnch="$lnch,file://$d"
fi
d="/usr/share/applications/gedit.desktop"
if [ -f "$d" ]; then
	sl="$sl,$d"
	lnch="$lnch,file://$d"
fi
d="/usr/share/applications/gcalctool.desktop"
if [ -f "$d" ]; then
	sl="$sl,$d"
	lnch="$lnch,file://$d"
fi
d="/usr/share/applications/gnome-terminal.desktop"
if [ -f "$d" ]; then
	sl="$sl,$d"
	lnch="$lnch,file://$d"
fi
d="/usr/share/applications/gnomecc.desktop"
if [ -f "$d" ]; then
	sl="$sl,$d"
	lnch="$lnch,file://$d"
fi
lnch="$lnch,file:///usr/share/applications/,TrashCan"
sl="$sl,/usr/share/applications/,TrashCan"
gconftool-2 --set /apps/docky-2/Docky/Interface/DockPreferences/Dock1/Launchers --type list --list-type string "[$lnch]"
gconftool-2 --set /apps/docky-2/Docky/Interface/DockPreferences/Dock1/SortList --type list --list-type string "[$sl]"

# Helpers
echo "Activating Helpers..."
d="/usr/share/applications/rhythmbox.desktop"
if [ -f "$d" ]; then
	gconftool-2 --set /apps/docky-2/Docky/Services/HelperService/rhythmbox_control_py --type boolean true
fi
d="/usr/share/applications/pidgin.desktop"
if [ -f "$d" ]; then
	gconftool-2 --set /apps/docky-2/Docky/Services/HelperService/pidgin_control_py --type boolean true
fi
d="/usr/share/applications/deluge.desktop"
if [ -f "$d" ]; then
	gconftool-2 --set /apps/docky-2/Docky/Services/HelperService/deluge_badge_py --type boolean true
fi
d="/usr/share/applications/skype.desktop"
if [ -f "$d" ]; then
	gconftool-2 --set /apps/docky-2/Docky/Services/HelperService/skype_control_py --type boolean true
fi

# Metacity
gconftool-2 --set /apps/gwd/metacity_theme_opacity --type float 1

# Disable Compiz
if [ ! -z $COMPIZPID ]; then
	nohup metacity --replace > /dev/null &
fi

# Backuping
echo "Backuping..."
mkdir -p $BACKUPDIR/compiz
cp -f /usr/lib/compiz/libanimation.so $BACKUPDIR/compiz/
cp -f /usr/share/compiz/animation.xml $BACKUPDIR/compiz/
gconftool-2 --dump /apps/compiz > $BACKUPDIR/compiz/compiz.entries
mkdir -p $BACKUPCURRENT/compiz
cp $BACKUPDIR/compiz/* $BACKUPCURRENT/compiz/

echo "Setting up Compiz Fusion..."
# General
# Active Plugins
sl="core,ccp,move,resize,place,decoration,commands,mousepoll,svg,text,session,gnomecompat,workarounds,dbus"
sl="$sl,png,regex,vpswitch,imgjpeg,animation,scale,shift,expo,showdesktop,cube,rotate,3d,fade,ezoom,switcher"
if [ $qwobbly = 1 ]; then
	sl="$sl,wobbly"
fi
s=`gconftool-2 --get /apps/compiz/general/allscreens/options/active_plugins | grep widget`
if [ -n "$s" ]; then
	sl="$sl,widget"
fi
gconftool-2 --set /apps/compiz/general/allscreens/options/active_plugins --type list --list-type string "[$sl]"
gconftool-2 --set /apps/compiz/general/allscreens/options/cursor_theme --type string "Macbuntu-Cursors"
# Animation
# Minimize a window like OS-X
sudo cp -f compiz/$ARCHDIR/libanimation.so /usr/lib/compiz/
sudo cp -f compiz/$ARCHDIR/animation.xml /usr/share/compiz/
# Animation settings
gconftool-2 --set /apps/compiz/plugins/animation/screen0/options/close_durations --type list --list-type int "[100,500]"
gconftool-2 --set /apps/compiz/plugins/animation/screen0/options/close_effects --type list --list-type string "[animation:Fade,animation:Magic Lamp]"
gconftool-2 --set /apps/compiz/plugins/animation/screen0/options/close_matches --type list --list-type string "[(type=Menu | PopupMenu | Dialog | Normal | DropdownMenu),(type=ModalDialog)]"
gconftool-2 --set /apps/compiz/plugins/animation/screen0/options/minimize_durations --type list --list-type int "[500]"
gconftool-2 --set /apps/compiz/plugins/animation/screen0/options/minimize_effects --type list --list-type string "[animation:Magic Lamp]"
gconftool-2 --set /apps/compiz/plugins/animation/screen0/options/minimize_matches --type list --list-type string "[(type=Normal | Dialog | ModalDialog | Unknown)]"
gconftool-2 --set /apps/compiz/plugins/animation/screen0/options/open_durations --type list --list-type int "[100,500]"
gconftool-2 --set /apps/compiz/plugins/animation/screen0/options/open_effects --type list --list-type string "[animation:Fade,animation:Magic Lamp]"
gconftool-2 --set /apps/compiz/plugins/animation/screen0/options/open_matches --type list --list-type string "[(type=Menu | PopupMenu | Dialog | Normal | DropdownMenu),(type=ModalDialog)]"
# Decoration
gconftool-2 --set /apps/compiz/plugins/decoration/allscreens/options/decoration_match --type string "any"
gconftool-2 --set /apps/compiz/plugins/decoration/allscreens/options/shadow_color --type string "#000000ff"
gconftool-2 --set /apps/compiz/plugins/decoration/allscreens/options/shadow_match --type string "any"
gconftool-2 --set /apps/compiz/plugins/decoration/allscreens/options/shadow_opacity --type float 0.44
gconftool-2 --set /apps/compiz/plugins/decoration/allscreens/options/shadow_radius --type float 18.0
gconftool-2 --set /apps/compiz/plugins/decoration/allscreens/options/shadow_x_offset --type int 4
gconftool-2 --set /apps/compiz/plugins/decoration/allscreens/options/shadow_y_offset --type int 5
# Show Desktop
v="BottomLeft"
if [ $qshowdesktop = 0 ]; then
	v=""
fi
gconftool-2 --set /apps/compiz/general/allscreens/options/show_desktop_edge --type string "$v"
gconftool-2 --set /apps/compiz/plugins/showdesktop/screen0/options/direction --type int 5
gconftool-2 --set /apps/compiz/plugins/showdesktop/screen0/options/speed --type float 3
gconftool-2 --set /apps/compiz/plugins/showdesktop/screen0/options/timestep --type float 0.1
gconftool-2 --set /apps/compiz/plugins/showdesktop/screen0/options/window_match --type string "type=toolbar | type=utility | type=dialog | type=normal"
gconftool-2 --set /apps/compiz/plugins/showdesktop/screen0/options/window_opacity --type float 5
gconftool-2 --set /apps/compiz/plugins/showdesktop/screen0/options/window_part_size --type int 10
# Scale
v="BottomRight"
if [ $qshowall = 0 ]; then
	v=""
fi	
gconftool-2 --set /apps/compiz/plugins/scale/allscreens/options/initiate_all_edge --type string "$v"
gconftool-2 --set /apps/compiz/plugins/scale/allscreens/options/initiate_all_key --type string "<Shift><Control>Tab"
gconftool-2 --set /apps/compiz/plugins/scale/allscreens/options/show_desktop --type boolean false
gconftool-2 --set /apps/compiz/plugins/scale/screen0/options/darken_back --type boolean true
gconftool-2 --set /apps/compiz/plugins/scale/screen0/options/hover_time --type int 500
gconftool-2 --set /apps/compiz/plugins/scale/screen0/options/opacity --type int 100
gconftool-2 --set /apps/compiz/plugins/scale/screen0/options/overlay_icon --type int 0
gconftool-2 --set /apps/compiz/plugins/scale/screen0/options/spacing --type int 12
gconftool-2 --set /apps/compiz/plugins/scale/screen0/options/speed --type float 3
gconftool-2 --set /apps/compiz/plugins/scale/screen0/options/window_match --type string "Toolbar | Utility | Dialog | Normal | Unknown"
# Expo
gconftool-2 --set /apps/compiz/plugins/expo/allscreens/options/aspect_ratio --type float 1
gconftool-2 --set /apps/compiz/plugins/expo/allscreens/options/curve --type float 0.18
gconftool-2 --set /apps/compiz/plugins/expo/allscreens/options/deform --type int 2
gconftool-2 --set /apps/compiz/plugins/expo/allscreens/options/distance --type int 0
gconftool-2 --set /apps/compiz/plugins/expo/allscreens/options/expo_animation --type int 0
gconftool-2 --set /apps/compiz/plugins/expo/allscreens/options/expo_edge --type string ""
gconftool-2 --set /apps/compiz/plugins/expo/allscreens/options/expo_key --type string "<Super>e"
gconftool-2 --set /apps/compiz/plugins/expo/allscreens/options/ground_color1 --type string "#b3b3b361"
gconftool-2 --set /apps/compiz/plugins/expo/allscreens/options/ground_color2 --type string "#b3b3b300"
gconftool-2 --set /apps/compiz/plugins/expo/allscreens/options/ground_size --type float 0.33
# Manual only, this creates problems on some machines
# gconftool-2 --set /apps/compiz/plugins/expo/allscreens/options/reflection --type boolean true
#Cube
gconftool-2 --set /apps/compiz/plugins/cube/screen0/options/acceleration --type float 4
gconftool-2 --set /apps/compiz/plugins/cube/screen0/options/active_opacity --type float 37
gconftool-2 --set /apps/compiz/plugins/cube/screen0/options/color --type string "#ffffff00"
gconftool-2 --set /apps/compiz/plugins/cube/screen0/options/in --type boolean false
gconftool-2 --set /apps/compiz/plugins/cube/screen0/options/inactive_opacity --type float 100
gconftool-2 --set /apps/compiz/plugins/cube/screen0/options/skydome --type boolean true
gconftool-2 --set /apps/compiz/plugins/cube/screen0/options/skydome_animated --type boolean false
gconftool-2 --set /apps/compiz/plugins/cube/screen0/options/skydome_image --type string "/usr/share/backgrounds/leopard-aurora.jpg"
gconftool-2 --set /apps/compiz/plugins/cube/screen0/options/speed --type float 1.5
gconftool-2 --set /apps/compiz/plugins/cube/screen0/options/transparent_manual_only --type boolean true
# Rotate
gconftool-2 --set /apps/compiz/plugins/rotate/allscreens/options/initiate_button --type string "<Control><Alt>Button2"
gconftool-2 --set /apps/compiz/plugins/rotate/screen0/options/zoom --type float 0.15
#3d
gconftool-2 --set /apps/compiz/plugins/3d/screen0/options/bevel_topleft --type boolean true
gconftool-2 --set /apps/compiz/plugins/3d/screen0/options/bevel_topright --type boolean true
gconftool-2 --set /apps/compiz/plugins/3d/screen0/options/manual_only --type boolean true
gconftool-2 --set /apps/compiz/plugins/3d/screen0/options/max_window_space --type int 10
gconftool-2 --set /apps/compiz/plugins/3d/screen0/options/min_cube_size --type int 47
gconftool-2 --set /apps/compiz/plugins/3d/screen0/options/width --type float 0.335
gconftool-2 --set /apps/compiz/plugins/3d/screen0/options/width_color --type string "#333333ff"
gconftool-2 --set /apps/compiz/plugins/3d/screen0/options/width_color_inactive --type string "#333333ff"
gconftool-2 --set /apps/compiz/plugins/3d/screen0/options/window_match --type string "Toolbar | Utility | Dialog | Normal | Unknown"
# Shift
gconftool-2 --set /apps/compiz/plugins/shift/allscreens/options/next_all_key --type string "<Super>Tab"
gconftool-2 --set /apps/compiz/plugins/shift/allscreens/options/next_key --type string "Disabled"
gconftool-2 --set /apps/compiz/plugins/shift/allscreens/options/prev_all_key --type string "<Super><Shift>Tab"
gconftool-2 --set /apps/compiz/plugins/shift/allscreens/options/prev_key --type string "Disabled"
gconftool-2 --set /apps/compiz/plugins/shift/screen0/options/ground_color1 --type string "#b3b3b361"
gconftool-2 --set /apps/compiz/plugins/shift/screen0/options/ground_color2 --type string "#b3b3b300"
gconftool-2 --set /apps/compiz/plugins/shift/screen0/options/ground_size --type float 0.33
gconftool-2 --set /apps/compiz/plugins/shift/screen0/options/intensity --type float 0.4
gconftool-2 --set /apps/compiz/plugins/shift/screen0/options/minimized --type boolean true
gconftool-2 --set /apps/compiz/plugins/shift/screen0/options/mouse_speed --type float 10
# Manual only, this creates problems on some machines
# gconftool-2 --set /apps/compiz/plugins/shift/screen0/options/reflection --type boolean true
gconftool-2 --set /apps/compiz/plugins/shift/screen0/options/size --type int 50
# Switcher
gconftool-2 --set /apps/compiz/plugins/switcher/allscreens/options/next_all_key --type string "<Alt>Tab"
gconftool-2 --set /apps/compiz/plugins/switcher/allscreens/options/next_key --type string "Disabled"
gconftool-2 --set /apps/compiz/plugins/switcher/allscreens/options/prev_all_key --type string "<Shift><Alt>Tab"
gconftool-2 --set /apps/compiz/plugins/switcher/allscreens/options/prev_key --type string "Disabled"
gconftool-2 --set /apps/compiz/plugins/switcher/screen0/options/auto_rotate --type boolean true
gconftool-2 --set /apps/compiz/plugins/switcher/screen0/options/bring_to_front --type boolean true
gconftool-2 --set /apps/compiz/plugins/switcher/screen0/options/icon --type boolean false
gconftool-2 --set /apps/compiz/plugins/switcher/screen0/options/minimized --type boolean true
gconftool-2 --set /apps/compiz/plugins/switcher/screen0/options/zoom --type int 5

# Backuping
echo "Backuping..."
mkdir -p $BACKUPDIR/panel
gconftool-2 --dump /apps/panel > $BACKUPDIR/panel/panel.entries
mkdir -p $BACKUPCURRENT/panel
cp $BACKUPDIR/panel/panel.entries $BACKUPCURRENT/panel/

echo "Setting up theme..."
# Backgrounds
gconftool-2 --set /desktop/gnome/background/picture_filename --type string "/usr/share/backgrounds/leopard-aurora.jpg"
# Gtk Theme
gconftool-2 --set /desktop/gnome/interface/gtk_theme --type string "Macbuntu"
gconftool-2 --set /apps/metacity/general/theme --type string "Macbuntu"
gconftool-2 --set /desktop/gnome/interface/icon_theme --type string "Macbuntu-Icons"
# Cursor
gconftool-2 --set /desktop/gnome/peripherals/mouse/cursor_theme --type string "Macbuntu-Cursors"
gconftool-2 --set /desktop/gnome/peripherals/mouse/cursor_size --type int 28
# Button layout
gconftool-2 --set /apps/metacity/general/button_layout --type string "close,minimize,maximize:menu"
# Panels
gconftool-2 --load panel/panel.entries
gconftool-2 --set /apps/panel/general/toplevel_id_list --type list --list-type string "[top_panel_screen0]"
gconftool-2 --set /apps/panel/toplevels/top_panel_screen0/background/type --type string "gtk"
# gconftool-2 --set /apps/panel/toplevels/top_panel_screen0/background/type --type string "image"
# gconftool-2 --set /apps/panel/toplevels/top_panel_screen0/background/image --type string "$HOME/.themes/Macbuntu/gtk-2.0/Panel/panel-bg-solid.png"
# Icons
gconftool-2 --set /desktop/gnome/interface/toolbar_style --type string "icons"
gconftool-2 --set /desktop/gnome/interface/buttons_have_icons --type boolean false
gconftool-2 --set /desktop/gnome/interface/menus_have_icons --type boolean true
# Nautilus
gconftool-2 --set /apps/nautilus/preferences/default_folder_viewer --type string "icon_view"
gconftool-2 --set /apps/nautilus/preferences/side_pane_view --type string "NautilusPlacesSidebar"
gconftool-2 --set /apps/nautilus/preferences/sort_directories_first --type boolean true
gconftool-2 --set /apps/nautilus/preferences/start_with_location_bar --type boolean true
gconftool-2 --set /apps/nautilus/preferences/always_use_location_entry --type boolean false
gconftool-2 --set /apps/nautilus/preferences/start_with_sidebar --type boolean true
gconftool-2 --set /apps/nautilus/preferences/start_with_status_bar --type boolean true
gconftool-2 --set /apps/nautilus/preferences/start_with_toolbar --type boolean true
# Compositing manager
gconftool-2 --set /apps/metacity/general/compositing_manager --type boolean true
# Fonts
if [ ! $lgfont = 1 ]; then
	gconftool-2 --set /desktop/gnome/interface/font_name --type string "Lucida Grande Medium 9"
	gconftool-2 --set /desktop/gnome/interface/document_font_name --type string "Lucida Grande Medium 9"
	gconftool-2 --set /apps/nautilus/preferences/desktop_font --type string "Lucida Grande Medium 9"
	gconftool-2 --set /apps/metacity/general/titlebar_font --type string "Lucida Grande Medium 10"
	gconftool-2 --set /desktop/gnome/interface/monospace_font_name --type string "Lucida Console Semi-Condensed 10"
fi
# Terminal
gconftool-2 --set /apps/gnome-terminal/global/use_menu_accelerators --type boolean false
gconftool-2 --set /apps/gnome-terminal/profiles/Default/background_color --type string "#000000000000"
gconftool-2 --set /apps/gnome-terminal/profiles/Default/background_darkness --type float 0.95
gconftool-2 --set /apps/gnome-terminal/profiles/Default/background_type --type string "transparent"
gconftool-2 --set /apps/gnome-terminal/profiles/Default/foreground_color --type string "#AAAAAAAAAAAA"
gconftool-2 --set /apps/gnome-terminal/profiles/Default/scrollback_unlimited --type boolean true
gconftool-2 --set /apps/gnome-terminal/profiles/Default/use_theme_background --type boolean false
gconftool-2 --set /apps/gnome-terminal/profiles/Default/use_theme_colors --type boolean false

echo "Setting up sound theme..."
gconftool-2 --set /desktop/gnome/sound/theme_name --type string "macbuntu"
gconftool-2 --set /desktop/gnome/sound/input_feedback_sounds --type boolean true
gconftool-2 --set /desktop/gnome/sound/event_sounds --type boolean true
gconftool-2 --set /desktop/gnome/sound/enable_esd --type boolean true

echo "Setting up login screen..."
# Login screen
# Backgrounds
sudo -u gdm gconftool-2 --set /desktop/gnome/background/picture_filename --type string "/usr/share/backgrounds/leopard-aurora.jpg"
# Gtk Theme
sudo -u gdm gconftool-2 --set /desktop/gnome/interface/icon_theme --type string "LoginIcons"
sudo -u gdm gconftool-2 --set /desktop/gnome/interface/gtk_theme --type string "Macbuntu"
sudo -u gdm gconftool-2 --set /apps/metacity/general/theme --type string "Macbuntu"
# Cursor
sudo -u gdm gconftool-2 --set /desktop/gnome/peripherals/mouse/cursor_size --type int 28
sudo -u gdm gconftool-2 --set /desktop/gnome/peripherals/mouse/cursor_theme --type string "Macbuntu-Cursors"
# Logo
sudo -u gdm gconftool-2 --set /apps/gdm/simple-greeter/logo_icon_name --type string "applelogo-black"
sudo rm -rf /usr/share/icons/LoginIcons/icon-theme.cache

# Fonts
if [ ! $lgfont = 1 ]; then
	sudo -u gdm gconftool-2 --set /desktop/gnome/interface/font_name --type string "Lucida Grande Medium 9"
	sudo -u gdm gconftool-2 --set /apps/nautilus/preferences/desktop_font --type string "Lucida Grande Medium 9"
fi

# Sounds
sudo -u gdm gconftool-2 --set /desktop/gnome/sound/theme_name --type string "macbuntu"

# Plymouth theme
echo "Setting up Plymouth theme..."
sudo update-alternatives --install /lib/plymouth/themes/default.plymouth default.plymouth /lib/plymouth/themes/Paw-Ubuntu/paw-ubuntu.plymouth 100
sudo update-alternatives --install /lib/plymouth/themes/default.plymouth default.plymouth /lib/plymouth/themes/Paw-OSX/paw-osx.plymouth 100
# Paw-OSX as default
sudo update-alternatives --set default.plymouth /lib/plymouth/themes/Paw-OSX/paw-osx.plymouth
# Give user a choice
sudo update-alternatives --config default.plymouth
sudo update-initramfs -u

# Reloading Gnome Panel
killall gnome-panel

# Starting Docky...
ANYDOCK=
if [ ! -z $CAIROPID ] || [ ! -z $AWNPID ]; then
	ANYDOCK=1
fi
if [ ! -z $DOCKYPID ] || [ -z $ANYDOCK ]; then
	nohup docky > /dev/null &
fi

if [ ! -z $CAIROPID ]; then
	nohup cairo-dock > /dev/null &
fi

if [ ! -z $AWNPID ]; then
	nohup avant-window-navigator > /dev/null &
fi

# Reloading Compiz
if [ ! -z $COMPIZPID ]; then
	nohup compiz --replace > /dev/null &
fi

echo "Finishing installation..."
echo "$UBUVER-$VERSION" > $MACBUNTUHOME/current
OLD="$MACBUNTUHOME/Maverick-2.3"
rm -rf $OLD
sleep 10

echo ""
echo "$MACBUNTU installation complete! Have fun :)"

echo "Featured"
echo " * Firefox theme Vfox3_Basic and MacOSX Theme"
echo " * Thunderbird theme Leopard Mail-Default-Aqua"
echo " * Chrome theme GTK Leopard Chrome Theme"
echo ""
echo "Do you want to see and install [Y/n]?"
read ans
case "$ans" in
	n*|N*) ;;
	*)
	d="/usr/share/applications/firefox.desktop"
	if [ -f "$d" ]; then
		s=`ps | grep firefox`
		echo $s
		if [ ! -n "$s" ]; then
			firefox &
			sleep 10
		fi
		`firefox -new-tab https://addons.mozilla.org/en-US/firefox/addon/11227/ https://addons.mozilla.org/en-US/firefox/addon/12782/ https://addons.mozilla.org/en-US/thunderbird/addon/6763/` &
# ACE Foxdie looks great but not included - security reason, something wrong with the plugin
# https://addons.mozilla.org/en-US/firefox/addon/6124/ 
# TODO: look at source code, do some tests
	fi
	d="/usr/share/applications/google-chrome.desktop"
	if [ -f "$d" ]; then
		`google-chrome http://eamon63.deviantart.com/art/GTK-Leopard-Chrome-Theme-151975508` &
	fi
	d="/usr/share/applications/chromium-browser.desktop"
	if [ -f "$d" ]; then
		`chromium-browser http://eamon63.deviantart.com/art/GTK-Leopard-Chrome-Theme-151975508` &
	fi
	sleep 10
esac

echo ""
echo "It is recommended that you restart the X server (Control+Alt+Backspace if enabled)"
echo "Positively, if reboot the computer. Restart now?"
echo "Please, press any other key if you want to restart later [y/N]?"
read ans
case "$ans" in
	y*|Y*)
	echo "Rebooting..."
	sudo reboot
	exit 0;
esac

echo "Bye"

else # Tester

echo "Tester..."

fi # End Tester

