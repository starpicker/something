#include <stdio.h>
main()
{
	extern const unsigned long _binary_bin_jpg_start;
	extern const unsigned long _binary_bin_jpg_size;
	extern const unsigned long _binary_bin_jpg_end;


	const unsigned char *start = (const unsigned char*)&_binary_bin_jpg_start;
	const unsigned long size = (const unsigned long)&_binary_bin_jpg_size;
	const unsigned char *end= (const unsigned char*)&_binary_bin_jpg_end;

	printf("_binary_bin_jpg_start = %p\n", &_binary_bin_jpg_start);
	printf("_binary_bin_jpg_size = %d\n", &_binary_bin_jpg_size);
	printf("_binary_bin_jpg_end= %p\n", &_binary_bin_jpg_end);

	FILE * fp = fopen("output.jpg", "w");
	fwrite(start, size, 1, fp);
	fclose(fp);
}
