http://www.byywee.com/page/M0/S952/952818.html
read carefully of test.c

sudo objcopy -I binary -O elf64-x86-64 -B i386 bin.jpg bin.o
objdump -ht bin.o