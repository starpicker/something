/*
 * Copyright (C) 2009 The Android Open Source Project
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 *
 */
#include <string.h>
#include <jni.h>

#include <dirent.h>
#include <stdlib.h>
#include <string.h>
#include <stdio.h>
#include <time.h>

char* getpath(char* path);

jstring
Java_com_example_picdemo_MainActivity_getPath( JNIEnv* env,
                                                  jobject thiz )
{

    char path[256];
    
    return (*env)->NewStringUTF(env, getpath(path));
}

char* getpath(char* path)
{
    char* foldpath = "/sdcard/wp/";
    DIR *dirp;
    struct dirent *dp;
    dirp = opendir(foldpath);
    int count = 0;
    while ((dp = readdir(dirp)) != NULL)count++;
    (void) closedir(dirp);
    srand((unsigned) time(NULL));

    int pos = 0;
    while(pos < 2)
    {
       pos = rand() % count;
    }

    count = 0;

    dirp = opendir(foldpath);
    while ((dp = readdir(dirp)) != NULL)
    {
        if(count++ == pos)
        {
        	strcpy(path, foldpath);
            strcat(path, dp->d_name);
            break;
        }
    }
    (void) closedir(dirp);
    
    return path;
}
