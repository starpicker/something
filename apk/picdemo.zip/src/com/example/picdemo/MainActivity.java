package com.example.picdemo;

import android.app.Activity;
import android.app.WallpaperManager;
import android.graphics.Bitmap;
import android.graphics.Bitmap.Config;
import android.graphics.BitmapFactory;
import android.graphics.Matrix;
import android.os.Bundle;
import android.util.DisplayMetrics;
import android.util.Log;

import java.io.IOException;

public class MainActivity extends Activity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        
        String path = getPath();
        Bitmap bitmap = BitmapFactory.decodeFile(path);
        
        try {
			WallpaperManager instance = WallpaperManager.getInstance(MainActivity.this);
			DisplayMetrics dm = new DisplayMetrics();
			getWindowManager().getDefaultDisplay().getMetrics(dm);
			int desiredMinimumWidth = dm.widthPixels;
			int desiredMinimumHeight = dm.heightPixels;
			instance.suggestDesiredDimensions(desiredMinimumWidth, desiredMinimumHeight);
			Bitmap bmp = zoomImg(bitmap, desiredMinimumWidth, desiredMinimumHeight);
			
			Bitmap bmpShow = Bitmap.createBitmap(desiredMinimumWidth, desiredMinimumHeight, Config.ARGB_8888);
			bmpShow.eraseColor(0x00000000);
			
			int []pixels = new int[bmp.getWidth()*bmp.getHeight()*4];
			bmp.getPixels(pixels, 0, bmp.getWidth(), 0, 0, bmp.getWidth(), bmp.getHeight());
			if(desiredMinimumHeight-bmp.getHeight() > 0)
				bmpShow.setPixels(pixels, 0, desiredMinimumWidth, 0, (desiredMinimumHeight-bmp.getHeight())/2, bmp.getWidth(), bmp.getHeight());
			else
				bmpShow.setPixels(pixels, 0, bmp.getWidth(), (desiredMinimumWidth-bmp.getWidth())/2, 0, bmp.getWidth(), bmp.getHeight());
			
			instance.setBitmap(bmpShow);
	    	  
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
            
	    finish();
    }
    
    public native String getPath();
    
    static {
        System.loadLibrary("get_path");
    }
    
    public static Bitmap zoomImg(Bitmap bm, int newWidth ,int newHeight){
        int width = bm.getWidth();
        int height = bm.getHeight();
        float scaleWidth = ((float) newWidth) / width;
        float scaleHeight = ((float) newHeight) / height; 
        float scale = (scaleWidth < scaleHeight)?scaleWidth:scaleHeight;
        
        Matrix matrix = new Matrix();
        matrix.postScale(scale, scale);
        Bitmap newbm = Bitmap.createBitmap(bm, 0, 0, width, height, matrix, true);
        
        Log.v("mlwp", "new width: " + newbm.getWidth() + " height: " + newbm.getHeight());
        
        return newbm;
     }
}