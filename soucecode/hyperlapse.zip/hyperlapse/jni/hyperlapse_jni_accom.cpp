#include "hyperlapse_jni_accom.h"

#include <stdio.h>
#include <string.h>
#include <android/bitmap.h>

#include "ml_time.h"

#ifndef mllog
#include <android/log.h>
#define log(...) __android_log_print(ANDROID_LOG_ERROR, "mmmlll", __VA_ARGS__)
#else
#ifndef mlllog
#define mlllog
#define log(...)
#endif
#endif

int decode_video_to_raw_data_folder(const char* input_mp4_path, const char* output_raw_data_folder, int* width = nullptr, int* height = nullptr, int* duration = nullptr,
										int * total_frame_num = nullptr, bool nv21 = true, JNIEnv * env = nullptr, jobject obj = nullptr, jmethodID callback = nullptr, 
										MHLAL* e = nullptr);
int convert_nv21_to_rgb565(unsigned char* const nv21_buffer, unsigned char* rgb_buffer, int width, int height, int blur_flag = 0);
int convert_i420_to_rgb565(unsigned char* const i420_buffer, unsigned char* rgb_buffer, int width, int height, int blur_flag = 0);
int nv21_to_jbitmap(JNIEnv *env, jobject& jbitmap, int index, int blur_flag = 0);

enum OUT_RAW_FORMAT{i420, nv21, rgb565, rgba8888, unknown=999};
int decode_video_to_get_first_frame(const char* input_mp4_path, unsigned char* output_raw_data, int width, int height, OUT_RAW_FORMAT out_raw_format = i420);

int ml_gaussian_blur_rgb565(unsigned char* input_output_data, int width, int height);

MHLAL::RAW_FORMAT MHLAL::format = NV21;

std::unique_ptr<char[]> MHLAL::jstringTostring(JNIEnv* env, jstring jstr)
{
	char* rtn = NULL;
	jclass clsstring = env->FindClass("java/lang/String");
	jstring strencode = env->NewStringUTF("utf-8");
	jmethodID mid = env->GetMethodID(clsstring, "getBytes", "(Ljava/lang/String;)[B");
	jbyteArray barr= (jbyteArray)env->CallObjectMethod(jstr, mid, strencode);
	jsize alen = env->GetArrayLength(barr);
	jbyte* ba = env->GetByteArrayElements(barr, JNI_FALSE);
	if (alen > 0)
	{
		//rtn = (char*)malloc(alen + 1);
		rtn = new char[alen + 1];

		memcpy(rtn, ba, alen);
		rtn[alen] = 0;
	}
	env->ReleaseByteArrayElements(barr, ba, 0);
	return std::unique_ptr<char[]>(rtn);
}

int MHLAL::decode_video_to_raw_data_folder(const char* input_mp4_path, const char* output_raw_data_folder, int* width, int* height, int* duration, 
											int* total_frame_num, RAW_FORMAT raw_format, JNIEnv * env, jobject obj, jmethodID callback, MHLAL* e)
{
	int ret = 0;
	//format = raw_format;
	
	log("decode_video_to_raw_data_folder raw_format :%d, format :%d, MHLAL::NV21 :%d, MHLAL::I420 :%d", raw_format, format, MHLAL::NV21, MHLAL::I420);
	
	if(raw_format == NV21)
		ret = ::decode_video_to_raw_data_folder(input_mp4_path, output_raw_data_folder, width, height, duration, total_frame_num, true, env, obj, callback, e);
	else
		ret = ::decode_video_to_raw_data_folder(input_mp4_path, output_raw_data_folder, width, height, duration, total_frame_num, false, env, obj, callback, e);
	
	return ret;
}

int MHLAL::decode_video_to_get_first_frame(const char* input_mp4_path, unsigned char* output_raw_data, int width, int height, RGB_FORMAT rgb_format, int blurflag)
{
	int ret = 0;
	if(rgb_format == RGB565) {
		ret = ::decode_video_to_get_first_frame(input_mp4_path, output_raw_data, width, height, rgb565);
	}
	else {
		if(rgb_format == RGBA8888) {
			ret = ::decode_video_to_get_first_frame(input_mp4_path, output_raw_data, width, height, rgba8888);
		}
		else {
			log("MHLAL::decode_video_to_get_first_frame only support rgb565 rgba8888, exit");
			ret = -1;
		}
	}
	
	if(blurflag)
	{
		//call blur
		ret = ml_gaussian_blur_rgb565(output_raw_data, width, height);
	}
	return ret;
	
}

int MHLAL::convert_raw_to_rgb(unsigned char* const raw_buffer, unsigned char* rgb_buffer, int width, int height, 
									RAW_FORMAT raw_format, RGB_FORMAT rgb_format, int blur_flag)
{
	int ret = 0;
	if((raw_format == NV21) && (rgb_format == RGB565))
		ret = ::convert_nv21_to_rgb565(raw_buffer, rgb_buffer, width, height, blur_flag);
	else if((raw_format == I420) && (rgb_format == RGB565))
		ret = ::convert_i420_to_rgb565(raw_buffer, rgb_buffer, width, height, blur_flag);
		else			
			log("not support color convert, except nv21 to rgb565, i420 to rgb565");
	
	return ret;
}

int MHLAL::offscreen_to_jbitmap(JNIEnv *env, jobject& jbitmap, LPASVLOFFSCREEN pRaw, int blur_flag)
{
	T
	AndroidBitmapInfo info;
    void* addr;
    int res;
	RGB_FORMAT rgb_pix_fmt = RGB_UNKNOWN;
	RAW_FORMAT raw_pix_fmt = RAW_UNKNOWN;
	unsigned char* rgb_buffer = NULL;
	int rgb_buffer_len;
	unsigned char* raw_buffer = NULL;
	int width;
	int height;
	
	res = AndroidBitmap_getInfo(env, jbitmap, &info);
    if(res != 0)
    {
		goto exit;
    }
	
	width = info.width;
	height = info.height;
    switch(info.format)
    {
		case ANDROID_BITMAP_FORMAT_RGB_565:
			rgb_pix_fmt = RGB565;
			rgb_buffer_len = width*height<<1;
			rgb_buffer = (unsigned char*) malloc(rgb_buffer_len);
            break;
        case ANDROID_BITMAP_FORMAT_RGBA_8888:
            rgb_pix_fmt = RGBA8888;
			rgb_buffer_len = width*height<<2;
			rgb_buffer = (unsigned char*) malloc(rgb_buffer_len);
            break;

    }

    if(rgb_pix_fmt == RGB_UNKNOWN)
    {
        goto exit;
    }
	
	switch(pRaw->u32PixelArrayFormat)
	{
		case ASVL_PAF_NV21:
			raw_pix_fmt = NV21;
			raw_buffer	= (unsigned char*) malloc(width*height*3>>1);
			break;
		case ASVL_PAF_I420:
			raw_pix_fmt = I420;
			raw_buffer	= (unsigned char*) malloc(width*height*3>>1);
			break;
	}
	
	if(raw_buffer == NULL)
	{
		goto exit;
	}

	if(raw_pix_fmt == RAW_UNKNOWN)
    {
        goto exit;
    }
	
	if((pRaw->i32Width != width) || (pRaw->i32Height != height))
	{
		log("width and height is not same, exit");
		goto exit;
	}
	
	{
	//not good
		auto p = new MLTIME("offscreen_to_jbitmap memcpy raw to raw");
		memcpy(raw_buffer, pRaw->ppu8Plane[0], width*height*3>>1);
		delete p;
	}
	
	//missing rgba8888
	{
		auto p = new MLTIME("offscreen_to_jbitmap convert_raw_to_rgb");
		res = convert_raw_to_rgb(raw_buffer, rgb_buffer, width, height, raw_pix_fmt, rgb_pix_fmt, blur_flag);
		delete p;
	}
	if(res != 0)
    {
		goto exit;
    }
	
    res = AndroidBitmap_lockPixels(env, jbitmap, &addr);
    if(res != 0)
    {
		goto exit;
    }
	
	if(rgb_pix_fmt == RGB565)
	{
		auto p = new MLTIME("offscreen_to_jbitmap memcpy rgb565 to rgb565");
		memcpy(addr, rgb_buffer, rgb_buffer_len);
		delete p;
	}
	
	if(rgb_pix_fmt == RGBA8888)
	{
        for(int i = 0; i < width * height; i += 4)
        {
            ((unsigned char*)addr)[i] 	= rgb_buffer[i + 2];
            ((unsigned char*)addr)[i + 1] = rgb_buffer[i + 1];
            ((unsigned char*)addr)[i + 2] = rgb_buffer[i]    ;
            ((unsigned char*)addr)[i + 3] = rgb_buffer[i + 3];
        }
	}

	
	AndroidBitmap_unlockPixels(env,jbitmap);

exit:
	free(rgb_buffer);
	free(raw_buffer);
    return res;
}