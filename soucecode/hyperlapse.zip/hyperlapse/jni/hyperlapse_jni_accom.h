#include <jni.h>

#include "hyperlapse.h"

#include <memory>

struct MHLAL {

#define MHLAL_MAX_PATH_LEN 256
	
	enum RAW_FORMAT{NV21, I420, RAW_UNKNOWN=999};
	enum RGB_FORMAT{RGB565, RGBA8888, RGB_UNKNOWN=999};
	
	MHLAL(LPINIT_PARAM param):width(0), height(0), duration(0), total_frame_num(0), hls(new Hyperlapse(param))
	{
		mp4_path[0] = '\0';
		raw_data_folder[0] = '\0';
	}
	~MHLAL(){delete hls;};
	
	int width;
	int height;
	int duration;
	int total_frame_num;
	char mp4_path[MHLAL_MAX_PATH_LEN];
	char raw_data_folder[MHLAL_MAX_PATH_LEN];
	Hyperlapse* hls;
	
	static RAW_FORMAT format;	
	static std::unique_ptr<char[]> jstringTostring(JNIEnv* env, jstring jstr);
	static int decode_video_to_raw_data_folder(const char* input_mp4_path, const char* output_raw_data_folder, int* width = nullptr, int* height = nullptr, int* duration = nullptr,
												 int* total_frame_num = nullptr, RAW_FORMAT raw_format = NV21, JNIEnv * env = nullptr, jobject obj = nullptr, jmethodID callback = nullptr, 
												 MHLAL* e  = nullptr);
	static int offscreen_to_jbitmap(JNIEnv *env, jobject& jbitmap, LPASVLOFFSCREEN pRaw, int blur_flag = 0);

	static int decode_video_to_get_first_frame(const char* input_mp4_path, unsigned char* output_raw_data, int width, int height, RGB_FORMAT rgb_format = RGB565, int blurflag = 0);
private:
	static int convert_raw_to_rgb(unsigned char* const raw_buffer, unsigned char* rgb_buffer, int width, int height, 
									RAW_FORMAT raw_format = NV21, RGB_FORMAT rgb_format = RGB565, int blur_flag = 0);
};