
/*-----------------------------------------------------------------------------
 *
 * This file is ArcSoft's property. It contains ArcSoft's trade secret, 
 * proprietary and confidential information. 
 * 
 * The information and code contained in this file is only for authorized 
 * ArcSoft employees to design, create, modify, or review.
 * 
 * DO NOT DISTRIBUTE, DO NOT DUPLICATE OR TRANSMIT IN ANY FORM WITHOUT 
 * PROPER AUTHORIZATION.
 * 
 * If you are not an intended recipient of this file, you must not copy, 
 * distribute, modify, or take any action in reliance on it. 
 * 
 * If you have received this file in error, please immediately notify ArcSoft 
 * and permanently delete the original and any copy of any file and any 
 * printout thereof.
 *
 *---------------------------------------------------------------------------*/

/*-----------------------------------------------------------------------------
 * File Name - ajl.h
 * Purpose   - AJL Common Header File
 *             This file contains:  definitions for data types, data
 *             structures, error codes, and function prototypes used
 *             in the Arcsoft (R) JPEG Library (AJL).
 *
 * History   - 
 *	Current Version:	1.0.0.13
 *	Last Updated Date:	11/11/2004
 *	By:					Ji Chen
 *---------------------------------------------------------------------------*/

#ifndef __AJL_INC__
#define __AJL_INC__

/* configuration */
#ifdef __WIN32__
# undef __WIN32__
#endif


#if defined( __cplusplus )
extern "C" {
#endif

/** pdefine.h ***************************************************************/
typedef signed int      AInt;
typedef signed char     AInt8;
typedef signed short    AInt16;
typedef signed long     AInt32;
typedef unsigned int    AUInt;
typedef unsigned char   AUInt8;
typedef unsigned short  AUInt16;
typedef unsigned long   AUInt32;

typedef long            ALong;
typedef short           AShort;
typedef unsigned char   AByte;
typedef unsigned short  AWord;
typedef unsigned long   ADWord;
typedef float           AFloat;
typedef double          ADouble;
typedef void *          AHandle;
typedef char            AChar;
typedef unsigned short  AWChar;
typedef long            ABool;
typedef void            AVoid;
typedef void *          APVoid;
typedef char *          APChar;
typedef const char *    APCChar;
typedef	ALong           ARESULT;
typedef ADWord          ACOLORREF; 

typedef AByte           ASMP;
typedef AShort          ACOEF;

typedef struct _APOINT
{ 
  ALong   x; 
  ALong   y; 

} APOINT, * PAPOINT;

typedef struct _ASIZE
{
  ALong   cx;
  ALong   cy;

} ASIZE, * PASIZE;

typedef struct _ARECT
{ 
  ALong   left;
  ALong   top;
  ALong   right;
  ALong   bottom;

} ARECT, * PARECT;

/** aversion.h *************************************************************/

typedef struct _AJLVersion
{
  AInt          major;
  AInt          minor;
  AInt			release;
  AInt          build;
  const APChar  Version;
  const APChar  BuildDate;
  const APChar  CopyRight;

} AJLVersion;

/** aconst.h ***********************************************************/

/* Status Tag */
#define ANULL                   0
#define AFALSE                  0
#define ATRUE                   1

/* Error Tag */  
#define AJL_OK                  0x00000000L
#define AJL_ERR_ARGUMENT        0x00000001L
#define AJL_ERR_NOT_AVAIL       0x00000002L
#define AJL_ERR_FILE_OP         0x00000003L
#define AJL_ERR_MEMORY_FAIL     0x00000004L
#define AJL_ERR_NOT_JPEG        0x00000005L
#define AJL_ERR_SCALEFACTOR     0x00000006L
#define AJL_ERR_UNKNOWN         0x00000007L
#define AJL_ERROR               0x00000008L
#define AJL_ERR_WRONGSCALE      0x00000009L
#define AJL_ERR_EXIF_NOT_AVAIL  0x0000000AL
#define AJL_USER_INTERRUPT      0x0000000BL
#define AJL_ERR_INVALID_PARAMS  0x0000000CL
#define AJL_ERR_UNSUPPORTTED    0x0000000DL
#define AJL_ERR_UNFINISHED      0x0000000EL
#define AJL_ERR_UNNAMED			(~0)

//#define MAX_COMP                4   /* Maximum Components */
#define MAX_COMP                3

/** aexif.h *************************************************************/

/* Describes format descriptor */
#define      FORMAT_NUM              12 /* Total Format # Supported */

/* Every Format */
#define FMT_BYTE        1
#define FMT_STRING      2
#define FMT_USHORT      3
#define FMT_ULONG       4
#define FMT_URATIONAL   5
#define FMT_SBYTE       6
#define FMT_UNDEFINED   7
#define FMT_SSHORT      8		/* not defined in Exif 2.2 standard */
#define FMT_SLONG       9
#define FMT_SRATIONAL   10
#define FMT_SINGLE      11		/* not defined in Exif 2.2 standard */
#define FMT_DOUBLE      12		/* not defined in Exif 2.2 standard */

#define MAX_COMMENT     1000
#define MAX_SECTIONS    20

#define BUF_AUDIO_SIZE  32768


/* Exif Tags */
typedef enum _EXIF_Tags {
  /* Inherit From TIFF */
  E_IMAGE_WIDTH                     = 0x0100,
  E_IMAGE_HEIGHT                    = 0x0101,
  E_BITS_PER_SAMPLE                 = 0x0102,
  E_COMPRESSION                     = 0x0103,
  E_PHOTOMETRIC_INTERPRETATION      = 0x0106,
  E_ORIENTATION                     = 0x0112,
  E_SAMPLES_PER_PIXEL               = 0x0115,
  E_PLANAR_CONFIGURATION            = 0x011C,
  E_YCBCR_SUBSAMPLING               = 0x0212,
  E_YCBCR_POSITIONING               = 0x0213,
  E_X_RESOLUTION                    = 0x011A,
  E_Y_RESOLUTION                    = 0x011B,
  E_RESOLUTION_UNIT                 = 0x0128,
  
  E_STRIP_OFFSETS                   = 0x0111,
  E_ROWS_PER_STRIP                  = 0x0116,
  E_STRIP_BYTE_COUNTS               = 0x0117,
  E_JPEG_INTERCHANGE_FORMAT         = 0x0201,
  E_JPEG_INTERCHANGE_FORMAT_LENGTH  = 0x0202,
  
  E_TRANSFER_FUNCTION               = 0x012D,
  E_WHITE_POINT                     = 0x013E,
  E_PRIMARY_CHROMATICITIES          = 0x013F,
  E_YCBCR_COEFFICIENTS              = 0x0211,
  E_REFERENCE_BLACK_WHITE           = 0x0214,
  
  E_DATE_TIME                       = 0x0132,
  E_IMAGE_DESCRIPTION               = 0x010E,
  E_MAKE                            = 0x010F,
  E_MODEL                           = 0x0110,
  E_SOFTWARE                        = 0x0131,
  E_ARTIST                          = 0x013B,
  E_COPY_RIGHT                      = 0x8298,
  
  E_IFD_POINTER                     = 0x8769,
  E_IFD_GPS_POINTER                 = 0x8825,
  E_IFD_INTERP_POINTER              = 0xA005,
  
  /* Exif Property */
  E_EXIF_VERSION                    = 0x9000,
  E_FLASHPIX_VERSION                = 0xA000,
  
  E_COLOR_SPACE                     = 0xA001,
  
  E_COMPONENTS_CONFIGURATION        = 0x9101,
  E_COMPRESSED_BITS_PER_PIXEL       = 0x9102,
  E_PIXEL_X_DIMENSION               = 0xA002,
  E_PIXEL_Y_DIMENSION               = 0xA003,
  
  E_MAKER_NOTE                      = 0x927C,
  E_USER_COMMENT                    = 0x9286,
  
  E_RELATED_SOUND_FILE              = 0xA004,
  
  E_DATE_TIME_ORIGINAL              = 0x9003,
  E_DATE_TIME_DIGITIZED             = 0x9004,
  E_SUB_SEC_TIME                    = 0x9290,
  E_SUB_SEC_TIME_ORIGINAL           = 0x9291,
  E_SUB_SEC_TIME_DIGITIZED          = 0x9292,
  
  E_EXPOSURE_TIME                   = 0x829A,
  E_FNUMBER                         = 0x829D,
  E_EXPOSURE_PROGRAM                = 0x8822,
  E_SPECTRAL_SENSITIVITY            = 0x8824,
  E_ISO_SPEED_RATINGS               = 0x8827,
  E_OECF                            = 0x8828,
  E_SHUTTER_SPEED_VALUE             = 0x9201,
  E_APERTURE_VALUE                  = 0x9202,
  E_BRIGHTNESS_VALUE                = 0x9203,
  E_EXPOSURE_BIAS_VALUE             = 0x9204,
  E_MAX_APERTURE_VALUE              = 0x9205,
  E_SUBJECT_DISTANCE                = 0x9206,
  E_METERING_MODE                   = 0x9207,
  E_LIGHT_SOURCE                    = 0x9208,
  E_FLASH                           = 0x9209,
  E_FOCAL_LENGTH                    = 0x920A,
  E_FOCAL_ENERGY                    = 0xA20B,
  E_SPATIAL_FREQ_RESPONSE           = 0xA20C,
  E_FOCAL_PLANE_X_RESOLUTION        = 0xA20E,
  E_FOCAL_PLANE_Y_RESOLUTION        = 0xA20F,
  E_FOCAL_PLANE_RESOLUTION_UNIT     = 0xA210,
  E_SUBJECT_LOCATION                = 0xA214,
  E_EXPOSURE_INDEX                  = 0xA215,
  E_SENSING_METHOD                  = 0xA217,
  E_FILE_SOURCE                     = 0xA300,
  E_SCENE_TYPE                      = 0xA301,
  E_CFA_PATTERN                     = 0xA302
  
} EXIF_TAG;


typedef struct EXIF_INFO_EXTERNAL * LPAEXIF;

/** aparam.h *************************************************/

/* Compressed JPEG Decode/Encode Parameters */
typedef struct AJPEGParams_EXTERNAL *AJPEGParams;

/** pfile.h *************************************************************/

#define AFILE     AVoid
	
/** amemstch.h *************************************************************/

typedef struct _AMEM_STITCH_REQ {
	ABool stitch;         /* Use Stitch Memory (= ATRUE) */
	ABool full_buff;      /* Use Full Buffer (= ATRUE) */
	AInt  block_size;     /* Every Block Size */
	
} AMEM_STITCH_REQ, * APMEM_STITCH_REQ;

/** aprop.h *************************************************************/

/* Color Space Definitions */
typedef enum {
  A_GRAY        = 1,    /* Grayscale Color Space. */
  A_RGB         = 2,    /* Red-Green-Blue Color Space. */
  A_BGR         = 3,    /* Reversed Channel Ordering From A_RGB. */
  A_YCBCR       = 4,    /* Luminance-Chrominance Color Space As Defined */
                        /* By CCIR Recommendation 601. */
  A_OTHER       = 255  /* Some Other Color Space Not Defined. */
                        /* (This Means No Color Space Conversion Needed). */
    
} AColorSpace;

/* Sub-sampling Definitions */
typedef enum {
  A_NONE    = 0,    /* Contain No Infor   */
  A_411     = 1,    /* Horz 2:1, Vert 2:1 */
  A_422_H   = 2,    /* Horz 2:1, Vert 1:1 */
  A_422_V   = 3,    /* Horz 1:1, Vert 2:1 */
  A_444     = 4    /* Horz 1:1, Vert 1:1 */

} ASubSampling;

/* Specified Format Output Definations */
/* 8 bits per sample */
typedef enum
{
	AF_UNKNOWN		= 0,	/* unsupported format */
	
	AF_YUV_GRAY_DCT	= 10,	/* input/output format only */
	AF_YUV_444_DCT	= 11,
	AF_YUV_422H_DCT	= 12,
	AF_YUV_422V_DCT	= 13,
	AF_YUV_411_DCT	= 14,
							/* format in memory */
	AF_DCT			= 1,	/* MCU */
	AF_GRAY			= 3,	/* 8 bit scaled values, monochrome */

	AF_BGR_C		= 20,	/* B0G0R0, B1G1R1...  */
	AF_BGRA_C		= 21,	/* B0G0R0A0, B1G1R1A1... */
	AF_RGB_C		= 22,	/* R0G0B0, R1G1B1...  */
	AF_RGBA_C		= 23,	/* R0G0B0A0, R1G1R1B1... */
	AF_RGB_P		= 24,	/* R0R1..., G0G1..., B0B1... */
	AF_BGR_P		= 25,	/* B0B1..., G0G1..., R0R1... */
	
	AF_YUV_P		= 30,	/* default yuv planar format */
	AF_YUV_444_P	= 31,	/* Y0U0V0Y1U1V1... */
	AF_YUV_422H_P	= 32,	/* Y0Y1U0V0, Y3Y4U1V1... */
	AF_YUV_422V_P	= 33,	/* Y00Y10U0V0, Y01Y11U1V1... */
	AF_YUV_411_P	= 34,	/* Y00Y01Y10Y11U0V0, ... */
	
	AF_YUV_C		= 35,	/* default yuv chunky format */
	AF_YUV_444_C	= 36,	/* Y0U0V0Y1U1V1... */
	AF_YUV_422H_C	= 37,	/* Y0Y1U0V0, Y3Y4U1V1... */
	AF_YUV_422V_C	= 38,	/* Y00Y10U0V0, Y01Y11U1V1... */
	AF_YUV_411_C	= 39	/* Y00Y01Y10Y11U0V0... */

} AFormat;

/* Data Requirement Type */
typedef enum {
  A_REQ_RGB   = 0,  /* RGB or BGR */
  A_REQ_YCBCR = 1,  /* YCbCr */
  A_REQ_COEF  = 2  /* DCT Coefficient */

} AReqType;

/* Read Property */
typedef struct _AJL_READ_PROP_EXTERNAL * PAJL_READ_PROP;

/* Read Context */
typedef struct _AJL_READ_CONTEXT {
  ABool           avail;      /* The Context Is O.K. (= ATRUE) */
  AFILE *         file;       /* File Stream Handle */
  AByte *         memory;     /* Memory Pointer */
  AInt            type;       /* File ? Memory */
  AInt            size;       /* Source Data Size */
  ASIZE           scales;     /* Horizontal & Vertical Scale Factor */

  PAJL_READ_PROP  prop;       /* Read Property Structure */

} AJL_READ_CONTEXT, * PAJL_READ_CONTEXT;

/* Mapping Memory Parameters */
typedef struct _AJL_MEMORY_PARAM {
	AFormat fmt;	/* added by Zhenyu Yang on 03-15-04 */
	ABool is_planar;
	AInt  num_comp;
	AInt  blk_per_BCU;
	AInt  image_width;
	AInt  image_height;
	AInt  comp_width[MAX_COMP];
	AInt  comp_height[MAX_COMP];
	AInt  comp_pitch[MAX_COMP];
	AInt  comp_size[MAX_COMP];

} AJL_MEMORY_PARAM, * PAJL_MEMORY_PARAM;

/* Write Property */
typedef struct _AJL_WRITE_PROP_EXTERNAL * PAJL_WRITE_PROP;

/* Write Context */
typedef struct _AJL_WRITE_CONTEXT {
  ABool           avail;
  AFILE *         file;
  AByte *         memory;
  AInt            type;
  AInt            size;

  PAJL_WRITE_PROP prop;
  
} AJL_WRITE_CONTEXT, * PAJL_WRITE_CONTEXT;

/** aencapi.h *************************************************************/

ARESULT 
ajlWriteFileInit(PAJL_WRITE_CONTEXT write, AChar * file_name, APMEM_STITCH_REQ req, AInt est_size,
                 AInt width, AInt height, AColorSpace color_space, ASubSampling sub_sampling,
                 AInt quality, ABool fast_quality);

ARESULT
ajlWriteMemoryInit(PAJL_WRITE_CONTEXT write, AByte * pOutput, ALong OutputMemSize, APMEM_STITCH_REQ req, AInt est_size,
				   AInt width, AInt height, AColorSpace color_space, ASubSampling sub_sampling, ARESULT  (* write_buffer) (AByte *buffer, AInt bytes_in_buffer, AByte ** newbuffer, AInt * newbuffer_size),
				   AInt quality, ABool fast_quality);

ARESULT
ajlWriteFileUninit(PAJL_WRITE_CONTEXT write);

ARESULT
ajlWriteMemoryUninit(PAJL_WRITE_CONTEXT write);

ARESULT
ajlEditFileInit(PAJL_READ_CONTEXT read, 
                PAJL_WRITE_CONTEXT write, AChar * file_name, 
                APMEM_STITCH_REQ req, AInt est_size, ABool fast_quality);

ARESULT
ajlWriteSaveHeader(PAJL_WRITE_CONTEXT write, AByte * exif, AInt exif_size);

ARESULT
ajlWriteCopyTables(PAJL_WRITE_CONTEXT write, AJPEGParams * tables);

ARESULT
ajlWriteSaveDCTFromMemory(PAJL_WRITE_CONTEXT write, 
                          ACOEF * image, AInt width, AInt height, AInt pitch, AInt blk_per_MCU);

ARESULT
ajlWriteSaveYUVPlanarFromMemory(PAJL_WRITE_CONTEXT write,
                                AByte ** image, AInt width, AInt height, AInt * pitch);

ARESULT
ajlWriteSaveYUVChunkyFromMemory(PAJL_WRITE_CONTEXT write, 
                                AByte * image, AInt width, AInt height, AInt pitch);

ARESULT
ajlWriteSaveRGBPlanarFromMemory(PAJL_WRITE_CONTEXT write,
                                AByte ** image, AInt width, AInt height, AInt * pitch);

ARESULT 
ajlWriteSaveRGBChunkyFromMemory(PAJL_WRITE_CONTEXT write,
                                AByte * image, AInt width, AInt height, AInt pitch);

ARESULT 
ajlWriteSetCallback(PAJL_WRITE_CONTEXT write, 
					ARESULT (* user_callback) (AInt nNumerator, AInt nDenominator, AVoid *pPrime), AVoid *pPrime); 
/** adecapi.h *************************************************************/

/* API Interface */
ARESULT 
ajlReadFileInit(PAJL_READ_CONTEXT read, AChar * file_name, APMEM_STITCH_REQ req);

ARESULT
ajlReadFileInit_OI(PAJL_READ_CONTEXT read, AChar * file_name, APMEM_STITCH_REQ req, AUInt32 IndexSize);

ARESULT 
ajlReadFileInit_SE(PAJL_READ_CONTEXT read, AChar * file_name, APMEM_STITCH_REQ req);

ARESULT
ajlReadMemoryInit(PAJL_READ_CONTEXT read, AByte * pSrcData, AUInt imgsize, APMEM_STITCH_REQ req);

ARESULT
ajlReadFileUninit(PAJL_READ_CONTEXT read);

ARESULT
ajlReadMemoryUninit(PAJL_READ_CONTEXT read);

ARESULT
ajlReadGetDimension(PAJL_READ_CONTEXT read, ASIZE * dimension);

ARESULT
ajlReadGetBCUIntervals(PAJL_READ_CONTEXT read, ASIZE * intervals);

ARESULT
ajlReadGetBCUDimension(PAJL_READ_CONTEXT read, ASIZE * BCU_dimension);

ARESULT
ajlReadGetScaleFactors(PAJL_READ_CONTEXT read, ASIZE * scales);

ARESULT
ajlReadSetScaleFactors(PAJL_READ_CONTEXT read, ASIZE * scales);

ARESULT
ajlReadGetScaledCropRegion(PAJL_READ_CONTEXT read, ARECT * region);

ARESULT
ajlReadGetCropRegion(PAJL_READ_CONTEXT read, ARECT * region);

ARESULT
ajlReadGetMapMemoryParams(PAJL_READ_CONTEXT read, ARECT * region, AReqType req, ABool is_planar, 
                          PAJL_MEMORY_PARAM mem);

ARESULT
ajlReadGetMapMemoryParamsFormat(PAJL_READ_CONTEXT read, ARECT * region,
								PAJL_MEMORY_PARAM mem);

AJPEGParams * 
ajlReadGetTables(PAJL_READ_CONTEXT read);

ARESULT 
ajlReadLoadDCTToMemory(PAJL_READ_CONTEXT read, ARECT * region, 
                       ACOEF * image, AInt width, AInt height, AInt pitch, AInt blk_per_BCU);

ARESULT
ajlReadLoadYUVPlanarToMemory(PAJL_READ_CONTEXT read, ARECT * region,
							 AByte ** image, AInt width, AInt height, AInt * pitch);

ARESULT
ajlReadLoadYUVChunkyToMemory(PAJL_READ_CONTEXT read, ARECT * region,
                             AByte * image, AInt width, AInt height, AInt pitch);

ARESULT
ajlReadLoadYUVChunkyToMemory_OI(PAJL_READ_CONTEXT read, ARECT * region,
								AByte * image, AInt width, AInt height, AInt pitch);
								
ARESULT
ajlReadLoadRGBPlanarToMemory(PAJL_READ_CONTEXT read, ARECT * region,
							 AByte ** image, AInt width, AInt height, AInt * pitch);

ARESULT
ajlReadLoadRGBChunkyToMemory(PAJL_READ_CONTEXT read, ARECT * region,
                             AByte * image, AInt width, AInt height, AInt pitch);
ARESULT
ajlReadLoadRGBChunkyToMemory_OI(PAJL_READ_CONTEXT read, ARECT * region,
                             AByte * image, AInt width, AInt height, AInt pitch);
ARESULT
ajlReadLoadToMemoryFormat(PAJL_READ_CONTEXT read, ARECT *region,
						  AByte ** image, PAJL_MEMORY_PARAM mem);

// Added by Ji Chen 11/10/04
ARESULT 
ajlReadSetCallback(PAJL_READ_CONTEXT read,
				   ARESULT (* user_callback) (AInt nNumerator, AInt nDenominator, AVoid *pPrime), AVoid *pPrime); 

/** arot.h *************************************************************/

typedef enum {

	A_ROT_NONE      = 0,
	A_ROT_HORZFLIP  = 1,
	A_ROT_VERTFLIP  = 2,  
	A_ROT_CW90      = 3,
	A_ROT_CW180     = 4,
	A_ROT_CW270     = 5,
	A_ROT_TRANSPOSE = 6,
	A_ROT_TRANSVERSE= 7
		
} A_ROT_TYPE;



/** arepfrm.h *************************************************************/
typedef struct _AMULREPLACE_RECT{
	
	ARECT   region;
	AInt    num_comp;
	AInt    image_width;
	AInt    image_height;
	AInt  comp_pitch[MAX_COMP];
	union {
		ASMP * rgbchunky;
		ASMP * rgbplanar[MAX_COMP];
		ASMP * yuvchunky;
		ASMP * yuvplanar[MAX_COMP];
		ACOEF * coef;
	}data;
	
}AMULREPLACE_RECT, * APMULREPLACE_RECT;
/** aedtapi.h *************************************************************/

ARESULT
ajlEditCropGetRegion(PAJL_READ_CONTEXT read, ARECT * region);

ARESULT
ajlEditCrop(PAJL_READ_CONTEXT read, PAJL_WRITE_CONTEXT write, ARECT * region, 
            AByte * exif, AInt exif_size);

ARESULT
ajlEditRotGetDimension(PAJL_READ_CONTEXT read, ASIZE * dimension, A_ROT_TYPE rot);

ARESULT
ajlEditRot(PAJL_READ_CONTEXT read, PAJL_WRITE_CONTEXT write, A_ROT_TYPE rot, 
           AByte * exif, AInt exif_size);

ARESULT
ajlEditAutoContrast(PAJL_READ_CONTEXT read, PAJL_WRITE_CONTEXT write, 
                    ADouble a, ADouble b, AByte * exif, AInt exif_size);

ARESULT
ajlEditAutoBrightness(PAJL_READ_CONTEXT read, PAJL_WRITE_CONTEXT write, 
                      ADouble a, ADouble b, AByte * exif, AInt exif_size);

ARESULT 
ajlEditAutoColor(PAJL_READ_CONTEXT read, PAJL_WRITE_CONTEXT write, 
                 ADouble du, ADouble dv, AByte * exif, AInt exif_size);

ARESULT
ajlEditAutoLevel(PAJL_READ_CONTEXT read, PAJL_WRITE_CONTEXT write,
                 ADouble * da, ADouble * db, AByte * exif, AInt exif_size);

ARESULT
ajlEditReplaceDCTFromMemory(PAJL_READ_CONTEXT read, PAJL_WRITE_CONTEXT write, 
                            ARECT * region, ACOEF * image, AInt width, AInt height, 
                            AInt pitch, AInt blk_per_BCU, 
                            AByte * exif, AInt exif_size);

ARESULT
ajlEditReplaceYUVPlanarFromMemory(PAJL_READ_CONTEXT read, PAJL_WRITE_CONTEXT write,
                                  ARECT * region, AByte ** image, 
                                  AInt width, AInt height, AInt * pitch, 
                                  AByte * exif, AInt exif_size);

ARESULT
ajlEditReplaceYUVChunkyFromMemory(PAJL_READ_CONTEXT read, PAJL_WRITE_CONTEXT write, 
                                  ARECT * region, AByte * image, 
                                  AInt width, AInt height, AInt pitch,
                                  AByte * exif, AInt exif_size);

ARESULT
ajlEditReplaceRGBPlanarFromMemory(PAJL_READ_CONTEXT read, PAJL_WRITE_CONTEXT write,
                                  ARECT * region, AByte ** image, 
                                  AInt width, AInt height, AInt * pitch,
                                  AByte * exif, AInt exif_size);

ARESULT 
ajlEditReplaceRGBChunkyFromMemory(PAJL_READ_CONTEXT read, PAJL_WRITE_CONTEXT write,
                                  ARECT * region, AByte * image, 
                                  AInt width, AInt height, AInt pitch,
                                  AByte * exif, AInt exif_size);
ARESULT 
ajlEditMulReplaceRGBChunkyFromMemory(PAJL_READ_CONTEXT read, PAJL_WRITE_CONTEXT write,
									 APMULREPLACE_RECT pMulRect, AInt nRegionNum,
									 AByte * exif, AInt exif_size);
ARESULT 
ajlEditMulReplaceYUVChunkyFromMemory(PAJL_READ_CONTEXT read, PAJL_WRITE_CONTEXT write,
									 APMULREPLACE_RECT pMulRect, AInt nRegionNum,
									 AByte * exif, AInt exif_size);
ARESULT 
ajlEditMulReplaceDCTFromMemory(PAJL_READ_CONTEXT read, PAJL_WRITE_CONTEXT write,
							   APMULREPLACE_RECT pMulRect, AInt nRegionNum,
							   AByte * exif, AInt exif_size);
ARESULT 
ajlEditMulReplaceRGBPlanarFromMemory(PAJL_READ_CONTEXT read, PAJL_WRITE_CONTEXT write,
									 APMULREPLACE_RECT pMulRect, AInt nRegionNum,
									 AByte * exif, AInt exif_size);
ARESULT 
ajlEditMulReplaceYUVPlanarFromMemory(PAJL_READ_CONTEXT read, PAJL_WRITE_CONTEXT write,
									 APMULREPLACE_RECT pMulRect, AInt nRegionNum,
									 AByte * exif, AInt exif_size);
// Added by Ji Chen 11/10/04
ARESULT 
ajlEditSetCallback(PAJL_READ_CONTEXT read, PAJL_WRITE_CONTEXT write,
				   ARESULT (* user_callback) (AInt nNumerator, AInt nDenominator, AVoid *pPrime), AVoid *pPrime); 
/* aexif.h */

ABool	ajlReadHaveExif(PAJL_READ_CONTEXT read);
ABool	ajlReadHaveThumbnail(PAJL_READ_CONTEXT read);
ARESULT ajlGetThumbnail_Length(PAJL_READ_CONTEXT read, AWord * pwThumLength);
ARESULT ajlFetchThumbnail(PAJL_READ_CONTEXT read, AWord wThumLength , AByte * pThumbnail, ABool * bThumb_compressed); 

// currently disabled, will be available for advanced users
// noted by Zhenyu Yang on 10/21/2004
//ARESULT ajlModifyThumbnail(PAJL_WRITE_CONTEXT write, AByte *pThumbnail, ALong lThumbnailSize);
//ARESULT ajlDeleteThumbnail(PAJL_WRITE_CONTEXT write);
//ARESULT ajlFetchExifDimension(PAJL_READ_CONTEXT read, ADWord *dXDimension, ADWord *dYDimension);
//ARESULT ajlSetExifDimension(PAJL_WRITE_CONTEXT write, ADWord dXDimension, ADWord dYDimension);
//ARESULT ajlInitialExifInfo(PAJL_WRITE_CONTEXT write, AWord dXDimension, AWord dYDimension);

ARESULT ajlExifCopy(LPAEXIF pDst, LPAEXIF pSrc);
// added by Zhenyu Yang on 10/18/2004
LPAEXIF ajlReadGetExif(PAJL_READ_CONTEXT read);
LPAEXIF ajlWriteGetExif(PAJL_WRITE_CONTEXT write);

// added in aprop.h
AColorSpace ajlReadGetColorSpace(PAJL_READ_CONTEXT read);
ASubSampling ajlReadGetSubSampling(PAJL_READ_CONTEXT read);

// aversio.h
const AJLVersion * ajlGetVersion();

#if defined( __cplusplus )
}
#endif

#endif /* __AJL_INC__ */
