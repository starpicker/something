/*----------------------------------------------------------------------------------------------
*
* This file is ArcSoft's property. It contains ArcSoft's trade secret, proprietary and 		
* confidential information. 
* 
* The information and code contained in this file is only for authorized ArcSoft employees 
* to design, create, modify, or review.
* 
* DO NOT DISTRIBUTE, DO NOT DUPLICATE OR TRANSMIT IN ANY FORM WITHOUT PROPER AUTHORIZATION.
* 
* If you are not an intended recipient of this file, you must not copy, distribute, modify, 
* or take any action in reliance on it. 
* 
* If you have received this file in error, please immediately notify ArcSoft and 
* permanently delete the original and any copy of any file and any printout thereof.
*
*---------------------------------------------------------------------------------------------*/
/*
 * ADKRECT.h
 *
 * interface for the functions of MPOINT, MRECT & MSIZE.
 *
 *
 * Code History
 *    
 * --2005-3-15 Weiren Sun ( wrsun@arcsoft.com.cn )
 *   initial version 
 *
 * Code Review
 *
 *
 */


#ifndef _ADKRECT_H_
#define _ADKRECT_H_

#ifdef __cplusplus
extern "C" {
#endif

	
/* functions for MPOINT structure */
MVoid ADK_PointSet(PMPOINT pPt, MLong x, MLong y);
#define ADK_PointSetPt(pPtDst, pPtSrc) \
			AMASSERT((pPtDst) && (pPtSrc)); *(pPtDst) = *(pPtSrc)

MVoid ADK_PointOffset(PMPOINT pPt, MLong dx, MLong dy);
#define ADK_PointOffsetPt(pPt, pPtOffset)\
			AMASSERT((pPt) && (pPtOffset)); ADK_PointOffset((pPt), (pPtOffset)->x, (pPtOffset)->y)

#define ADK_PointAdd(pPt, x, y)\
			ADK_PointOffset((pPt), (x), (y))
#define ADK_PointAddPt(pPt, pPtAugend)\
			AMASSERT((pPtAugend)); ADK_PointOffset((pPt), (pPtAugend)->x, (pPtAugend)->y)
#define ADK_PointSub(pPt, x, y)\
			ADK_PointOffset((pPt), -(x), -(y))
#define ADK_PointSubPt(pPt, pPtMinuend)\
			AMASSERT((pPtMinuend)); ADK_PointOffset((pPt), -(pPtMinuend)->x, -(pPtMinuend)->y)

MBool ADK_PointIsEqual(PMPOINT pPt, MLong x, MLong y);
#define ADK_PointIsUnequal(pPt, x, y)\
			(!(ADK_PointIsEqual((pPt), (x), (y)))
#define ADK_PointIsEqualPt(pPt1, pPt2)\
			ADK_PointIsEqual((pPt1), (pPt2)->x, (pPt2)->y)
#define ADK_PointIsUnequalPt(pPt1, pPt2)\
			(!(ADK_PointIsEqualPt(pPt1, pPt2))

/* functions for MRECT structure */

MVoid ADK_SetRect(PMRECT pRect, MLong lLeft, MLong lTop, MLong lRight, MLong lBottom);
#define ADK_CopyRect(pRtDst, pRtSrc)\
			AMASSERT((pRtDst) && (pRtSrc)); *(pRtDst) = *(pRtSrc)
#define ADK_SetRectWH(pRect, l, t, w, h)\
			AMASSERT(pRect); ADK_SetRect((pRect), (l), (t), (l) + (w), (t) + (h))

MBool ADK_PtInRect(PMRECT pRect, MLong x, MLong y);
#define ADK_PtInRectPt(pRect, pPt)\
			ADK_PtInRect((pRect), (pPt)->x, (pPt)->y)

MVoid ADK_OffsetRect(PMRECT pRect, MLong dx, MLong dy);
#define ADK_OffsetRectPt(pRect, pPtDelta)\
			AMASSERT(pPtDelta); ADK_OffsetRect((pRect), (pPtDelta)->x, (pPtDelta)->y)

MBool ADK_IsRectEmpty(PMRECT pRect);
MLong ADK_GetRectWidth(PMRECT pRect);
MLong ADK_GetRectHeight(PMRECT pRect);
MPOINT ADK_GetRectSize(PMRECT pRect);
MPOINT ADK_RectTopLeft(PMRECT pRect);
MPOINT ADK_RectBottomRight(PMRECT pRect);
MPOINT ADK_RectCenterPoint(PMRECT pRect);
MBool ADK_IsRectNull(PMRECT pRect); /* note that null means _all_ zeros*/
MVoid ADK_SetRectEmpty(PMRECT pRect);
MBool ADK_EqualRect(PMRECT pRect1, PMRECT pRect2);
MVoid ADK_InflateRect(PMRECT pRect, MLong lDLeft, MLong lDTop, MLong lDRight, MLong lDBottom);
#define ADK_InflateRectXY(pRect, dx, dy)\
			ADK_InflateRect((pRect), (dx), (dy), (dx), (dy))
#define ADK_InflateRectPt(pRect, pPt)\
			AMASSERT(pPt); ADK_InflateRect((pRect), (pPt)->x, (pPt)->y, (pPt)->x, (pPt)pt->y)
#define ADK_DeflateRect(pRect, l, t, r, b)\
			ADK_InflateRect((pRect), -(l), -(t), -(r), -(b))
#define ADK_DeflateRectXY(pRect, dx, dy)\
			ADK_InflateRect((pRect), -(dx), -(dy), -(dx), -(dy))
#define ADK_DeflateRectPt(pRect, pPt)\
			AMASSERT(pPt); ADK_InflateRect((pRect), -(pPt)->x, -(pPt)->y, -(pPt)->x, -(pPt)pt->y)
			
MVoid ADK_NormalizeRect(PMRECT pRect);
MBool ADK_IntersectRect(PMRECT pRtDst, PMRECT pRect1, PMRECT pRect2);
MBool ADK_UnionRect(PMRECT pRtDst, PMRECT pRect1, PMRECT pRect2);
	/*Note   Both of the rectangles must be normalized or this function may fail.
	You can call NormalizeRect to normalize the rectangles before calling this function.*/


#ifdef __cplusplus
}
#endif


#endif /*_ADKRECT_H_*/
