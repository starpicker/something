/*----------------------------------------------------------------------------------------------
*
* This file is ArcSoft's property. It contains ArcSoft's trade secret, proprietary and 		
* confidential information. 
* 
* The information and code contained in this file is only for authorized ArcSoft employees 
* to design, create, modify, or review.
* 
* DO NOT DISTRIBUTE, DO NOT DUPLICATE OR TRANSMIT IN ANY FORM WITHOUT PROPER AUTHORIZATION.
* 
* If you are not an intended recipient of this file, you must not copy, distribute, modify, 
* or take any action in reliance on it. 
* 
* If you have received this file in error, please immediately notify ArcSoft and 
* permanently delete the original and any copy of any file and any printout thereof.
*
*---------------------------------------------------------------------------------------------*/
/*
 * adkarray.h
 *
 * interface for the CMArray class.
 *
 *
 * Code History
 *    
 * --2005-6-9 Weiren Sun ( wrsun@arcsoft.com.cn )
 *   initial version 
 *
 * Code Review
 *
 *
 */


#ifndef _ADKARRAY_H_
#define _ADKARRAY_H_

#ifdef __cplusplus
extern "C" {
#endif
	

MRESULT ADK_DArrayCreate(MDWord dwBytesPerUnit, MHandle hMemContext, MHandle* phDArray);
MRESULT ADK_DArrayDestroy(MHandle hDArray);
MRESULT ADK_DArraySetSize(MHandle hDArray, MLong lSize);
MRESULT	ADK_DArrayGrow(MHandle hDArray, MLong lCnt);
MRESULT	ADK_DArrayRemoveAll(MHandle hDArray);
MRESULT ADK_DArrayAdd(MHandle hDArray, MVoid* pElement, MLong* plIndex);
MRESULT ADK_DArrayInsertAt(MHandle hDArray, MLong lIndex, MVoid* pElement);
MRESULT ADK_DArrayRemoveAt(MHandle hDArray, MLong lIndex, MLong lCount);
MRESULT ADK_DArrayMoveElement(MHandle hDArray, MLong lOldIndex, MLong lNewIndex, MBool* pbSucc);
MRESULT ADK_DArraySwapElement(MHandle hDArray, MLong lIndex1, MLong lIndex2, MBool* pbSucc);
MRESULT ADK_DArrayFind(MHandle hDArray, MVoid* pElement, MLong* plIndex);
MRESULT ADK_DArrayIsValidIndex(MHandle hDArray, MLong lIndex, MBool* pbValid);
MRESULT ADK_DArrayGetBuffer(MHandle hDArray, MVoid** ppBuff);
MRESULT ADK_DArrayGetCount(MHandle hDArray, MLong* plCount);
MRESULT ADK_DArrayGetUpperBound(MHandle hDArray, MLong* plUpperBound);
MRESULT ADK_DArrayFreeExtra(MHandle hDArray);
MRESULT ADK_DArrayGetAt(MHandle hDArray, MLong lIndex, MVoid** ppElement);
MRESULT	ADK_DArraySetAt(MHandle hDArray, MLong lIndex, MVoid* pElement);


#ifdef __cplusplus
}
#endif


#endif /*_ADKARRAY_H_*/
