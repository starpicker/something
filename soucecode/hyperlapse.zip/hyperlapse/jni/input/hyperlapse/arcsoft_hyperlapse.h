/*******************************************************************************
Copyright(c) ArcSoft, All right reserved.

This file is ArcSoft's property. It contains ArcSoft's trade secret, proprietary 
and confidential information. 

The information and code contained in this file is only for authorized ArcSoft 
employees to design, create, modify, or review.

DO NOT DISTRIBUTE, DO NOT DUPLICATE OR TRANSMIT IN ANY FORM WITHOUT PROPER 
AUTHORIZATION.

If you are not an intended recipient of this file, you must not copy, 
distribute, modify, or take any action in reliance on it. 

If you have received this file in error, please immediately notify ArcSoft and 
permanently delete the original and any copy of any file and any printout 
thereof.
*******************************************************************************/
#ifndef _ARCSOFT_HYPERLAPSE_H_
#define _ARCSOFT_HYPERLAPSE_H_

#include "asvloffscreen.h"
#include "merror.h"

#ifdef HPLPDLL_EXPORTS
#define HPLP_API __declspec(dllexport)
#else
#define HPLP_API
#endif

#ifdef __cplusplus
extern "C" {
#endif

#define HPLP_SPEEDUP_1X		0x1
#define HPLP_SPEEDUP_2X		0x2
#define HPLP_SPEEDUP_4X		0x3
#define HPLP_SPEEDUP_8X		0x4
#define HPLP_SPEEDUP_16X	0x5
#define HPLP_SPEEDUP_32X	0x6

/************************************************************************
* This function is used to get version information of library
************************************************************************/
typedef struct _tag_AHPLP_Version {
	MInt32		lCodebase;		// Codebase version number
	MInt32		lMajor;			// Major version number
	MInt32		lMinor;			// Minor version number
	MInt32		lBuild;			// Build version number, increasable only
	const MChar *Version;		// Version in string form
	const MChar *BuildDate;		// Latest build date
	const MChar *CopyRight;		// Copyrights
} AHPLP_Version;

HPLP_API MVoid AHPLP_GetVersion(AHPLP_Version *pVer);

/************************************************************************
* The functions is used to perform video hyperlapse
************************************************************************/
typedef struct _tag_INIT_PARAM {
	MFloat				fTrimRatio;
	MUInt32				PAF;
} INIT_PARAM, *LPINIT_PARAM;

HPLP_API MRESULT AHPLP_Init(			    // return MOK if success, otherwise fail
	MVoid				*pMemBuf,			// [in]  The buffer of memory for algorithm
	MInt32				lMemSize,			// [in]  The size of the memory buffer
	LPINIT_PARAM		pParam,				// [in]  The parameters for initializing engine
	MHandle				*phEngine			// [out] The algorithm engine will be initialized by this API
);

HPLP_API MRESULT AHPLP_Uninit(				// return MOK if success, otherwise fail
	MHandle				*phEngine			// [in/out] The algorithm engine will be un-initialized by this API
);

/* ************************************
 * APIs for stage one
 * ************************************/
HPLP_API MRESULT AHPLP_AddFrame(			// return MOK if success, otherwise fail
	MHandle				hEngine,			// [in]  The algorithm engine
	LPASVLOFFSCREEN		pSrcImg				// [in]  The offscreen of source image
);

#define AVS_TYPE_GYROSCOPE	0x0

HPLP_API MRESULT AHPLP_SetSensorData(		// return MOK if success, otherwise fail
	MHandle				hEngine,			// [in]  The algorithm engine
	MInt32				iSensorMode,		// [in]  The type of sensor data
	MFloat				pfData[],			// [in]  The sensor raw data, 1 x 3 float array
	MDouble				fTimeStamp			// [in]  The timestamp of received sensor data
);

/* ************************************
 * APIs for stage two
 * ************************************/
HPLP_API MRESULT AHPLP_Preprocess(			// return MOK if success, otherwise fail
	MHandle				hEngine				// [in]  The algorithm engine	
);

typedef struct _tag_FRAME_LIST {
	MInt32		*pFrameList;				// the list of frames
	MInt32		lFrameSize;					// the size of frame list
} FRAME_LIST, *LPFRAME_LIST;

HPLP_API MRESULT AHPLP_GetFrameList(		// return MOK if success, otherwise fail
	MHandle				hEngine,			// [in]  The algorithm engine
	MInt32				lSpeed,				// [in]  The speed for play
	LPFRAME_LIST		pList				// [out] The returned frame list	
);

/* ************************************
 * APIs for stage three
 * ************************************/
typedef struct _tag_HPLP_PARAM {
	MInt32				lSpeed;
} HPLP_PARAM, *LPHPLP_PARAM;

HPLP_API MRESULT AHPLP_ResetHyperlapse(		// return MOK if success, otherwise fail
	MHandle				hEngine,			// [in]  The algorithm engine
	LPHPLP_PARAM		pParam				// [in]  The parameters for algorithm engine
);

HPLP_API MRESULT AHPLP_DoHyperlapse(		// return MOK if success, otherwise fail
	MHandle				hEngine,			// [in]  The algorithm engine
	MInt32				lFrameNo,			// [in]  The frame number of image
	LPASVLOFFSCREEN		pSrcImg,			// [in]  The offscreen of source image
	LPASVLOFFSCREEN		pDstImg				// [out] The offscreen of result image	
);

#ifdef __cplusplus
}
#endif

#endif // _ARCSOFT_HYPERLAPSE_H_
