#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <jni.h>

#include "asvloffscreen.h"
#include "hyperlapse_jni_accom.h"

extern "C"{
#include "libavcodec/avcodec.h"
#include "libavformat/avformat.h"
#include "libswscale/swscale.h"
}

#ifndef mllog
#include <android/log.h>
#define log(...) __android_log_print(ANDROID_LOG_ERROR, "mmmlll", __VA_ARGS__)
#else
#ifndef mlllog
#define mlllog
#define log(...)
#endif
#endif

//const int KSIZE = 59;
//int opencv_gaussian_blur(unsigned char* const input_output_yuv, int width, int height, int ksize = KSIZE);

#define PROGRESS_SHIFT 7

//demo quality
int decode_video_to_raw_data_folder(const char* input_mp4_path, const char* output_raw_data_folder, int* width, int* height, int* duration, 
										int* total_frame_num, bool nv21, JNIEnv * env, jobject obj, jmethodID callback, MHLAL* e)
{
	log("mp4 path: %s, raw data folder: %s, format is: %s", input_mp4_path, output_raw_data_folder, [nv21](){return ((nv21 == true)?"nv21":"i420");}());
	
	//for ffmpeg decoder
	AVFormatContext     *pav_format_context = nullptr;
	AVCodecContext      *pav_codec_context = nullptr;
	AVCodec             *pcodec;
	AVFrame             *pframe = nullptr;
	AVPacket            packet;
	int                 video_stream;
	int                 frame_finished;
	FILE* 				fp;
	char 				raw_data_file_path[256];
	int					res = 0;
	unsigned char* 		frame_buffer = nullptr;
	SwsContext*			img_convert_ctx = nullptr;
	uint8_t 			*dst[3];
	int 				dstStride[3];
	int 				y_size;
	int 				index = 0;
	int 				times = 0;
	int 				call_per_frames = 1;
	bool				notify = false;
	
	ASVLOFFSCREEN img 	= {0};
	
	// Register all formats and codecs
    av_register_all();
    // Open video file
    if(avformat_open_input(&pav_format_context, input_mp4_path, nullptr, nullptr) != 0)
    {
        log("avformat_open_input for %s failed\n", input_mp4_path);
        return -1; // Couldn't open file
    }
	
	// Retrieve stream information
    if(avformat_find_stream_info(pav_format_context, NULL) < 0)
	{
		res = -1;
		goto exit;
	}


    // Dump information about file onto standard error
    av_dump_format(pav_format_context, -1, input_mp4_path, 0);

    log("pav_format_context->nb_streams :%d\n", pav_format_context->nb_streams);
	
	// Find the first video stream
    video_stream = -1;
    for( int i = 0; i < (int)(pav_format_context->nb_streams); i++ )
    {
        if( pav_format_context->streams[i]->codec->codec_type == AVMEDIA_TYPE_VIDEO)
        {
            video_stream = i;
            break;
        }
    }

    if( video_stream == -1 )
	{
		res = -1;
		goto exit;
	}
	
	
	pav_codec_context = pav_format_context->streams[video_stream]->codec;

    pcodec = avcodec_find_decoder(pav_codec_context->codec_id);
    if( pcodec == nullptr )
	{
		res = -1;
		goto exit;
	}
    if( avcodec_open2(pav_codec_context, pcodec, nullptr) < 0 )
	{
		res = -1;
		goto exit;
	}

    pframe = av_frame_alloc();
    if( pframe == nullptr )
	{
		res = -1;
		goto exit;
	}

    av_frame_unref(pframe);
	
	if((width != nullptr) && (height != nullptr) && (duration != nullptr))
	{
		*width = pav_codec_context->width;
		*height = pav_codec_context->height;
		*duration = pav_format_context->streams[video_stream]->duration*av_q2d(pav_format_context->streams[video_stream]->time_base);
		goto exit;
	}
	
	if((env != nullptr) && (obj != nullptr) && (callback != nullptr))
	{
		notify = true;
	}
		
	y_size = pav_codec_context->width * pav_codec_context->height;
	frame_buffer = (unsigned char*) malloc(y_size*3>>1);
	if(frame_buffer == nullptr)
	{
		res = -1;
		goto exit;
	}
	
	dst[0] = frame_buffer;
	dst[1] = frame_buffer+y_size;
	
	dstStride[0] = pav_codec_context->width;
	dstStride[1] = pav_codec_context->width;
	
	img_convert_ctx = sws_getContext(pav_codec_context->width, pav_codec_context->height, pav_codec_context->pix_fmt, pav_codec_context->width,
										pav_codec_context->height, AV_PIX_FMT_NV21, SWS_BICUBIC, NULL, NULL, NULL); 
	
	call_per_frames = pav_format_context->streams[video_stream]->nb_frames>>PROGRESS_SHIFT;
	
	//if(e != nullptr)
	{
		img.ppu8Plane[0] = (unsigned char*) frame_buffer;
		
		//if(e->format == MHLAL::NV21)
		if(nv21)
		{
			img.u32PixelArrayFormat = ASVL_PAF_NV21;
			img.i32Width            = pav_codec_context->width;
			img.i32Height           = pav_codec_context->height;
			img.ppu8Plane[1]        = img.ppu8Plane[0] + img.i32Width*img.i32Height;
			img.pi32Pitch[0]        = img.i32Width;
			img.pi32Pitch[1]        = img.i32Width;
		}
		else
		//if(e->format == MHLAL::I420)
		{
			img.u32PixelArrayFormat = ASVL_PAF_I420;
			img.i32Width            = pav_codec_context->width;
			img.i32Height           = pav_codec_context->height;
			img.ppu8Plane[1]        = img.ppu8Plane[0] + img.i32Width*img.i32Height;
			img.ppu8Plane[2]        = img.ppu8Plane[1] + (img.i32Width*img.i32Height>>2);
			img.pi32Pitch[0]        = img.i32Width;
			img.pi32Pitch[1]        = img.i32Width>>1;
			img.pi32Pitch[2]        = img.i32Width>>1;
		}
	}
	
	while( av_read_frame(pav_format_context, &packet) >= 0 )
    {
		log("av_read_frame in");
		
        if( packet.stream_index == video_stream )
        {
            avcodec_decode_video2(pav_codec_context, pframe, &frame_finished, &packet);

            if(frame_finished)
            {
				 log("width :%d, linesize: %d, %d, %d", pav_codec_context->width, pframe->linesize[0], pframe->linesize[1], pframe->linesize[2]);
				 if(nv21)
				 {
					sws_scale(img_convert_ctx, (const uint8_t* const*)pframe->data, pframe->linesize, 0, pav_codec_context->height, dst, dstStride);
					sprintf(raw_data_file_path, "%s/%dx%d_%05d.nv21", output_raw_data_folder, pav_codec_context->width, pav_codec_context->height, index++);
					
					fp = fopen(raw_data_file_path, "w");
					 log("raw_data_file_path nv21 :%s, index :%d, fp :%p", raw_data_file_path, index, fp);
					 if(fp)
					 {
						log("raw_data_file_path nv21 before fwrite");
						fwrite(frame_buffer, y_size*3>>1, 1, fp);
						log("raw_data_file_path nv21 after fwrite");
						
						fclose(fp);
					 }
				 }
				 else
				 {
					sprintf(raw_data_file_path, "%s/%dx%d_%05d.i420", output_raw_data_folder, pav_codec_context->width, pav_codec_context->height, index++);

					fp = fopen(raw_data_file_path, "w");
					log("raw_data_file_path i420 :%s, index :%d, fp :%p", raw_data_file_path, index, fp);
					if(fp)
					{
						for(int plane = 0; plane < 3; plane++)
						{
							if(plane == 0)
							{
								//write Y plane
								for(int y = 0; y < pav_codec_context->height; y++)
								{
									memcpy(img.ppu8Plane[0], pframe->data[plane] + y * pframe->linesize[plane], pav_codec_context->width);
									fwrite(pframe->data[plane] + y * pframe->linesize[plane], 1, pav_codec_context->width, fp);
									img.ppu8Plane[0] += pav_codec_context->width;
								}
							}
							else
							{
								//write U/V plane
								for(int y = 0; y < pav_codec_context->height / 2; y++)
								{
									memcpy(img.ppu8Plane[0], pframe->data[plane] + y * pframe->linesize[plane], pav_codec_context->width / 2);
									fwrite(pframe->data[plane] + y * pframe->linesize[plane], 1, pav_codec_context->width / 2, fp);
									img.ppu8Plane[0] += pav_codec_context->width / 2;
								}
							}
						}
						img.ppu8Plane[0] = frame_buffer;
						fclose(fp);
					}
				 }
				 
				 log("notify before call_per_frames :%d", call_per_frames);
				 
				 if(notify && (call_per_frames == 0))
				 {
					 env->CallVoidMethod(obj, callback, (int)(((double)index)/(pav_format_context->streams[video_stream]->nb_frames) * 1000));
					 log("progress_d: %d, and index is %d, frames count is %lld",(int)(((double)index)/(pav_format_context->streams[video_stream]->nb_frames) * 1000), index, pav_format_context->streams[video_stream]->nb_frames);
				 }
				 else
				 {
					if(notify && (index/call_per_frames > times))
					 {
						times = index/call_per_frames;
						if(times*1000>>PROGRESS_SHIFT < 980)
						{
							log("CallVoidMethod before");
							env->CallVoidMethod(obj, callback, times*1000>>PROGRESS_SHIFT);
							log("progress: %d", times*1000>>PROGRESS_SHIFT);
						}
					 }
				 }

				 log("notify after");
				 
					//do hyperlapse add frame
					if(e)
					{
						int ret = e->hls->AddFrame(&img);
						if(ret != MOK)
							goto exit;
					}
            }
        }
        av_free_packet(&packet);
    }
	
	if(notify)
		env->CallVoidMethod(obj,callback,1000);
	
	if(total_frame_num)
		*total_frame_num = index;
	
	{
		int ret = e->hls->Preprocess();
		if(ret != MOK)
			goto exit;
	}
exit:
	if(img_convert_ctx)
		sws_freeContext(img_convert_ctx);
	free(frame_buffer);
    av_frame_free(&pframe);
    avcodec_close(pav_codec_context);
    avformat_close_input(&pav_format_context);
	
	return res;
}

enum OUT_RAW_FORMAT{i420, nv21, rgb565, rgba8888, unknown=999};
int decode_video_to_get_first_frame(const char* input_mp4_path, unsigned char* output_raw_data, int width, int height, 
									OUT_RAW_FORMAT out_raw_format)
{
	log("decode_video_to_get_first_frame mp4 path: %s", input_mp4_path);
	
	//for ffmpeg decoder
	AVFormatContext     *pav_format_context = nullptr;
	AVCodecContext      *pav_codec_context = nullptr;
	AVCodec             *pcodec;
	AVFrame             *pframe = nullptr;
	AVPacket            packet;
	int                 video_stream;
	int                 frame_finished;
	int					res = 0;
	SwsContext*			img_convert_ctx = nullptr;
	uint8_t 			*dst[3];
	int 				dstStride[3];
	int 				y_size;
	AVPixelFormat		pix_fmt = AV_PIX_FMT_NONE;
	bool 				color_convert = false;
	
	// Register all formats and codecs
    av_register_all();
    // Open video file
    if(avformat_open_input(&pav_format_context, input_mp4_path, nullptr, nullptr) != 0)
    {
        log("avformat_open_input for %s failed\n", input_mp4_path);
        return -1; // Couldn't open file
    }
	
	// Retrieve stream information
    if(avformat_find_stream_info(pav_format_context, NULL) < 0)
	{
		res = -1;
		goto exit;
	}


    // Dump information about file onto standard error
    //av_dump_format(pav_format_context, -1, input_mp4_path, 0);

    log("pav_format_context->nb_streams :%d\n", pav_format_context->nb_streams);
	
	// Find the first video stream
    video_stream = -1;
    for( int i = 0; i < (int)(pav_format_context->nb_streams); i++ )
    {
        if( pav_format_context->streams[i]->codec->codec_type == AVMEDIA_TYPE_VIDEO)
        {
            video_stream = i;
            break;
        }
    }

    if( video_stream == -1 )
	{
		res = -1;
		goto exit;
	}
	
	
	pav_codec_context = pav_format_context->streams[video_stream]->codec;

    pcodec = avcodec_find_decoder(pav_codec_context->codec_id);
    if( pcodec == nullptr )
	{
		res = -1;
		goto exit;
	}
    if( avcodec_open2(pav_codec_context, pcodec, nullptr) < 0 )
	{
		res = -1;
		goto exit;
	}

    pframe = av_frame_alloc();
    if( pframe == nullptr )
	{
		res = -1;
		goto exit;
	}

    av_frame_unref(pframe);
	
	if((width != pav_codec_context->width) && (height != pav_codec_context->height))
	{
		log("width and height is not the same, exit");
		goto exit;
	}
		
	y_size = pav_codec_context->width * pav_codec_context->height;
	if(output_raw_data == nullptr)
	{
		res = -1;
		goto exit;
	}
	
	switch(out_raw_format)
	{
		case i420:
			pix_fmt = AV_PIX_FMT_YUV420P;
			color_convert = false;
			break;
		case nv21:
			{
				pix_fmt = AV_PIX_FMT_NV21;
				dst[0] = output_raw_data;
				dst[1] = output_raw_data+y_size;
				dstStride[0] = pav_codec_context->width;
				dstStride[1] = pav_codec_context->width;
				color_convert = true;
			}
			break;
		case rgb565:
			{
				pix_fmt = AV_PIX_FMT_RGB565;
				dst[0] = output_raw_data;
				dstStride[0] = pav_codec_context->width<<1;
				color_convert = true;
			}
			break;
		case rgba8888:
			{
				pix_fmt = AV_PIX_FMT_RGB32;
				dst[0] = output_raw_data;
				dstStride[0] = pav_codec_context->width<<2;
				color_convert = true;
			}
			break;
		default:
			break;
	}
	
	if(pix_fmt == AV_PIX_FMT_NONE)
	{
		log("only support out format i420 nv21 rgb565 rgba8888, exit");
		goto exit;
	}
	

	if(color_convert)
		img_convert_ctx = sws_getContext(pav_codec_context->width, pav_codec_context->height, pav_codec_context->pix_fmt, pav_codec_context->width,
										pav_codec_context->height, pix_fmt, SWS_BICUBIC, NULL, NULL, NULL); 
										
	while( av_read_frame(pav_format_context, &packet) >= 0 )
    {
        if( packet.stream_index == video_stream )
        {
            avcodec_decode_video2(pav_codec_context, pframe, &frame_finished, &packet);

            if(frame_finished)
            {
				if(color_convert)
					sws_scale(img_convert_ctx, (const uint8_t* const*)pframe->data, pframe->linesize, 0, pav_codec_context->height, dst, dstStride);
				
				break;
            }
        }
        av_free_packet(&packet);
    }
	
exit:
	if(img_convert_ctx)
		sws_freeContext(img_convert_ctx);
    av_frame_free(&pframe);
    avcodec_close(pav_codec_context);
    avformat_close_input(&pav_format_context);
	
	log("decode_video_to_get_first_frame out");
	return res;
}

#define USING__ARCSOFT_PP

#ifdef USING__ARCSOFT_PP
#include "amdisplay.h"
#include "asvloffscreen.h"
#include "ampostprocess.h"
#include "merror.h"
#endif //USING__ARCSOFT_PP

int convert_nv21_to_rgb565(unsigned char* const nv21_buffer, unsigned char* rgb_buffer, int width, int height, int blur)
{
#ifdef USING__ARCSOFT_PP

	int res = MOK;
	MPAFPIXEL PixelSrc = {0}, PixelDst = {0};
	MByte *ppSrc[MPP_MAX_PLANES] = {0};
	MInt32 lSrcPitch[MPP_MAX_PLANES] = {0};
	MByte *ppDst[MPP_MAX_PLANES] = {0};
	MInt32 lDstPitch[MPP_MAX_PLANES] = {0};
	MBLITFX mblitfx = {0};
	MHandle	pphandle;
	
	PixelSrc.dwHeight  = height;
	PixelSrc.dwWidth   = width;
	PixelSrc.dwSpaceID = MPAF_OTHERS_NV21 | MPAF_BT601_YCBCR;
	
	PixelDst.dwHeight  = height;
	PixelDst.dwWidth   = width;
	PixelDst.dwSpaceID = MPAF_RGB16_R5G6B5;

	mblitfx.dwDirection       = 0;
	mblitfx.dwReSizeAlg       = MPP_RESIZE_NEAREST_NEIGHBOUR;//MPP_RESIZE_BILINEAR;
	
	mblitfx.dwAspectRatio     = 0;//MPP_ASPECT_RATIO_FIT_OUT;
	mblitfx.dwProcessorType   = 0;
	mblitfx.dwPerformanceMode = MPP_PERFORMANCE_AUTO;
	mblitfx.dwDither          = 0;
	mblitfx.dwAlpha           = 255;
	
	res = MPPCreate(&PixelDst, &PixelSrc, &mblitfx, &pphandle);
 	log("convert_nv21_to_rgb565 MPPCreate res = %d" , res);
	if (res != MOK)
	{
		return res;
	}
	
	lSrcPitch[0] = width;
	lSrcPitch[1] = lSrcPitch[0];
	lSrcPitch[2] = lSrcPitch[1];
	
	lDstPitch[0] = width<<1;
	lDstPitch[1] = 0;
	lDstPitch[2] = 0;
	
	ppSrc[0] = nv21_buffer;
	ppSrc[2] = ppSrc[0] + width*height;
	ppSrc[1] = ppSrc[2] + 1;
	
	ppDst[0] = rgb_buffer;
	ppDst[1] = 0;
	ppDst[2] = 0;
	
	
	res = MPProcess(pphandle, ppDst, MNull, lDstPitch, ppSrc, lSrcPitch);
	log("convert_nv21_to_rgb565 MPProcessres = %d" , res);
	if (pphandle)
	{
		MPPDestroy(pphandle);
	}
	log("convert_nv21_to_rgb565 out");
	return res;
	
#else
	
	if(blur)
	{
		//opencv_gaussian_blur(nv21_buffer, width, height);
	}
	
	int y_size = width*height;
	uint8_t 			*const src[3] = {nv21_buffer, nv21_buffer+y_size};
	const int 			srcStride[3] = {width, width};
	
	uint8_t 			*dst[3] = {rgb_buffer};
	const int 			dstStride[3] = {width*2};
	
	SwsContext* img_convert_ctx;
	img_convert_ctx = sws_getContext(width, height, AV_PIX_FMT_NV21, width,
										height, AV_PIX_FMT_RGB565, SWS_BICUBIC, NULL, NULL, NULL);
	sws_scale(img_convert_ctx, src, srcStride, 0, height, dst, dstStride);
	sws_freeContext(img_convert_ctx);
	
	return 0;
	
#endif
}

int convert_i420_to_rgb565(unsigned char* const i420_buffer, unsigned char* rgb_buffer, int width, int height, int blur)
{
#ifdef USING__ARCSOFT_PP

	int res = MOK;
	MPAFPIXEL PixelSrc = {0}, PixelDst = {0};
	MByte *ppSrc[MPP_MAX_PLANES] = {0};
	MInt32 lSrcPitch[MPP_MAX_PLANES] = {0};
	MByte *ppDst[MPP_MAX_PLANES] = {0};
	MInt32 lDstPitch[MPP_MAX_PLANES] = {0};
	MBLITFX mblitfx = {0};
	MHandle	pphandle;
	
	PixelSrc.dwHeight  = height;
	PixelSrc.dwWidth   = width;
	PixelSrc.dwSpaceID = MPAF_I420 | MPAF_BT601_YCBCR;
	
	PixelDst.dwHeight  = height;
	PixelDst.dwWidth   = width;
	PixelDst.dwSpaceID = MPAF_RGB16_R5G6B5;

	mblitfx.dwDirection       = 0;
	mblitfx.dwReSizeAlg       = MPP_RESIZE_NEAREST_NEIGHBOUR;//MPP_RESIZE_BILINEAR;
	
	mblitfx.dwAspectRatio     = 0;//MPP_ASPECT_RATIO_FIT_OUT;
	mblitfx.dwProcessorType   = 0;
	mblitfx.dwPerformanceMode = MPP_PERFORMANCE_AUTO;
	mblitfx.dwDither          = 0;
	mblitfx.dwAlpha           = 255;
	
	res = MPPCreate(&PixelDst, &PixelSrc, &mblitfx, &pphandle);
 	log("convert_i420_to_rgb565 MPPCreate res = %d" , res);
	if (res != MOK)
	{
		return res;
	}
	
	lSrcPitch[0] = width;
	lSrcPitch[1] = lSrcPitch[0]>>1;
	lSrcPitch[2] = lSrcPitch[0]>>1;
	
	lDstPitch[0] = width<<1;
	lDstPitch[1] = 0;
	lDstPitch[2] = 0;
	
	ppSrc[0] = i420_buffer;
	ppSrc[1] = ppSrc[0] + width*height;
	ppSrc[2] = ppSrc[1] + (width*height>>2);
	
	ppDst[0] = rgb_buffer;
	ppDst[1] = 0;
	ppDst[2] = 0;
	
	
	res = MPProcess(pphandle, ppDst, MNull, lDstPitch, ppSrc, lSrcPitch);
	log("convert_i420_to_rgb565 MPProcessres = %d" , res);
	if (pphandle)
	{
		MPPDestroy(pphandle);
	}
	log("convert_i420_to_rgb565 out");
	return res;
	
#else
	
not using swscale now

	if(blur)
	{
		//opencv_gaussian_blur(nv21_buffer, width, height);
	}
	
	int y_size = width*height;
	uint8_t 			*const src[3] = {nv21_buffer, nv21_buffer+y_size};
	const int 			srcStride[3] = {width, width};
	
	uint8_t 			*dst[3] = {rgb_buffer};
	const int 			dstStride[3] = {width*2};
	
	SwsContext* img_convert_ctx;
	img_convert_ctx = sws_getContext(width, height, AV_PIX_FMT_NV21, width,
										height, AV_PIX_FMT_RGB565, SWS_BICUBIC, NULL, NULL, NULL);
	sws_scale(img_convert_ctx, src, srcStride, 0, height, dst, dstStride);
	sws_freeContext(img_convert_ctx);
	
	return 0;
	
#endif
}