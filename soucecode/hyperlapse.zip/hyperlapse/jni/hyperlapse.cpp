#include <stdexcept>

#include "hyperlapse.h"
#include "ml_time.h"

#ifndef mllog
#include <android/log.h>
#undef log(...)
#define log(...) __android_log_print(ANDROID_LOG_ERROR, "mmmlll hyperlapse", __VA_ARGS__)
#else
#ifndef mlllog
#define mlllog
#define log(...)
#endif
#endif

const int MEM_SIZE = 500 * 1024 * 1024;

Hyperlapse::Hyperlapse(LPINIT_PARAM param)
{
	MLTIME t("AHPLP_Init");
	MRESULT ret = MOK;
	pMem = (MByte *)MMemAlloc(MNull, MEM_SIZE);
	if(!pMem)
	{
		ret = MERR_NO_MEMORY;
		goto exit;
	}
	
	ret = AHPLP_Init(pMem, MEM_SIZE, param, &hEngine);
	if((MOK != ret) || (hEngine == NULL))
		goto exit;
	
	hplpParam = {0};
	
exit:
	if(ret != MOK)
	{
		MMemFree(MNull, pMem);
		throw std::runtime_error("Hyperlapse::Hyperlapse(LPINIT_PARAM param)");
	}
}

Hyperlapse::~Hyperlapse()
{
	MLTIME t("AHPLP_Uninit");
	if(hEngine)
		AHPLP_Uninit(&hEngine);
	if(pMem)
		MMemFree(MNull, pMem);
}

MRESULT Hyperlapse::AddFrame(LPASVLOFFSCREEN pSrcImg)
{
	if(pSrcImg == NULL)
		return -1;
	
	MRESULT ret = MOK;
	MLTIME t("AHPLP_AddFrame");
	ret = AHPLP_AddFrame(hEngine, pSrcImg);
	return ret;
}

MRESULT Hyperlapse::Preprocess(void)
{
	MRESULT ret = MOK;
	MLTIME t("AHPLP_Preprocess");
	ret = AHPLP_Preprocess(hEngine);
	return ret;
}

MRESULT Hyperlapse::ResetParam(LPHPLP_PARAM pParam)
{
	if(pParam == NULL)
		return -1;
	MRESULT ret = MOK;
	MLTIME t("AHPLP_ResetHyperlapse");
	ret = AHPLP_ResetHyperlapse(hEngine, pParam);
	
	return ret;
}

MRESULT Hyperlapse::GetFrameList(LPFRAME_LIST pList, MInt32 lSpeed)
{
	if((lSpeed !=0) && (lSpeed == hplpParam.lSpeed))
	{
		log("speed is the same with last time, return");
		return -1;
	}
	
	MRESULT ret = MOK;
	MLTIME t("AHPLP_GetFrameList");
	log("Hyperlapse::GetFrameList AHPLP_GetFrameList hEngine :%p, lSpeed :%d, pList :%p", hEngine, (int)lSpeed, pList);
	ret = AHPLP_GetFrameList(hEngine, lSpeed, pList);
	log("Hyperlapse::GetFrameList AHPLP_GetFrameList hEngine :%p, ret :%ld, lSpeed :%d, pList :%p", hEngine, ret, (int)lSpeed, pList);
	
	if(ret == MOK)
	{
		hplpParam.lSpeed = lSpeed;
	}

	return ret;
}

MRESULT Hyperlapse::DoHyperlapse(MInt32 lFrameNo, LPASVLOFFSCREEN pSrcImg, LPASVLOFFSCREEN pDstImg)
{
	if((pSrcImg == nullptr) || (pDstImg == nullptr))
	{
		log("spSrcImg or pDstImg is null");
		return -1;
	}
	
	MRESULT ret = MOK;
	MLTIME t("AHPLP_DoHyperlapse");
	ret = AHPLP_DoHyperlapse(hEngine, lFrameNo, pSrcImg, pDstImg);
	
	return ret;
}



