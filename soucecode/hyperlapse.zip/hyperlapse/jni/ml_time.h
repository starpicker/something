#ifndef MALEIISHANDSOME_H
#define MALEIISHANDSOME_H

#include <sys/time.h> 

#ifndef mllog
#include <android/log.h>
#define log(...) __android_log_print(ANDROID_LOG_ERROR, "mmmlll", __VA_ARGS__)
#else
#ifndef mlllog
#define mlllog
#define log(...)
#endif
#endif

struct MLTIME {
		MLTIME(const char* l = nullptr):label(l)
		{
			gettimeofday(&t_start, NULL);
		}
		
		~MLTIME()
		{
			gettimeofday(&t_end, NULL);
			long time_diff = (t_end.tv_sec - t_start.tv_sec)*1000 + (t_end.tv_usec - t_start.tv_usec)/1000;
			log("%s cost time is %ldms", label, time_diff);
		}
private:
		MLTIME operator =(const MLTIME&);
		
private:
	struct timeval t_start;
	struct timeval t_end;
	const char* label;
};

#define T MLTIME t = __func__;
	
#endif //MALEIISHANDSOME_H