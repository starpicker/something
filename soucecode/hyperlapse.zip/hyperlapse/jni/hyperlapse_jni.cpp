#include <jni.h>

#include <cstring>
#include <cstdio>

#include <android/bitmap.h>

#include "arcsoft_hyperlapse.h"
#include "hyperlapse.h"
#include "hyperlapse_jni_accom.h"

#ifndef mllog
#include <android/log.h>
#define log(...) __android_log_print(ANDROID_LOG_ERROR, "mmmlll", __VA_ARGS__)
#else
#ifndef mlllog
#define mlllog
#define log(...)
#endif
#endif

#include "ml_time.h"

JNIEXPORT jlong native_initHyperlapse(JNIEnv * env, jobject obj, jfloat trimRatio, jint inputFormat)
{
	log("test 3s crash %s", __func__);
	int format = (inputFormat == MHLAL::NV21)?ASVL_PAF_NV21:ASVL_PAF_I420;
	
	if(format == ASVL_PAF_NV21)
		log("format is nv21");
	if(format == ASVL_PAF_I420)
		log("format is i420");
	
	INIT_PARAM param = {trimRatio, (MUInt32)format};
	intptr_t e =  (intptr_t) (new MHLAL(&param));
	
	((MHLAL*)e)->format = (MHLAL::RAW_FORMAT)inputFormat;
	
	log("native_initHyperlapse engine :%p", (void*)e);
	log("test 3s crash %s out", __func__);
	return e;
}

JNIEXPORT jint native_uninitHyperlapse(JNIEnv * env, jobject obj, jlong engine)
{
	log("test 3s crash %s", __func__);
	if(engine == 0)
		return -1;

	delete (MHLAL*)engine;
	log("test 3s crash %s out", __func__);
	return 0;
}

JNIEXPORT jint native_loadSrcDataAndPreprocess(JNIEnv * env, jobject obj, jlong engine)
{
	T
	log("test 3s crash %s", __func__);
	if(engine == 0)
		return -1;
	
	MHLAL* e = (MHLAL*)engine;
	log("native_loadSrcDataAndPreprocess e->format ：%d, MHLAL::NV21 :%d, MHLAL::I420 :%d", e->format, MHLAL::NV21, MHLAL::I420);
	
	if((e->format != MHLAL::NV21) && (e->format != MHLAL::I420))
	{
		log("native_loadSrcDataAndPreprocess only support nv21 and i420, exit");
		return -1;
	}
	
	int ret = 0;
	char raw_data_file_path[MHLAL_MAX_PATH_LEN];
	
	log("engine :%p, total_frame_num :%d", (void*)e, e->total_frame_num);
	
	int width = e->width;
	int height = e->height;
	
	ASVLOFFSCREEN img = {0};
	img.ppu8Plane[0] = (unsigned char*) malloc(e->width*e->height*3>>1);
	if(img.ppu8Plane[0] == NULL)
	{
		return -1;
	}
	
	if(e->format == MHLAL::NV21)
	{
		img.u32PixelArrayFormat = ASVL_PAF_NV21;
		img.i32Width            = width;
		img.i32Height           = height;
		img.ppu8Plane[1]        = img.ppu8Plane[0] + img.i32Width*img.i32Height;
		img.pi32Pitch[0]        = img.i32Width;
		img.pi32Pitch[1]        = img.i32Width;
	}

	if(e->format == MHLAL::I420)
	{
		img.u32PixelArrayFormat = ASVL_PAF_I420;
		img.i32Width            = width;
		img.i32Height           = height;
		img.ppu8Plane[1]        = img.ppu8Plane[0] + img.i32Width*img.i32Height;
		img.ppu8Plane[2]        = img.ppu8Plane[1] + (img.i32Width*img.i32Height>>2);
		img.pi32Pitch[0]        = img.i32Width;
		img.pi32Pitch[1]        = img.i32Width>>1;
		img.pi32Pitch[2]        = img.i32Width>>1;
	}
		
	FILE* fp = nullptr;
	
	for(int i = 0; i < e->total_frame_num; i++)
	{
		if(e->format == MHLAL::NV21)
			sprintf(raw_data_file_path, "%s/%dx%d_%05d.nv21", e->raw_data_folder, e->width, e->height, i);
		if(e->format == MHLAL::I420)
			sprintf(raw_data_file_path, "%s/%dx%d_%05d.i420", e->raw_data_folder, e->width, e->height, i);
		
		fp = fopen(raw_data_file_path, "r");
		if(fp)
		{
			fread(img.ppu8Plane[0], width*height*3>>1, 1, fp);
			fclose(fp);
		}
		else
		{
			ret = -1;
			break;
		}
		
		ret = e->hls->AddFrame(&img);
		log("native_loadSrcDataAndPreprocess AddFrame ret :%d", ret);
		
		if(MOK != ret)
		{
			log("add frame fail");
			break;
		}
	}
	
	free(img.ppu8Plane[0]);
	
	if(ret != MOK)
		return ret;
	
	ret = e->hls->Preprocess();
	log("native_loadSrcDataAndPreprocess Preprocess ret :%d", ret);
	log("test 3s crash %s out", __func__);
	return ret;
}

JNIEXPORT jint native_resetHyperlapse(JNIEnv * env, jobject obj, jlong engine, jint speed)
{
	log("test 3s crash %s", __func__);
	if(engine == 0)
		return -1;
	
	int ret = 0;
	MHLAL* e = (MHLAL*)engine;
	
	HPLP_PARAM hplpParam = {0};
	hplpParam.lSpeed = speed;
	ret = e->hls->ResetParam(&hplpParam);
	log("native_resetHyperlapse ResetParam ret :%d, speed :%d", ret, speed);
	log("test 3s crash %s out", __func__);
	return ret;
}

JNIEXPORT jintArray native_getFrameList(JNIEnv * env, jobject obj, jlong engine, jint speed)
{
	log("test 3s crash %s", __func__);
	T
	if(engine == 0)
		return NULL;
	
	int ret = 0;
	MHLAL* e = (MHLAL*)engine;
	FRAME_LIST frame_list;
	
	log("native_getFrameList GetFrameList before");
	ret = e->hls->GetFrameList(&frame_list, speed);
	log("native_getFrameList GetFrameList ret :%d, speed :%d", ret, speed);
	
	log("native_getFrameList GetFrameList frame_list.lFrameSize :%d", (int)(frame_list.lFrameSize));
	
	for(int i = 0; i < frame_list.lFrameSize; i++)
		log("frame_list.pFrameList[%d] :%d", i, (int)((frame_list.pFrameList)[i]));
	
	if((ret == MOK) && (frame_list.lFrameSize != 0))
	{
		log("place 1");
		jintArray arr = env->NewIntArray(frame_list.lFrameSize);
		log("place 2");
		env->SetIntArrayRegion(arr, 0, frame_list.lFrameSize, (jint*)(frame_list.pFrameList));
		log("place 3");
		//env->DeleteLocalRef(arr);
		log("place 4");
		return arr;
	}
	log("test 3s crash %s out", __func__);
	return NULL;
}

JNIEXPORT jint native_getFrameAccordingIndex(JNIEnv * env, jobject obj, jlong engine, jobject jbitmap, jint index)
{
	log("test 3s crash %s", __func__);
	T
	if(engine == 0)
		return -1;
	
	int ret = 0;
	MHLAL* e = (MHLAL*)engine;
	
	if((e->format != MHLAL::NV21) && (e->format != MHLAL::I420))
		return -1;
	
	int width = e->width;
	int height = e->height;
	
	ASVLOFFSCREEN imgSrc = {0};
	ASVLOFFSCREEN imgOut = {0};
	//alloc memory for imgSrc imgOut
	{
		if(e->format == MHLAL::NV21)
		{
			imgSrc.u32PixelArrayFormat = ASVL_PAF_NV21;
			imgSrc.i32Width            = width;
			imgSrc.i32Height           = height;
			imgSrc.ppu8Plane[0]        = (unsigned char*) malloc(width*height*3>>1);
			imgSrc.ppu8Plane[1]        = imgSrc.ppu8Plane[0] + imgSrc.i32Width*imgSrc.i32Height;
			imgSrc.pi32Pitch[0]        = imgSrc.i32Width;
			imgSrc.pi32Pitch[1]        = imgSrc.i32Width;
			
			imgOut.u32PixelArrayFormat = ASVL_PAF_NV21;
			imgOut.i32Width            = width;
			imgOut.i32Height           = height;
			imgOut.ppu8Plane[0]        = (unsigned char*) malloc(width*height*3>>1);
			imgOut.ppu8Plane[1]        = imgOut.ppu8Plane[0] + imgOut.i32Width*imgOut.i32Height;
			imgOut.pi32Pitch[0]        = imgOut.i32Width;
			imgOut.pi32Pitch[1]        = imgOut.i32Width;
		}
		
		if(e->format == MHLAL::I420)
		{
			imgSrc.u32PixelArrayFormat = ASVL_PAF_I420;
			imgSrc.i32Width            = width;
			imgSrc.i32Height           = height;
			imgSrc.ppu8Plane[0]        = (unsigned char*) malloc(width*height*3>>1);
			imgSrc.ppu8Plane[1]        = imgSrc.ppu8Plane[0] + imgSrc.i32Width*imgSrc.i32Height;
			imgSrc.ppu8Plane[2]        = imgSrc.ppu8Plane[1] + (imgSrc.i32Width*imgSrc.i32Height>>2);
			imgSrc.pi32Pitch[0]        = imgSrc.i32Width;
			imgSrc.pi32Pitch[1]        = imgSrc.i32Width>>1;
			imgSrc.pi32Pitch[2]        = imgSrc.i32Width>>1;
			
			imgOut.u32PixelArrayFormat = ASVL_PAF_I420;
			imgOut.i32Width            = width;
			imgOut.i32Height           = height;
			imgOut.ppu8Plane[0]        = (unsigned char*) malloc(width*height*3>>1);
			imgOut.ppu8Plane[1]        = imgOut.ppu8Plane[0] + imgOut.i32Width*imgOut.i32Height;
			imgOut.ppu8Plane[2]        = imgOut.ppu8Plane[1] + (imgOut.i32Width*imgOut.i32Height>>2);
			imgOut.pi32Pitch[0]        = imgOut.i32Width;
			imgOut.pi32Pitch[1]        = imgOut.i32Width>>1;
			imgOut.pi32Pitch[2]        = imgOut.i32Width>>1;
		}
		
	}
	
	//read raw into imgSrc imgOut
	{
		char raw_data_file_path[MHLAL_MAX_PATH_LEN];
		if(e->format == MHLAL::NV21)
			sprintf(raw_data_file_path, "%s/%dx%d_%05d.nv21", e->raw_data_folder, width, height, index);
		if(e->format == MHLAL::I420)
			sprintf(raw_data_file_path, "%s/%dx%d_%05d.i420", e->raw_data_folder, width, height, index);
		
		auto p = new MLTIME("read raw data");
		FILE* fp = fopen(raw_data_file_path, "r");
		fread(imgSrc.ppu8Plane[0], width*height*3>>1, 1, fp);
		fclose(fp);
		delete p;
	}
	
	//algorithem
	{
		auto p = new MLTIME("DoHyperlapse");
		ret = e->hls->DoHyperlapse(index, &imgSrc, &imgOut);
		delete p;
		log("native_getFrameAccordingIndex DoHyperlapse ret :%d", ret);
	}
	
	auto p = new MLTIME("offscreen_to_jbitmap");
	ret = MHLAL::offscreen_to_jbitmap(env, jbitmap, &imgOut);
	delete p;
	
	//free imgSrc imgOut
	{
		free(imgSrc.ppu8Plane[0]);
		free(imgOut.ppu8Plane[0]);
	}
	log("test 3s crash %s out", __func__);
	return ret;
}

JNIEXPORT jint native_setParamaterForDecode(JNIEnv * env, jobject obj, jlong engine, jstring mp4_path, jstring raw_data_folder)
{
	log("test 3s crash %s", __func__);
	if(engine == 0)
		return -1;
	
	MHLAL* e = (MHLAL*)engine;
	
	int ret = 0;
	//char* mp4 = MHLAL::jstringTostring(env, mp4_path);
	//char* raw_folder = MHLAL::jstringTostring(env, raw_data_folder);

	//memcpy(e->mp4_path, mp4, strlen(mp4)+1);
	//memcpy(e->raw_data_folder, raw_folder, strlen(raw_folder)+1);

	auto mp4 = MHLAL::jstringTostring(env, mp4_path);
	auto raw_folder = MHLAL::jstringTostring(env, raw_data_folder);
	
	memcpy(e->mp4_path, &mp4[0], strlen(&mp4[0])+1);
	memcpy(e->raw_data_folder, &raw_folder[0], strlen(&raw_folder[0])+1);
	
	ret = MHLAL::decode_video_to_raw_data_folder(e->mp4_path, e->raw_data_folder, &(e->width), &(e->height), &(e->duration));
	log("native_setParamaterForDecode decode_video_to_raw_data_folder ret :%d", ret);

	//free(mp4);
	//free(raw_folder);
	log("test 3s crash %s out", __func__);
	return ret;
}

JNIEXPORT jint native_getVideoWidth(JNIEnv * env, jobject obj, jlong engine)
{
	log("test 3s crash %s", __func__);
	if(engine == 0)
		return -1;
	
	MHLAL* e = (MHLAL*)engine;
	log("test 3s crash %s out", __func__);
	return e->width;
}

JNIEXPORT jint native_getVideoHeight(JNIEnv * env, jobject obj, jlong engine)
{
	log("test 3s crash %s", __func__);
	if(engine == 0)
		return -1;
	
	MHLAL* e = (MHLAL*)engine;
	log("test 3s crash %s out", __func__);
	return e->height;
}

JNIEXPORT jint native_startDecode(JNIEnv * env, jobject obj, jlong engine)
{
	log("test 3s crash %s", __func__);
	if(engine == 0)
		return -1;

	int ret = 0;
	MHLAL* e = (MHLAL*)engine;
	
	jclass cls = env->GetObjectClass(obj);   
	jmethodID callback = env->GetMethodID(cls,"onNotify","(I)V");
	
	log("native_startDecode e->format is %d", e->format);
	ret = MHLAL::decode_video_to_raw_data_folder(e->mp4_path, e->raw_data_folder, nullptr, nullptr, nullptr, &(e->total_frame_num), /*MHLAL::NV21*/e->format, env, obj, callback, e);
	log("native_startDecode decode_video_to_raw_data_folder ret :%d", ret);
	log("test 3s crash %s out", __func__);
	return ret;
}

JNIEXPORT jint native_getBitmapForPlay(JNIEnv * env, jobject obj, jlong engine, jobject jbitmap, jint index, jint blurflag)
{
	log("test 3s crash %s", __func__);
	T
	if(engine == 0)
		return -1;
	
	int ret = 0;
	MHLAL* e = (MHLAL*)engine;
	
	if((e->format != MHLAL::NV21) && (e->format != MHLAL::I420))
		return -1;
	
	int width = e->width;
	int height = e->height;
	
	ASVLOFFSCREEN img = {0};
	//alloc memory for offscreen
	{
		if(e->format == MHLAL::NV21)
		{
			img.u32PixelArrayFormat = ASVL_PAF_NV21;
			img.i32Width            = width;
			img.i32Height           = height;
			img.ppu8Plane[0]        = (unsigned char*) malloc(width*height*3>>1);
			img.ppu8Plane[1]        = img.ppu8Plane[0] + img.i32Width*img.i32Height;
			img.pi32Pitch[0]        = img.i32Width;
			img.pi32Pitch[1]        = img.i32Width;
		}
		
		if(e->format == MHLAL::I420)
		{
			img.u32PixelArrayFormat = ASVL_PAF_I420;
			img.i32Width            = width;
			img.i32Height           = height;
			img.ppu8Plane[0]        = (unsigned char*) malloc(width*height*3>>1);
			img.ppu8Plane[1]        = img.ppu8Plane[0] + img.i32Width*img.i32Height;
			img.ppu8Plane[2]        = img.ppu8Plane[1] + (img.i32Width*img.i32Height>>2);
			img.pi32Pitch[0]        = img.i32Width;
			img.pi32Pitch[1]        = img.i32Width>>1;
			img.pi32Pitch[2]        = img.i32Width>>1;
		}
		
	}
	
	//read raw into imgSrc imgOut
	{
		char raw_data_file_path[MHLAL_MAX_PATH_LEN];
		if(e->format == MHLAL::NV21)
			sprintf(raw_data_file_path, "%s/%dx%d_%05d.nv21", e->raw_data_folder, width, height, index);
		if(e->format == MHLAL::I420)
			sprintf(raw_data_file_path, "%s/%dx%d_%05d.i420", e->raw_data_folder, width, height, index);
		
		auto p = new MLTIME("read raw data");
		FILE* fp = fopen(raw_data_file_path, "r");
		fread(img.ppu8Plane[0], width*height*3>>1, 1, fp);
		fclose(fp);
		delete p;
	}
	
	auto p = new MLTIME("offscreen_to_jbitmap");
	ret = MHLAL::offscreen_to_jbitmap(env, jbitmap, &img, blurflag);
	delete p;
	log("native_getBitmapForPlay offscreen_to_jbitmap ret :%d", ret);
	
	//free offscreen
	{
		free(img.ppu8Plane[0]);
	}
	log("test 3s crash %s out", __func__);
	return ret;
}

JNIEXPORT jint native_getRawDatabyte(JNIEnv * env, jobject obj, jlong engine, jbyteArray rawDataByteArray, jint index)
{
	log("test 3s crash %s", __func__);
	T
	
	if(engine == 0)
		return -1;
	int ret = 0;
	MHLAL* e = (MHLAL*)engine;
	
	if((e->format != MHLAL::NV21) && (e->format != MHLAL::I420))
		return -1;
	
	int width = e->width;
	int height = e->height;
	
	//jsize len = env->GetArrayLength(rawDataByteArray);
	jboolean iscopy = 0;
	jbyte* rawData  = env->GetByteArrayElements(rawDataByteArray, &iscopy);
	
	ASVLOFFSCREEN imgSrc = {0};
	ASVLOFFSCREEN imgOut = {0};
	
	//alloc memory for imgSrc imgOut
	{
		if(e->format == MHLAL::NV21)
		{
			imgSrc.u32PixelArrayFormat = ASVL_PAF_NV21;
			imgSrc.i32Width            = width;
			imgSrc.i32Height           = height;
			imgSrc.ppu8Plane[0]        = (unsigned char*) malloc(width*height*3>>1);
			imgSrc.ppu8Plane[1]        = imgSrc.ppu8Plane[0] + imgSrc.i32Width*imgSrc.i32Height;
			imgSrc.pi32Pitch[0]        = imgSrc.i32Width;
			imgSrc.pi32Pitch[1]        = imgSrc.i32Width;
			
			imgOut.u32PixelArrayFormat = ASVL_PAF_NV21;
			imgOut.i32Width            = width;
			imgOut.i32Height           = height;
			imgOut.ppu8Plane[0]        = (unsigned char*) rawData;
			imgOut.ppu8Plane[1]        = imgOut.ppu8Plane[0] + imgOut.i32Width*imgOut.i32Height;
			imgOut.pi32Pitch[0]        = imgOut.i32Width;
			imgOut.pi32Pitch[1]        = imgOut.i32Width;
		}
		
		if(e->format == MHLAL::I420)
		{
			imgSrc.u32PixelArrayFormat = ASVL_PAF_I420;
			imgSrc.i32Width            = width;
			imgSrc.i32Height           = height;
			imgSrc.ppu8Plane[0]        = (unsigned char*) malloc(width*height*3>>1);
			imgSrc.ppu8Plane[1]        = imgSrc.ppu8Plane[0] + imgSrc.i32Width*imgSrc.i32Height;
			imgSrc.ppu8Plane[2]        = imgSrc.ppu8Plane[1] + (imgSrc.i32Width*imgSrc.i32Height>>2);
			imgSrc.pi32Pitch[0]        = imgSrc.i32Width;
			imgSrc.pi32Pitch[1]        = imgSrc.i32Width>>1;
			imgSrc.pi32Pitch[2]        = imgSrc.i32Width>>1;
			
			imgOut.u32PixelArrayFormat = ASVL_PAF_I420;
			imgOut.i32Width            = width;
			imgOut.i32Height           = height;
			imgOut.ppu8Plane[0]        = (unsigned char*) rawData;
			imgOut.ppu8Plane[1]        = imgOut.ppu8Plane[0] + imgOut.i32Width*imgOut.i32Height;
			imgOut.ppu8Plane[2]        = imgOut.ppu8Plane[1] + (imgOut.i32Width*imgOut.i32Height>>2);
			imgOut.pi32Pitch[0]        = imgOut.i32Width;
			imgOut.pi32Pitch[1]        = imgOut.i32Width>>1;
			imgOut.pi32Pitch[2]        = imgOut.i32Width>>1;
		}
		
	}
	
	//read data into imgSrc
	{
		char raw_data_file_path[MHLAL_MAX_PATH_LEN];
		if(e->format == MHLAL::NV21)
			sprintf(raw_data_file_path, "%s/%dx%d_%05d.nv21", e->raw_data_folder, width, height, index);
		if(e->format == MHLAL::I420)
			sprintf(raw_data_file_path, "%s/%dx%d_%05d.i420", e->raw_data_folder, width, height, index);
		
		auto p = new MLTIME("read raw data");
		FILE* fp = fopen(raw_data_file_path, "r");
		fread(imgSrc.ppu8Plane[0], width*height*3>>1, 1, fp);
		fclose(fp);
		delete p;
	}
	
	//algorithem
	{
		auto p = new MLTIME("DoHyperlapse");
		ret = e->hls->DoHyperlapse(index, &imgSrc, &imgOut);
		delete p;
		//yujian need test encode
		//memcpy(rawData, imgSrc.ppu8Plane[0], width*height*3>>1);
		//log("just copy the data");
		
		log("native_getRawDatabyte DoHyperlapse ret :%d", ret);
	}
	
	env->ReleaseByteArrayElements(rawDataByteArray, rawData, 0);
	free(imgSrc.ppu8Plane[0]);
	log("test 3s crash %s out", __func__);
	return ret;
}

JNIEXPORT jint native_getVideoDuration(JNIEnv * env, jobject obj, jlong engine)
{
	log("test 3s crash %s", __func__);
	if(engine == 0)
		return -1;
	
	MHLAL* e = (MHLAL*)engine;
	log("test 3s crash %s out", __func__);
	return e->duration;
}

JNIEXPORT jint native_getVideoFrameSum(JNIEnv * env, jobject obj, jlong engine)
{
	if(engine == 0)
		return -1;
	
	MHLAL* e = (MHLAL*)engine;
	log("test 3s crash %s out", __func__);
	return e->total_frame_num;
}

JNIEXPORT jint native_getFirstFrameForShow(JNIEnv * env, jobject obj, jlong engine, jobject jbitmap, jint blurflag)
{
	log("test 3s crash %s", __func__);
	T
	if(engine == 0)
		return -1;
	
	int ret = 0;
	MHLAL* e = (MHLAL*)engine;
	AndroidBitmapInfo info;
    void* addr;
	MHLAL::RGB_FORMAT rgb_pix_fmt = MHLAL::RGB_UNKNOWN;
	int raw_data_len;
	unsigned char* raw_buffer = NULL;
	int width;
	int height;
	
	ret = AndroidBitmap_getInfo(env, jbitmap, &info);
    if(ret != 0)
    {
		goto exit;
    }
	
	width = info.width;
	height = info.height;
	
	if((e->width != width) || (e->height != height))
	{
		log("width and height is not same, exit now, may pp later");
		goto exit;
	}
	
    switch(info.format)
    {
		case ANDROID_BITMAP_FORMAT_RGB_565:
			rgb_pix_fmt = MHLAL::RGB565;
			raw_data_len = width*height<<1;
			raw_buffer = (unsigned char*) malloc(raw_data_len);
            break;
        case ANDROID_BITMAP_FORMAT_RGBA_8888:
            rgb_pix_fmt = MHLAL::RGBA8888;
			raw_data_len = width*height<<2;
			raw_buffer = (unsigned char*) malloc(raw_data_len);
            break;

    }

    if(rgb_pix_fmt == MHLAL::RGB_UNKNOWN)
    {
        goto exit;
    }
	
	if(raw_buffer == NULL)
	{
		goto exit;
	}
	
	ret = MHLAL::decode_video_to_get_first_frame(e->mp4_path, raw_buffer, width, height, rgb_pix_fmt, blurflag);
	if(ret != 0)
    {
		goto exit;
    }
	
    ret = AndroidBitmap_lockPixels(env, jbitmap, &addr);
    if(ret != 0)
    {
		goto exit;
    }
	
	if(rgb_pix_fmt == MHLAL::RGB565)
	{
		memcpy(addr, raw_buffer, raw_data_len);
	}
	
	if(rgb_pix_fmt == MHLAL::RGBA8888)
	{
        for(int i = 0; i < width * height; i += 4)
        {
            ((unsigned char*)addr)[i] 	= raw_buffer[i + 2];
            ((unsigned char*)addr)[i + 1] = raw_buffer[i + 1];
            ((unsigned char*)addr)[i + 2] = raw_buffer[i]    ;
            ((unsigned char*)addr)[i + 3] = raw_buffer[i + 3];
        }
	}
	
	AndroidBitmap_unlockPixels(env,jbitmap);

exit:
	free(raw_buffer);
	log("test 3s crash %s out", __func__);
    return ret;
}

const char* const Java_class = "com/example/hyperlapse/engine/HyperlapseEngine";

static JNINativeMethod gMethods[] = {
    {"native_initHyperlapse", "(FI)J", (void*)native_initHyperlapse},
    {"native_uninitHyperlapse", "(J)I", (void*)native_uninitHyperlapse},
    {"native_loadSrcDataAndPreprocess", "(J)I", (void*)native_loadSrcDataAndPreprocess},
    {"native_resetHyperlapse", "(JI)I", (void*)native_resetHyperlapse},
    {"native_getFrameList", "(JI)[I", (void*)native_getFrameList},
    {"native_getFrameAccordingIndex", "(JLandroid/graphics/Bitmap;I)I", (void*)native_getFrameAccordingIndex},
    {"native_setParamaterForDecode","(JLjava/lang/String;Ljava/lang/String;)I", (void*)native_setParamaterForDecode},
    {"native_getVideoWidth", "(J)I", (void*)native_getVideoWidth},
    {"native_getVideoHeight", "(J)I", (void*)native_getVideoHeight},
    {"native_startDecode", "(J)I", (void*)native_startDecode},
    {"native_getBitmapForPlay", "(JLandroid/graphics/Bitmap;II)I", (void*)native_getBitmapForPlay},
    {"native_getRawDatabyte", "(J[BI)I", (void*)native_getRawDatabyte},
	{"native_getVideoDuration", "(J)I", (void*)native_getVideoDuration},
	{"native_getFirstFrameForShow", "(JLandroid/graphics/Bitmap;I)I", (void*)native_getFirstFrameForShow},
	{"native_getVideoFrameSum", "(J)I", (void*)native_getVideoFrameSum},
	
};

static int RegisterNativeMethods(JNIEnv* env, const char* className,
        JNINativeMethod* gMethods, int numMethods)
{
    jclass clazz;
    clazz = env->FindClass(className);
    if (clazz == MNull)
    {
        return JNI_FALSE;
    }
    if (env->RegisterNatives(clazz, gMethods, numMethods) < 0)
    {
        return JNI_FALSE;
    }
    return JNI_TRUE;
}

static void UnregisterNativeMethods(JNIEnv* env, const char* className)
{
    jclass clazz;
    clazz = env->FindClass(className);

    if (clazz == MNull)
        return;

    if (MNull != env)
    {
        env->UnregisterNatives(clazz);
    }
}

JNIEXPORT jint JNICALL JNI_OnLoad(JavaVM* vm, void* reserved)
{
    JNIEnv* env = NULL;

    if (vm->GetEnv((void**) &env, JNI_VERSION_1_4) != JNI_OK)
    {
        return -1;
    }

    jint ret = RegisterNativeMethods(env, Java_class, gMethods,
            sizeof(gMethods) / sizeof(gMethods[0]));
    if (ret != JNI_TRUE)
    {
        return -1;
    }
    return JNI_VERSION_1_4;
}

JNIEXPORT void JNICALL JNI_OnUnload(JavaVM* vm, void* reserved)
{
    JNIEnv* env = MNull;
    if (vm->GetEnv((void**) &env, JNI_VERSION_1_4) != JNI_OK)
        return;

    UnregisterNativeMethods(env, Java_class);
}