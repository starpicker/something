#ifndef HYPERLAPSE_H_
#define HYPERLAPSE_H_

#include "ammem.h"
#include "arcsoft_hyperlapse.h"

class Hyperlapse{
	
	public:
		Hyperlapse(LPINIT_PARAM param);
		~Hyperlapse();

		MRESULT AddFrame(LPASVLOFFSCREEN pSrcImg);
		MRESULT Preprocess(void);
		MRESULT ResetParam(LPHPLP_PARAM pParam);
		MRESULT GetFrameList(LPFRAME_LIST pList, MInt32 lSpeed = 0);
		MRESULT DoHyperlapse(MInt32 lFrameNo, LPASVLOFFSCREEN pSrcImg, LPASVLOFFSCREEN pDstImg);
		
	private:
		Hyperlapse(const Hyperlapse&);
		Hyperlapse operator =(const Hyperlapse&);
		MRESULT SetSensorData(MInt32 iSensorMode, MFloat pfData[], MDouble fTimeStamp);
		
	private:
		MHandle hEngine;
		MByte *pMem;
		HPLP_PARAM hplpParam;
};



































#endif //HYPERLAPSE_H_