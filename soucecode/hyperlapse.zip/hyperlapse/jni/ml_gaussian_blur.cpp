#include <string.h>
#include <cmath>

static void
gauss_rle (unsigned char* rgb24, 
		   unsigned char* rgb24_blur,
		   int          width_in,
           int          height_in,
		   int          bpp_in = 3,
		   int          has_alpha_in = 0,
           double       horz = 50.0,
           double       vert = 50.0);

#define UpAlign4(n) (((n) + 3) & ~3)

static int rgb565_to_rgb888(const void * psrc, int w, int h, void * pdst)  
{  
    int srclinesize = UpAlign4(w * 2);  
    int dstlinesize = UpAlign4(w * 3);  
  
    const unsigned char  * psrcline;  
    const unsigned short * psrcdot;  
    unsigned char  * pdstline;  
    unsigned char  * pdstdot;  
  
    int i,j;  
  
    if (!psrc || !pdst || w <= 0 || h <= 0) {
        return -1;  
    }  
  
    psrcline = (const unsigned char *)psrc;  
    pdstline = (unsigned char *)pdst;  
    for (i=0; i<h; i++) {  
        psrcdot = (const unsigned short *)psrcline;  
        pdstdot = pdstline;  
        for (j=0; j<w; j++) {  
            //565 b|g|r -> 888 r|g|b  
            *pdstdot++ = (unsigned char)(((*psrcdot) >> 0 ) << 3);  
            *pdstdot++ = (unsigned char)(((*psrcdot) >> 5 ) << 2);  
            *pdstdot++ = (unsigned char)(((*psrcdot) >> 11) << 3);  
            psrcdot++;  
        }  
        psrcline += srclinesize;  
        pdstline += dstlinesize;  
    }  
  
    return 0;  
}  
  
static int rgb888_to_rgb565(const void * psrc, int w, int h, void * pdst)  
{  
    int srclinesize = UpAlign4(w * 3);  
    int dstlinesize = UpAlign4(w * 2);  
      
    const unsigned char * psrcline;  
    const unsigned char * psrcdot;  
    unsigned char  * pdstline;  
    unsigned short * pdstdot;  
      
    int i,j;  
      
    if (!psrc || !pdst || w <= 0 || h <= 0) {  
        return -1;  
    }  
  
    psrcline = (const unsigned char *)psrc;  
    pdstline = (unsigned char *)pdst;  
    for (i=0; i<h; i++) {  
        psrcdot = psrcline;  
        pdstdot = (unsigned short *)pdstline;  
        for (j=0; j<w; j++) {  
            //888 r|g|b -> 565 b|g|r  
            *pdstdot =  (((psrcdot[0] >> 3) & 0x1F) << 0)//r  
                        |(((psrcdot[1] >> 2) & 0x3F) << 5)//g  
                        |(((psrcdot[2] >> 3) & 0x1F) << 11);//b  
            psrcdot += 3;  
            pdstdot++;  
        }  
        psrcline += srclinesize;  
        pdstline += dstlinesize;  
    }  
  
    return 0;  
}  

int ml_gaussian_blur_rgb565(unsigned char* input_output_data, int width, int height)
{
	int ret = 0;
	unsigned char* rgb24 = (unsigned char*) malloc(width*height*3);
	unsigned char* rgb24_blur = (unsigned char*) malloc(width*height*3);
	if(rgb24 == 0)
		return -1;
	if(rgb24_blur == 0)
		return -1;
	
	rgb565_to_rgb888(input_output_data, width, height, rgb24);
	
	//cut off gauss
	gauss_rle(rgb24, rgb24_blur, width, height);
		
	rgb888_to_rgb565(rgb24_blur, width, height, input_output_data);
	
	free(rgb24);
	free(rgb24_blur);
	return ret;
}

#if 0
+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
#endif

#ifndef MAX
#define MAX(a, b) ((a) > (b) ? (a) : (b))
#endif

#ifndef MIN
#define MIN(a, b) ((a) < (b) ? (a) : (b))
#endif

#define ROUND(x) ((int) ((x) + 0.5))

typedef struct {
  unsigned char *data;         
  void			*drawable;    
  unsigned int  bpp;          
  unsigned int  rowstride;    
  unsigned int  x, y;         
  unsigned int  w, h;         
  unsigned int  dirty : 1;    
  unsigned int  shadow : 1;   
  unsigned int  process_count;
} GimpPixelRgn;

void ml_get_col (unsigned char* whole_image, unsigned char* col_pixels_buff, int col, int bpp, int width, int height)
{
	int inc = bpp*width;
	int i = 0;
	whole_image += bpp*col;
	
	for(i=0;i<height;i++)
	{
		int b = 0;
		for (b = 0; b < 3; b++)
		{
			*col_pixels_buff++ = whole_image[b];
		}

		whole_image+= inc;
	}
}

void ml_set_col (unsigned char* whole_image, unsigned char* col_pixels_buff, int col, int bpp, int width, int height)
{
	int inc = bpp*width;
	int i = 0;
	whole_image += bpp*col;
	
	for(i=0;i<height;i++)
	{
		int b = 0;
		for (b = 0; b < 3; b++)
		{
			whole_image[b] = *col_pixels_buff++;
		}

		whole_image+= inc;
	}
}

void ml_get_row (unsigned char* whole_image, unsigned char* row_pixels_buff, int row, int bpp, int width, int height)
{
	int i = 0;
	whole_image += bpp*width*row;
	
	for(i=0;i<width*bpp;i++)
	{
		*row_pixels_buff++ = whole_image[i];
	}
}

void ml_set_row (unsigned char* whole_image, unsigned char* row_pixels_buff, int row, int bpp, int width, int height)
{
	int i = 0;
	whole_image += bpp*width*row;
	
	for(i=0;i<width*bpp;i++)
	{
		whole_image[i] = *row_pixels_buff++;
	}
}

static void
multiply_alpha (unsigned char *buf,
                int    width,
                int    bytes)
{
  int i, j;

  for (i = 0; i < width; i++, buf += bytes)
    {
      double alpha = buf[bytes - 1] * (1.0 / 255.0);

      for (j = 0; j < bytes - 1; j++)
        buf[j] = ROUND (buf[j] * alpha);
    }
}

static void
separate_alpha (unsigned char *buf,
                int    width,
                int    bytes)
{
  int i, j;

  for (i = 0; i < width; i++, buf += bytes)
    {
      unsigned char alpha = buf[bytes - 1];

      switch (alpha)
        {
        case 0:
        case 255:
          break;

        default:
          {
            double recip_alpha = 255.0 / alpha;

            for (j = 0; j < bytes - 1; j++)
              {
                int new_val = ROUND (buf[j] * recip_alpha);

                buf[j] = MIN (255, new_val);
              }
          }
          break;
        }
    }
}

static inline int
run_length_encode (const unsigned char *src,
                   int         *rle,
                   int         *pix,
                   int         dist,  /* distance between 2 src pixels */
                   int         width,
                   int         border,
                   int         pack)
{
  int last;
  int count = 0;
  int i     = width;
  int same  = 0;

  src += dist * (width - 1);

  if (pack)
    rle += width + border - 1;

  pix += width + border - 1;

  last  = *src;
  count = 0;

  /* the 'end' border */
  for (i = 0; i < border; i++)
    {
      count++;
      *pix--  = last;

      if (pack)
        *rle-- = count;
  }

  /* the real pixels */
  for (i = 0; i < width; i++)
    {
      int c = *src;
      src -= dist;

      if (pack && c==last)
        {
          count++;
          *pix-- = last;
          *rle-- = count;
          same++;
        }
      else
        {
          count   = 1;
          last    = c;
          *pix--  = last;

          if (pack)
            *rle-- = count;
        }
    }

  /* the start pixels */
  for (i = 0; i < border; i++)
    {
      count++;
      *pix-- = last;

      if (pack)
        *rle-- = count;
  }

  return same;
}

static void
do_encoded_lre (const int *enc,
                const int *src,
                unsigned char     *dest,
                int        width,
                int        length,
                int        dist,
                const int *curve,
                int        ctotal,
                const int *csum)
{
  int col;

  for (col = 0; col < width; col++, dest += dist)
    {
      const int *rpt;
      const int *pix;
      int        nb;
      int        s1;
      int        i;
      int        val   = ctotal / 2;
      int        start = - length;

      rpt = &enc[col + start];
      pix = &src[col + start];

      s1 = csum[start];
      nb = rpt[0];
      i  = start + nb;

      while (i <= length)
        {
          int s2 = csum[i];

          val += pix[0] * (s2-s1);
          s1 = s2;
          rpt = &rpt[nb];
          pix = &pix[nb];
          nb = rpt[0];
          i += nb;
        }

      val += pix[0] * (csum[length] - s1);

      val = val / ctotal;
      *dest = MIN (val, 255);
    }
}

static void
do_full_lre (const int *src,
             unsigned char     *dest,
             int        width,
             int        length,
             int        dist,
             const int *curve,
             int        ctotal)
{
  int col;

  for (col = 0; col < width; col++, dest += dist)
    {
      const int *x1;
      const int *x2;
      const int *c   = &curve[0];
      int        i;
      int        val = ctotal / 2;

      x1 = x2 = &src[col];

      /* The central point is a special case since it should only be
       * processed ONCE
       */

      val += x1[0] * c[0];

      c  += 1;
      x1 += 1;
      x2 -= 1;
      i   = length;

      /* Processing multiple points in a single iteration should be
       * faster but is not strictly required.
       * Some precise benchmarking will be needed to figure out
       * if this is really interesting.
       */
      while (i >= 8)
        {
          val += (x1[0] + x2[-0]) * c[0];
          val += (x1[1] + x2[-1]) * c[1];
          val += (x1[2] + x2[-2]) * c[2];
          val += (x1[3] + x2[-3]) * c[3];
          val += (x1[4] + x2[-4]) * c[4];
          val += (x1[5] + x2[-5]) * c[5];
          val += (x1[6] + x2[-6]) * c[6];
          val += (x1[7] + x2[-7]) * c[7];

          c  += 8;
          x1 += 8;
          x2 -= 8;
          i  -= 8;
        }

      while (i >= 4)
        {
          val += (x1[0] + x2[-0]) * c[0];
          val += (x1[1] + x2[-1]) * c[1];
          val += (x1[2] + x2[-2]) * c[2];
          val += (x1[3] + x2[-3]) * c[3];
          c  += 4;
          x1 += 4;
          x2 -= 4;
          i  -= 4;
        }

      /* Only that final loop is strictly required */

      while (i >= 1)
        {
          /* process the pixels at the distance i before and after the
           * central point. They must have the same coefficient
           */
          val += (x1[0] + x2[-0]) * c[0];
          c  += 1;
          x1 += 1;
          x2 -= 1;
          i  -= 1;
        }

      val = val / ctotal;
      *dest = MIN (val, 255);
    }
}

static void
make_rle_curve (double   sigma,
                int    **p_curve,
                int     *p_length,
                int    **p_sum,
                int     *p_total)
{
  const double  sigma2 = 2 * sigma * sigma;
  const double  l      = sqrt (-sigma2 * log (1.0 / 255.0));
  int           temp;
  int           i, n;
  int           length;
  int          *sum;
  int          *curve;

  n = ceil (l) * 2;
  if ((n % 2) == 0)
    n += 1;

  curve = (int*) malloc (n * sizeof(int));

  length = n / 2;
  curve += length; /* 'center' the curve[] */
  curve[0] = 255;

  for (i = 1; i <= length; i++)
    {
      temp = (int) (exp (- (i * i) / sigma2) * 255);
      curve[-i] = temp;
      curve[i] = temp;
    }

  sum   = (int*) malloc((2 * length + 1) * sizeof(int));

  sum[0] = 0;
  for (i = 1; i <= length*2; i++)
    {
      sum[i] = curve[i-length-1] + sum[i-1];
    }

  sum += length; /* 'center' the sum[] */

  *p_total  = sum[length] - sum[-length];
  *p_curve  = curve;
  *p_sum    = sum;
  *p_length = length;

}

static void
free_rle_curve (int *curve,
                int  length,
                int *sum)
{
  free (sum - length);
  free (curve - length);
}

static void
gauss_rle (unsigned char* rgb24, 
		   unsigned char* rgb24_blur,
		   int          width_in,
           int          height_in,
		   int          bpp_in,
		   int          has_alpha_in,
           double       horz,
           double       vert)
{
  GimpPixelRgn src_rgn, dest_rgn;
  int          bytes;
  int      has_alpha;
  unsigned char       *dest;
  unsigned char       *src;
  int          row, col, b;
  double       std_dev;
  int          total = 1;
  int         *curve = NULL;
  int         *sum   = NULL;
  int          length;
  int          width;
  int          height;
  
  int hor_extra = 1 + ceil (horz);
  int ver_extra = 1 + ceil (vert);
	
  int x = 0;
  int y = 0;
  x = MAX (x - hor_extra, 0);
  y = MAX (y - ver_extra, 0);
  width  = MIN (width_in + hor_extra, width_in) - x;
  height = MIN (height_in + ver_extra, height_in) - y;
  
  bytes = bpp_in;
  has_alpha = has_alpha_in;
  
  src  = (unsigned char*) malloc (MAX (width, height) * bytes * sizeof(unsigned char));
  dest = (unsigned char*) malloc (MAX (width, height) * bytes * sizeof(unsigned char));

  //TODO src dest 
  {
	//TODO: get input rgb24 bytes data, and set uesless paramters to let program go on
	memset(&src_rgn, 0, sizeof(GimpPixelRgn));
	memset(&dest_rgn, 0, sizeof(GimpPixelRgn));

	src_rgn.data = rgb24;
	src_rgn.bpp = bpp_in;
	src_rgn.w = width;
	src_rgn.h = height;
	src_rgn.x = 0;
	src_rgn.y = 0;
	src_rgn.rowstride = src_rgn.w*src_rgn.bpp;

	dest_rgn.data = rgb24_blur;
	dest_rgn.bpp = bpp_in;
	dest_rgn.w = width;
	dest_rgn.h = height;
	dest_rgn.x = 0;
	dest_rgn.y = 0;
	dest_rgn.rowstride = dest_rgn.w*src_rgn.bpp;

}
  
  /*  First the vertical pass  */
  if (vert > 0.0)
    {
      int   * rle = NULL;
      int   * pix = NULL;

      vert = fabs (vert) + 1.0;
      std_dev = sqrt (-(vert * vert) / (2 * log (1.0 / 255.0)));

      make_rle_curve (std_dev, &curve, &length, &sum, &total);

      rle = (int*) malloc ((height + 2 * length) * sizeof(int));
      rle += length; /* rle[] extends from -length to height+length-1 */

      pix = (int*) malloc ((height + 2 * length) * sizeof(int));
      pix += length; /* pix[] extends from -length to height+length-1 */

      for (col = 0; col < width; col++)
        {
		  ml_get_col (src_rgn.data, src, col, src_rgn.bpp, width, height);

          if (has_alpha)
            multiply_alpha (src, height, bytes);

          for (b = 0; b < bytes; b++)
            {
              int same =  run_length_encode (src + b, rle, pix, bytes,
                                              height, length, 1);

              if (same > (3 * height) / 4)
                {
                  /* encoded_rle is only fastest if there are a lot of
                   * repeating pixels
                   */
                  do_encoded_lre (rle, pix, dest + b, height, length, bytes,
                                  curve, total, sum);
                }
              else
                {
                  /* else a full but more simple algorithm is better */
                  do_full_lre (pix, dest + b, height, length, bytes,
                               curve, total);
                }
            }

          if (has_alpha)
            separate_alpha (dest, height, bytes);

            ml_set_col (dest_rgn.data, dest, col, dest_rgn.bpp, width, height);

        }

      free (rle - length);
      free (pix - length);

    }

  /*  Now the horizontal pass  */
  if (horz > 0.0)
    {
      int   * rle = NULL;
      int   * pix = NULL;

      horz = fabs (horz) + 1.0;

      /* euse the same curve if possible else recompute a new one */
      if (horz != vert)
        {

          std_dev = sqrt (-(horz * horz) / (2 * log (1.0 / 255.0)));

          if (curve != NULL) {
            free_rle_curve(curve, length, sum);
          }

          make_rle_curve(std_dev, &curve, &length, &sum, &total);

        }


      rle = (int*) malloc ((width+2*length) * sizeof(int));
      rle += length; /* so rle[] extends from -width to width+length-1 */

      pix = (int*) malloc ((width+2*length) * sizeof(int));
      pix += length; /* so pix[] extends from -width to width+length-1 */

      for (row = 0; row < height; row++)
        {
          ml_get_row (src_rgn.data, src, row, src_rgn.bpp, width, height);

          if (has_alpha)
            multiply_alpha (src, width, bytes);

          for (b = 0; b < bytes; b++)
            {
              int same = run_length_encode (src + b, rle, pix, bytes,
                                             width, length, 1);

              if (same > (3 * width) / 4)
                {
                  /* encoded_rle is only fastest if there are a lot of
                   * repeating pixels
                   */
                  do_encoded_lre (rle, pix, dest + b, width, length, bytes,
                                  curve, total, sum);
                }
              else
                {
                  /* else a full but more simple algorithm is better */
                  do_full_lre (pix, dest + b, width, length, bytes,
                               curve, total);
                }
            }


          if (has_alpha)
            separate_alpha (dest, width, bytes);

			ml_set_row (dest_rgn.data, dest, row, dest_rgn.bpp, width, height);
        }

      free (rle - length);
      free (pix - length);
    }
	
  if (curve)
    free_rle_curve (curve, length, sum);

  free (src);
  free (dest);
}
