#include "image_refocus.h"

#include <stdlib.h>

ImageFocus::ImageFocus()
{
    engine_ = MNull;
    focusMode_ = ARC_DCIR_NORMAL_MODE;
    memset(&dcirParam_, 0, sizeof(dcirParam_));
    memset(&rfParam_, 0, sizeof(rfParam_));
    
    ARC_DCIR_GetDefaultParam (&dcirParam_);
}

ImageFocus::~ImageFocus()
{
    //log("ARC_DCIR_Uninit engine_ :%p", engine_);
    
    ARC_DCIR_Uninit(&engine_);
}

MRESULT ImageFocus::init(MInt32 focusMode)
{
    MRESULT res;
    
    res = ARC_DCIR_Init(&engine_, focusMode);
    const MPBASE_Version* pVersion = ARC_DCIR_GetVersion();
    log("ARC_DCVR_GetVersion : %s", pVersion->Version);
    
    focusMode_ = focusMode;
    
    return res;
}

void ImageFocus::setCaldata(MVoid* data, MInt32 size)
{
    ARC_DC_CALDATA caldata = {data, size};
    
    ARC_DCIR_SetCaliData(engine_, &caldata);
}

void ImageFocus::setImgDegree(MInt32 degree)
{
    dcirParam_.i32ImgDegree = degree;
}
    
void ImageFocus::setMaxFov(MFloat maxFov)
{
    if(maxFov != 0)dcirParam_.fMaxFOV = maxFov;
}

void ImageFocus::setFaceParam(PMRECT faces, MInt32* faceAngles, MInt32 faceNum)
{
    ARC_DCIR_FACE_PARAM faceinfo = {faces, faceAngles, faceNum};
    
    dcirParam_.faceParam = faceinfo;
}

MRESULT ImageFocus::calcDispMap(ASVLOFFSCREEN& leftImg, ASVLOFFSCREEN& rightImg)
{
    MRESULT res;
    
    MLTIME* p = new MLTIME("ARC_DCIR_CalcDisparityData");
    res = ARC_DCIR_CalcDisparityData(engine_, &leftImg, &rightImg, &dcirParam_);
    delete p;
    
    log("ARC_DCIR_CalcDisparityData dcirParam_.fMaxFOV: %f, dcirParam_.i32ImgDegree: %d, dcirParam_.faceParam.i32FacesNum: %d",
        dcirParam_.fMaxFOV, dcirParam_.i32ImgDegree, dcirParam_.faceParam.i32FacesNum);
        
    log("ARC_DCIR_CalcDisparityData res: %ld", res);

    return res;
}

void ImageFocus::setFocusPoint(MPOINT focusPoint)
{
    rfParam_.ptFocus = focusPoint;
}

void ImageFocus::setBlurIntensity(MInt32 blurIntensity)
{
    rfParam_.i32BlurIntensity = blurIntensity;
}

void ImageFocus::setCameraImageInfo(int leftwidth, int leftheight, int rightwidth, int rightheight)
{
    ARC_REFOCUSCAMERAIMAGE_PARAM param = {leftwidth, leftheight, rightwidth, rightheight};
    
    ARC_DCIR_SetCameraImageInfo(engine_, &param);
}

void ImageFocus::reset(void)
{
    //ARC_DCIR_Reset(engine_);
}

MRESULT ImageFocus::process(ASVLOFFSCREEN& leftImg, ASVLOFFSCREEN& dstImg)
{
    MRESULT res;
    
    if(focusMode_ == ARC_DCIR_NORMAL_MODE)
    {
        void* pDispMap = MNull;
        int lDMSize = 0;
        res = ARC_DCIR_GetDisparityDataSize (engine_, &lDMSize);
        pDispMap = malloc(lDMSize);
         
        ARC_DCIR_GetDisparityData(engine_, pDispMap);
        
        MLTIME* p = new MLTIME("ARC_DCIR_Process");
        res = ARC_DCIR_Process(engine_, pDispMap, lDMSize,
                                &leftImg, &rfParam_, &dstImg);

        log("ARC_DCIR_Process rfParam_.i32BlurIntensity: %d, rfParam_.ptFocus: (%dx%d)",
        rfParam_.i32BlurIntensity, rfParam_.ptFocus.x, rfParam_.ptFocus.y);
        
        delete p;
        
        //res = ARC_DCIR_Process (engine_, NULL, 0,
        //                        &leftImg, &rfParam_, &dstImg);

        free(pDispMap);

        log("ARC_DCIR_Process res: %ld", res);
    }

    // not fulfilled
    if(focusMode_ == ARC_DCIR_POST_REFOCUS_MODE)
        res = -1;
                            
    return res;
}
