
#ifndef __VIDEO_REFOCUS_H__
#define __VIDEO_REFOCUS_H__

#include "utils.h"
#include "arcsoft_dualcam_video_refocus.h"

class VideoFocus
{
public:
    VideoFocus();
    ~VideoFocus();
    
public:
    MRESULT init(void);
    
    void setCaldata(MVoid* data, MInt32 size);
    
    void setImgDegree(MInt32 degree);
    void setFocusPoint(MPOINT focusPoint);
    void setBlurLevel(MInt32 blurLevel);
    void setRefocusOn(bool refocusOn);
    
    MRESULT process(ASVLOFFSCREEN& leftImg, ASVLOFFSCREEN& rightImg, ASVLOFFSCREEN& dstImg);
    void setCameraImageInfo(int leftwidth, int leftheight, int rightwidth, int rightheight);

private:

private:
    MHandle engine_;
    ARC_DCVR_PARAM vrParam_;
};

#endif /* __VIDEO_REFOCUS_H__ */