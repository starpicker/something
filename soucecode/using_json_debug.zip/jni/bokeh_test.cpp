#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>

extern int parse_param(const char* jsonPath);
extern int test_preview();
extern int test_capture();

const char* preview = "preview";
const char* capture = "capture";

int main(int argc, char* argv[])
{
    if(argc != 3)
    {
        printf("usage: %s %s[%s] param.json\n", argv[0], preview, capture);
        exit(0);
    }
    
    parse_param(argv[2]);
    
    if(!strcmp(argv[1], preview))
    {
        return test_preview();
    }
    else if(!strcmp(argv[1], capture))
    {
        return test_capture();
    }
    else
    {
        printf("no type assigned\n");
        return -1;
    }
}
