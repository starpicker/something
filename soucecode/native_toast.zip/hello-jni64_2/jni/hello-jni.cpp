/*
 * Copyright (C) 2009 The Android Open Source Project
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 *
 */
#include <string.h>
#include <jni.h>

#include <android/log.h>

#include <thread>


using std::thread;


JavaVM* gvm;

#define log(...) __android_log_print(ANDROID_LOG_ERROR, "DEV", __VA_ARGS__)

/* This is a trivial JNI example where we use a native method
 * to return a new VM String. See the corresponding Java source
 * file located at:
 *
 *   apps/samples/hello-jni/project/src/com/example/hellojni/HelloJni.java
 */


const int LONG_DELAY = 3500; // 3.5 seconds
const int SHORT_DELAY = 2000; // 2 seconds

jobject getContext(JNIEnv* env, JavaVM* vm)
{
    jclass activityThread = env->FindClass("android/app/ActivityThread");

    log("xxxxxxxxxxxxxx before activityThread :%p", activityThread);

    jmethodID currentActivityThread = env->GetStaticMethodID(activityThread, "currentActivityThread", "()Landroid/app/ActivityThread;");


    log("xxxxxxxxxxxxxx before currentActivityThread :%p", currentActivityThread);


    jobject at = env->CallStaticObjectMethod(activityThread, currentActivityThread);

    log("xxxxxxxxxxxxxx before at :%p", at);


    jmethodID getApplication = env->GetMethodID(activityThread, "getApplication", "()Landroid/app/Application;");

    log("xxxxxxxxxxxxxx before getApplication :%p", getApplication);


    jobject context = env->CallObjectMethod(at, getApplication);

    log("xxxxxxxxxxxxxx before context :%p", context);



    return context;
}

void realtoast(JavaVM* vm, JNIEnv* env, const char* str, jint time)
{
    jobject context = getContext(env, vm);
    jclass tclss = env->FindClass("android/widget/Toast");

    log("xxxxxxxxxxxxxx before tclss :%p", tclss);

    jmethodID mid = env->GetStaticMethodID(tclss, "makeText", "(Landroid/content/Context;Ljava/lang/CharSequence;I)Landroid/widget/Toast;");

    log("xxxxxxxxxxxxxx before mid :%p", mid);


    jclass loopclss = env->FindClass("android/os/Looper");
    jmethodID loopmid = env->GetStaticMethodID(loopclss, "prepare", "()V");

    env->CallStaticVoidMethod(loopclss, loopmid);

    jobject job = env->CallStaticObjectMethod(tclss, mid, context, env->NewStringUTF(str), time);
    jmethodID showId = env->GetMethodID(tclss, "show", "()V");

    env->CallVoidMethod(job, showId);

    jmethodID loopmid3 = env->GetStaticMethodID(loopclss, "myLooper", "()Landroid/os/Looper;");
    jobject job2 = env->CallStaticObjectMethod(loopclss, loopmid3);
    log("111111111 job :%p", job2);


    jmethodID quitid = env->GetMethodID(loopclss, "quit", "()V");
    log("111111111 quitid :%p", quitid);

    env->CallVoidMethod(job2, quitid);


    log("xxxxxxxxxxxxxx before loop000");

    jmethodID loopmid2 = env->GetStaticMethodID(loopclss, "loop", "()V");
    env->CallStaticVoidMethod(loopclss, loopmid2);

//    thread t([](JNIEnv* env, jclass loopclss, jmethodID loopmid2){
//
//
//        env->CallStaticVoidMethod(loopclss, loopmid2);
//    }, env, loopclss, loopmid2);

    //jmethodID loopmid3 = env->GetStaticMethodID(loopclss, "quit", "()V");
    //env->CallStaticVoidMethod(loopclss, loopmid3);

    //log("xxxxxxxxxxxxxx after quit");

    //t.join();

    log("xxxxxxxxxxxxxx after loop");
}

void toast(const char* str)
{
	JNIEnv* env1 = NULL;
	gvm->GetEnv((void**)&env1, JNI_VERSION_1_4);

	log("xxxxx env1 5555 is %p", env1);
    realtoast(gvm, env1, str, LONG_DELAY);
}


extern "C"
jstring
Java_com_example_hellojni_HelloJni_stringFromJNI__( JNIEnv* env,
                                                  jobject thiz )
{




	log("xxxxx env111 is %p", env);
	jstring s;

	thread t(
			[](jstring* s)
			{

				JNIEnv* env1 = NULL;

				if(gvm->GetEnv((void**)&env1, JNI_VERSION_1_4) != JNI_OK)
				{
					log("xxxxx env222 is %p", env1);
					if(env1 == 0)
					{

						gvm->AttachCurrentThread(&env1, NULL);
						log("xxxxx env333 is %p", env1);

						*s = env1->NewStringUTF("Hello from JNI !  Compiled with ABI 2222.");


						toast("aaaddddddddddddddddddddddd");


						gvm->DetachCurrentThread();
					}
				}

				log("xxxxx env333 after is %p", env1);
			}, &s
	);

	t.join();

	// s cannot be trans envs
	//return s;


	return env->NewStringUTF("Hello from JNI !  Compiled with ABI 1111.");
}

JNIEXPORT jint JNICALL JNI_OnLoad(JavaVM* vm, void* reserved)
{
	gvm = vm;
    JNIEnv* env = NULL;

    if(vm->GetEnv((void**)&env, JNI_VERSION_1_4) != JNI_OK)
    {
        return -1;
    }
	log("xxxxx vm is %p, env000 is %p", vm, env);

    return JNI_VERSION_1_4;
}
