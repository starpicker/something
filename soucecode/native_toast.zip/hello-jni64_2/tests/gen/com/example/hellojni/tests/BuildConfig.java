/** Automatically generated file. DO NOT MODIFY */
package com.example.hellojni.tests;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}