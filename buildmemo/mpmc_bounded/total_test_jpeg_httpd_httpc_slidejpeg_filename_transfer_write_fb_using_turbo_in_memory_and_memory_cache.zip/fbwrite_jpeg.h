#ifndef FBWRITER_JPEG_H__
#define FBWRITER_JPEG_H__

#include <stdlib.h> //for size_t

class FBWriter
{
public:
    static FBWriter* GetInstance()
    {
        if(m_pFBWriterInstance == NULL)
        {
            m_pFBWriterInstance = new FBWriter();
        }
        
        return m_pFBWriterInstance;
    }

private:
    FBWriter();
    FBWriter(const FBWriter &) = delete;
    FBWriter & operator = (const FBWriter &) = delete;
    
    static FBWriter* m_pFBWriterInstance;
    class CGarbo
    {  
    public:  
        ~CGarbo()  
        {  
            if(FBWriter::m_pFBWriterInstance)  
                delete FBWriter::m_pFBWriterInstance;  
        }  
    };  
    static CGarbo Garbo;
    
public:
    ~FBWriter();

public:
    int                           myself_write_jpeg_buffer_fb(unsigned char* jpegbuffer, int jpegLen);
    int                           myself_write_jpeg_buffer_fb_return_info(unsigned char* jpegbuffer, int jpegLen,
                                                                            unsigned char** pargb_buffer, int* pimage_width, int* pimage_height);
    int                           myself_write_argb32_buffer_fb(unsigned char* argb_buffer, int image_width, int image_height);

private:
    int                           fb_open(const char* fb_device);
    int                           fb_stat(int fd, int* width, int* height, int* depth);
    void*                         fb_mmap(int fd, unsigned int screensize);
    int                           fb_munmap(void *start, size_t length);
    int                           fb_close(int fd);
    
    static int                    tjpeg2argb(unsigned char* jpeg_buffer, int jpeg_size, unsigned char** pargb_buffer,
                                             int* argb_size, int* image_width, int* image_height);
private:
    int                           fbdev;
    const char*                   fb_device;
    void*                         fbmem;
    unsigned int                  screensize;
    int                           fb_width;
    int                           fb_height;
    int                           fb_depth;
};

#endif // FBWRITER_JPEG_H__