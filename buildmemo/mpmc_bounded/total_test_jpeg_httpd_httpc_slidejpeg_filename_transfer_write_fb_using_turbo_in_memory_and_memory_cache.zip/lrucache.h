#ifndef __LRUCACHE_H__
#define __LRUCACHE_H__

#include <vector>
#include <map>
#include <pthread.h>
#include <assert.h>

using std::map;

template <class K, class D>
struct Node{
    K key;
    D data;
    Node *prev, *next;
};

template <class K, class D>
class LRUCache{
public:
    LRUCache(size_t size , bool is_pthread_safe = false){
        if(size <= 0)
            size = 1024;

        pthread_safe = is_pthread_safe;
        if(pthread_safe)
            pthread_mutex_init(&cached_mutex , NULL);

        entries = new Node<K,D>[size];
        counter = size;
        
        head = new Node<K,D>;
        tail = new Node<K,D>;
        head->prev = NULL;
        head->next = tail;
        tail->prev = head;
        tail->next = NULL;
    }

    ~LRUCache(){
        if(pthread_safe)
            pthread_mutex_destroy(&cached_mutex);
        delete head;
        delete tail;
        delete[] entries;
    }

    void Put(K key, D data);
    D Get(K key);
    
private:
    void cached_lock(void){
        if(pthread_safe)
            pthread_mutex_lock(&cached_mutex);
    }
    void cached_unlock(void){
        if(pthread_safe)
            pthread_mutex_unlock(&cached_mutex);
    }
    void detach(Node<K,D>* node){
        node->prev->next = node->next;
        node->next->prev = node->prev;
    }
    void attach(Node<K,D>* node){
        node->prev = head;
        node->next = head->next;
        head->next = node;
        node->next->prev = node;
    }

private:
    map<K, Node<K,D>* > cached_map;
    int         counter;
    Node<K,D> * head, *tail;
    Node<K,D> * entries;
    bool pthread_safe;
    pthread_mutex_t cached_mutex;
};

template<class K , class D>
void LRUCache<K,D>::Put(K key , D data){
    cached_lock();
    Node<K,D> *node = cached_map[key];
    if(node){
        detach(node);
        node->data = data;
        attach(node);
    }
    else{
        if(counter == 0){
            node = tail->prev;
            detach(node);
            cached_map.erase(node->key);
        }
        else{
            --counter;
            node = &(entries[counter]);
        }
        node->key = key;
        
        free(node->data.argb32_buffer);
        
        node->data = data;
        cached_map[key] = node;
        attach(node);
    }
    cached_unlock();
}

template<class K , class D>
D LRUCache<K,D>::Get(K key){
    cached_lock();
    Node<K,D> *node = cached_map[key];
    if(node){
        detach(node);
        attach(node);
        cached_unlock();
        return node->data;
    }
    else{
        cached_unlock();
        return D();
    }
}

#endif