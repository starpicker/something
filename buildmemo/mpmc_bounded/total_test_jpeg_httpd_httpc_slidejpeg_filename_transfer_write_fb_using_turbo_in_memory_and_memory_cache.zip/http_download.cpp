#include "http_download.h"

#include <string>

//#include <stdio.h>
#include <string.h>
// #include <stdlib.h>
// #include <errno.h>
#include <unistd.h>
// #include <limits.h>
#include <netdb.h>
// #include <ctype.h>
// #include <arpa/inet.h>
// #include <sys/types.h>
// #include <sys/socket.h>
// #include <netinet/in.h>
// #include <netinet/tcp.h>

Http_Download::Http_Download()
{
    m_socket                 = 0;
    m_nResponseHeaderSize    = 0;
    m_nResponseBodySize      = 0;
    m_ChunkSize              = 0;
    m_ContentLen             = 0;
    m_RecvSize               = 0;
    m_ChunkOverFlag          = false;
    m_IsChunked              = false;

    memset(m_requestheader,  0, sizeof(m_requestheader));
    memset(m_ResponseHeader, 0, sizeof(m_ResponseHeader));
    memset(m_ResponseBody,   0, sizeof(m_ResponseBody));
}

Http_Download::~Http_Download()
{
    CloseSocket();
}

bool Http_Download::OpenSocket(void)
{
    struct protoent* ppe;
    ppe = getprotobyname("tcp");
    m_socket = socket(AF_INET, SOCK_STREAM, ppe->p_proto);
    if(m_socket == -1)
    {
        return false;
    }

#if 0
    /* Disable the Nagle (TCP No Delay) algorithm */
    int flag, ret;
    ret = setsockopt(m_socket, IPPROTO_TCP, TCP_NODELAY, (char *)&flag, sizeof(flag));
    if (ret == -1)
    {
        printf("Couldn't setsockopt(TCP_NODELAY)\n");
    }
#endif

    return true;
}

bool Http_Download::CloseSocket(void)
{
    if(m_socket != 0)
    {
        if(close(m_socket) == -1)
        {
            return false;
        }
    }
    m_socket = 0;

    return true;
}

bool Http_Download::SetTimeout(int ms, TIMEOUT_TYPE tt)const
{
    int opt = SO_RCVTIMEO;

    if(tt == TIMEOUT_TYPE::RECV)
    {
        opt = SO_RCVTIMEO;
    }
    else
    {
        opt = SO_SNDTIMEO;
    }

    int ret;
    ret = setsockopt(m_socket, SOL_SOCKET, opt, (char*)&ms, sizeof(ms));
    if(ret)
    {
        return false;
    }

    return true;
}

bool Http_Download::Connect(const char* szHostName, int nPort)const
{
    if(szHostName == nullptr)
    {
        return false;
    }

    hostent* phostent;
    phostent = gethostbyname(szHostName);
    if(phostent == nullptr)
    {
        printf("connect can't found host\n");
        return false;
    }

    struct in_addr ip_addr;
    memcpy(&ip_addr, phostent->h_addr_list[0], sizeof(ip_addr));

    struct sockaddr_in destaddr;
    destaddr.sin_family = AF_INET;
    destaddr.sin_port   = htons(nPort);
    destaddr.sin_addr   = ip_addr;
    if(connect(m_socket, (sockaddr*)&destaddr, sizeof(sockaddr)) != 0)
    {
        return false;
    }

    return true;
}

const char* Http_Download::FormatRequestHeader(const char* pServer, const char* url,
                                               const char* pCookie, const char* pReferer)
{
    memset(m_requestheader, 0, sizeof(m_requestheader));
    strcat(m_requestheader, "GET ");
    strcat(m_requestheader, url);
    strcat(m_requestheader, " HTTP/1.1");
    strcat(m_requestheader, "\r\n");
    strcat(m_requestheader, "Host:");
    strcat(m_requestheader, pServer);
    strcat(m_requestheader, "\r\n");

    if(pReferer != nullptr)
    {
        strcat(m_requestheader, "Referer:");
        strcat(m_requestheader, pReferer);
        strcat(m_requestheader, "\r\n");
    }

    strcat(m_requestheader, "Accept:*/*");
    strcat(m_requestheader, "\r\n");
    strcat(m_requestheader, "User-Agent:Dalvik/1.6.0 (Linux; U; Android 4.1.2; SH-02E Build/A2200)");
    strcat(m_requestheader, "\r\n");
    strcat(m_requestheader, "Connection:Keep-Alive");
    strcat(m_requestheader, "\r\n");

    if(pCookie != nullptr)
    {
        strcat(m_requestheader, "Set Cookie:0");
        strcat(m_requestheader, pCookie);
        strcat(m_requestheader, "\r\n");
    }

    strcat(m_requestheader, "\r\n");
    
    return m_requestheader;
}

bool Http_Download::SendRequest(void)const
{
    if(send(m_socket, m_requestheader, strlen(m_requestheader), 0) == -1)
    {
        return false;
    }

    return true;
}

bool Http_Download::ParseResponseHeader(void)
{
    char   buffer[MAX_HEADER_SIZE]  = {0};
    int    nBytes                   = 0;
    char*  pHeaderEnd               = nullptr;
    int    headerLen                = 0;

    //clear header
    m_nResponseHeaderSize           = 0;
    m_nResponseBodySize             = 0;

    while(1)
    {
        nBytes = recv(m_socket, buffer, MAX_HEADER_SIZE, 0);

        if(nBytes <= 0)
        {
            printf("ParseResponseHeader failed\n");
            return false;
        }

        pHeaderEnd = strstr(buffer, "\r\n\r\n") ;
        if(pHeaderEnd)
        {
            pHeaderEnd += strlen("\r\n\r\n");
            headerLen  = pHeaderEnd - buffer;
            memcpy(m_ResponseHeader + m_nResponseHeaderSize, buffer, headerLen);
            m_nResponseHeaderSize += headerLen;
            m_nResponseBodySize   = nBytes - headerLen;
            memcpy(m_ResponseBody, pHeaderEnd, m_nResponseBodySize);
            break;
        }
        else
        {
            headerLen = nBytes;
            memcpy(m_ResponseHeader + m_nResponseHeaderSize, buffer, headerLen);
            m_nResponseHeaderSize += headerLen;
        }
    }

    for(int i = 0; i < m_nResponseHeaderSize; i++)
    {
        m_ResponseHeader[i] = tolower(m_ResponseHeader[i]);
    }
    
    //printf("ParseResponseHeader  %s\n", m_ResponseHeader);

    char* encode = strstr(m_ResponseHeader, "transfer-encoding:");
    if(encode)
    {
        if(strstr(encode, "chunked"))
        {
            m_IsChunked = true;
        }
    }

    return true;
}

int Http_Download::GetResponseCode(void)const
{
    char szState[3] = {0};

    if(m_nResponseHeaderSize > sizeof("HTTP/1.1 200"))
    {
        szState[0] = m_ResponseHeader[9];
        szState[1] = m_ResponseHeader[10];
        szState[2] = m_ResponseHeader[11];
    }

    return atoi(szState);
}

long Http_Download::GetContentLength(void)
{
    char size[20] = {0};
    char* contentLen = strstr(m_ResponseHeader, "content-length:");
    if(contentLen)
    {
        contentLen += strlen("Content-Length:");
        char* stop = strstr(contentLen, "\r\n");
        memcpy(size, contentLen, stop - contentLen);
        m_ContentLen = atoi(size);
    }
    //printf("getContentLength Length %ld\n", m_ContentLen);

    return m_ContentLen;
}

int Http_Download::GetResponseBody(char* body)
{
    if(body == nullptr)
    {
        return 0;
    }

    int   size         = 0;
    char  strSize[10]  = {0};
    char* chunkSize    = nullptr;
    if(m_IsChunked && (chunkSize = strstr(m_ResponseBody, "\r\n")))
    {
        char* pBody = chunkSize + strlen("\r\n");
        memcpy(strSize, m_ResponseBody, chunkSize - m_ResponseBody);
        memcpy(body, pBody, m_nResponseBodySize - (pBody - m_ResponseBody));

        m_ChunkSize = strtol(strSize, NULL, 16);
        size        = m_nResponseBodySize - (pBody - m_ResponseBody);
        m_RecvSize  += size;
    }
    else
    {
        memcpy(body, m_ResponseBody, m_nResponseBodySize);
        size = m_nResponseBodySize;
    }

    return size;
}

long Http_Download::RecvDownloadData(char* pBuffer, long nMaxLength)
{
    int recvLen = 0;
    recvLen     = recv(m_socket, pBuffer, nMaxLength, 0);
    m_RecvSize  += recvLen;

    if(recvLen <= 0)
    {
        return -1;
    }

    if(m_IsChunked)
    {
        if(m_ChunkOverFlag)
        {
            long chunkSize = strtol(pBuffer, NULL, 16);
            if(chunkSize == 0)
            {
                printf("RecvDownloadData chunk over\n");
                m_RecvSize    -= recvLen;    //Current recv data is an end flag,not save them.
                recvLen       = -1;
                m_ContentLen  = m_RecvSize;
            }
            else
            {
                m_ChunkSize   += chunkSize;
                char* pChunk  = strstr(pBuffer, "\r\n");
                if(pChunk)
                {
                    pChunk      += strlen("\r\n");
                    int bodyLen = recvLen - (pChunk - pBuffer);
                    char* pBody = (char*)malloc(bodyLen);
                    memcpy(pBody, pChunk, bodyLen);
                    memcpy(pBuffer, pBody, bodyLen);
                    recvLen     = bodyLen;
                    free(pBody);
                    m_RecvSize  -= (pChunk - pBuffer);    //ignore chunk header
                }
            }
            m_ChunkOverFlag = false;

        }
        //current chunk is over.
        if(recvLen > 0 && m_RecvSize > m_ChunkSize)
        {
            if((pBuffer[recvLen - 5] == '0') && (pBuffer[recvLen - 4] == '\r') && (pBuffer[recvLen - 3] == '\n'))
            {
                recvLen      -= 7;  //ignore chunk End flag "\r\n0\r\n\r\n"
                m_RecvSize   -= 7;
                m_ContentLen = m_RecvSize;
                printf("#####Receive  chunk End and ignore the last 7 characters\n");
            }
            else
            {
                int ignoreLen = 2;
                if(m_RecvSize - m_ChunkSize == 2)
                {
                    m_ChunkOverFlag = true;
                }
                else if(m_RecvSize - m_ChunkSize > 2)
                {
                    //separate recv data to three part: PartA.ignorePart.PartB, and PartA will be reserved
                    int recvPartALen = recvLen - (m_RecvSize - m_ChunkSize);  //the len of before chunk over flag "\r\n".
                    int recvPartBLen = 0;
                    char* ckSize     = strstr(pBuffer + recvPartALen + 2, "\r\n");

                    //fetch chunk size
                    if(ckSize)
                    {
                        int chunkSize = strtol(pBuffer + recvPartALen + 2, NULL, 16);
                        ignoreLen     = (ckSize + 2 - (pBuffer + recvPartALen));
                        recvPartBLen  = m_RecvSize - m_ChunkSize - ignoreLen;

                        char* tmpBuf  = (char*)malloc(recvPartBLen);
                        memcpy(tmpBuf, pBuffer + recvPartALen + ignoreLen, recvPartBLen);
                        memcpy(pBuffer + recvPartALen, tmpBuf, recvPartBLen);
                        m_ChunkSize   += chunkSize;
                        free(tmpBuf);
                    }
                }
                recvLen    -= ignoreLen;  //ignore chunk OVER flag "\r\n"
                m_RecvSize -= ignoreLen;

                printf("#####Receive one chunk over and ignore %d character\n", ignoreLen);
            }
        }
    }

    return recvLen;
}
