#ifndef HTTP_DOWNLOAD__
#define HTTP_DOWNLOAD__

class Http_Download
{
public:
                                        Http_Download();
                                        ~Http_Download();

    enum class TIMEOUT_TYPE
    {
        RECV = 0,
        SEND,
    };

public:
    bool                               OpenSocket(void);
    bool                               CloseSocket(void);
    bool                               SetTimeout(int ms, TIMEOUT_TYPE tt = TIMEOUT_TYPE::RECV)const;
    bool                               Connect(const char* szHostName, int nPort = 80)const;
    const char*                        FormatRequestHeader(const char* pServer, const char* url,
                                                           const char* pCookie = nullptr,
                                                           const char* pReferer = nullptr);
    bool                               SendRequest(void)const;
    bool                               ParseResponseHeader(void);
    int                                GetResponseCode(void)const;
    long                               GetContentLength(void);
    int                                GetResponseBody(char* body);
    long                               RecvDownloadData(char* pBuffer, long nMaxLength);

private:
    int                                m_socket;

    const static int                   MAX_HEADER_SIZE = 1024u;

    char                               m_requestheader[MAX_HEADER_SIZE];
    char                               m_ResponseHeader[MAX_HEADER_SIZE];
    char                               m_ResponseBody[MAX_HEADER_SIZE];
    int                                m_nResponseHeaderSize;
    int                                m_nResponseBodySize;
    bool                               m_IsChunked;
    long                               m_ChunkSize;
    long                               m_RecvSize;
    long                               m_ContentLen;
    bool                               m_ChunkOverFlag;
};

#endif // HTTP_DOWNLOAD__
