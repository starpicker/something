#include "fbwrite_jpeg.h"

#include <stdio.h>
#include <fcntl.h>
#include <linux/fb.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <sys/mman.h>
#include <string.h>
#include <unistd.h>
#include <sys/ioctl.h>

#include "turbojpeg.h"

#define         FB_DEV        "/dev/fb0"

FBWriter* FBWriter::m_pFBWriterInstance = NULL;

FBWriter::FBWriter()
{
    if((fb_device = getenv("FRAMEBUFFER")) == NULL)
    fb_device = FB_DEV;

    fbdev = fb_open(fb_device);
    fb_stat(fbdev, &fb_width, &fb_height, &fb_depth);
    screensize = fb_width * fb_height * fb_depth / 8;
    fbmem      = fb_mmap(fbdev, screensize);
}
    
FBWriter::~FBWriter()
{
    fb_munmap(fbmem, screensize);
    fb_close(fbdev);
}

int FBWriter::myself_write_jpeg_buffer_fb(unsigned char* jpegbuffer, int jpegLen)
{
    unsigned char* argb_buffer;
    int image_width;
    int image_height;
    int argb_size;
    
    tjpeg2argb(jpegbuffer, jpegLen, &argb_buffer, &argb_size, &image_width, &image_height);
    
    memset(fbmem, 0, screensize);
    
    image_height = (image_height > fb_height) ? fb_height : image_height;
    image_width = (image_width > fb_width) ? fb_width : image_width;
    
    for(int i = 0; i < image_height; i++)
        memcpy(((unsigned char*)fbmem)+i*fb_width*4, argb_buffer+image_width*4*i, image_width*4);
    
    free(argb_buffer);

    return (0);
}

int FBWriter::myself_write_jpeg_buffer_fb_return_info(unsigned char* jpegbuffer, int jpegLen,
                                                        unsigned char** pargb_buffer, int* pimage_width, int* pimage_height)
{
    unsigned char* argb_buffer;
    int image_width;
    int image_height;
    int argb_size;
    
    tjpeg2argb(jpegbuffer, jpegLen, &argb_buffer, &argb_size, &image_width, &image_height);
    
    memset(fbmem, 0, screensize);
    
    *pargb_buffer = argb_buffer;
    *pimage_width = image_width;
    *pimage_height = image_height;
    
    image_height = (image_height > fb_height) ? fb_height : image_height;
    image_width = (image_width > fb_width) ? fb_width : image_width;
    
    for(int i = 0; i < image_height; i++)
        memcpy(((unsigned char*)fbmem)+i*fb_width*4, argb_buffer+image_width*4*i, image_width*4);
    
    //free(argb_buffer);

    return (0);
}

int FBWriter::myself_write_argb32_buffer_fb(unsigned char* argb_buffer, int image_width, int image_height)
{
    memset(fbmem, 0, screensize);
    
    image_height = (image_height > fb_height) ? fb_height : image_height;
    image_width = (image_width > fb_width) ? fb_width : image_width;

    for(int i = 0; i < image_height; i++)
        memcpy(((unsigned char*)fbmem)+i*fb_width*4, argb_buffer+image_width*4*i, image_width*4);
}

int FBWriter::fb_open(const char* fb_device)
{
    int fd;

    if((fd = open(fb_device, O_RDWR)) < 0)
    {
        perror(__func__);
        return (-1);
    }
    
    return (fd);
}

int FBWriter::fb_stat(int fd, int* width, int* height, int* depth)
{
    struct fb_fix_screeninfo fb_finfo;
    struct fb_var_screeninfo fb_vinfo;

    if(ioctl(fd, FBIOGET_FSCREENINFO, &fb_finfo))
    {
        perror(__func__);
        return (-1);
    }

    if(ioctl(fd, FBIOGET_VSCREENINFO, &fb_vinfo))
    {
        perror(__func__);
        return (-1);
    }

    *width = fb_vinfo.xres;
    *height = fb_vinfo.yres;
    *depth = fb_vinfo.bits_per_pixel;

    return (0);
}


void* FBWriter::fb_mmap(int fd, unsigned int screensize)
{
    void*             fbmem;

    if((fbmem = mmap(0, screensize, PROT_READ | PROT_WRITE, MAP_SHARED, fd, 0)) == MAP_FAILED)
    {
        perror(__func__);
        return (void *) (-1);
    }

    return (fbmem);
}

int FBWriter::fb_munmap(void *start, size_t length)
{
    return (munmap(start, length));
}


int FBWriter::fb_close(int fd)
{
    return (close(fd));
}

int FBWriter::tjpeg2argb(unsigned char* jpeg_buffer, int jpeg_size, unsigned char** pargb_buffer,
                int* argb_size, int* image_width, int* image_height)
{  
    tjhandle handle = NULL;
    int width, height, subsample, colorspace;
    int flags = 0;
    int pixelfmt = TJPF_BGRA;
  
    handle = tjInitDecompress();
    tjDecompressHeader3(handle, jpeg_buffer, jpeg_size, &width, &height, &subsample, &colorspace);
    
    *image_width = width;
    *image_height = height;
    *argb_size = width*height<<2;
    *pargb_buffer = (unsigned char*)malloc(*argb_size);
    
    flags |= 0;
    tjDecompress2(handle, jpeg_buffer, jpeg_size, *pargb_buffer, width, 0, height, pixelfmt, flags);

    tjDestroy(handle);
  
    return 0;
}