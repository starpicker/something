#include <netinet/in.h>    // for sockaddr_in
#include <arpa/inet.h>
#include <sys/types.h>    // for socket
#include <sys/socket.h>    // for socket
#include <stdio.h>        // for printf
#include <stdlib.h>        // for exit
#include <string.h>        // for bzero
#include <unistd.h>        // for bzero
 
#define HELLO_WORLD_SERVER_PORT    8079 
#define BUFFER_SIZE 1024
#define FILE_NAME_MAX_SIZE 512
 
int fileNameClientInit(char* serverIP)
{
    struct sockaddr_in client_addr;
    bzero(&client_addr,sizeof(client_addr));
    client_addr.sin_family = AF_INET;
    client_addr.sin_addr.s_addr = htons(INADDR_ANY);
    client_addr.sin_port = htons(0);
    int client_socket = socket(AF_INET,SOCK_STREAM,0);
    if( client_socket < 0)
    {
        printf("Create Socket Failed!\n");
        exit(1);
    }
    if( bind(client_socket,(struct sockaddr*)&client_addr,sizeof(client_addr)))
    {
        printf("Client Bind Port Failed!\n"); 
        exit(1);
    }
 
    struct sockaddr_in server_addr;
    bzero(&server_addr,sizeof(server_addr));
    server_addr.sin_family = AF_INET;
    if(inet_aton(serverIP, &server_addr.sin_addr) == 0) 
    {
        printf("Server IP Address Error!\n");
        exit(1);
    }
    server_addr.sin_port = htons(HELLO_WORLD_SERVER_PORT);
    socklen_t server_addr_length = sizeof(server_addr);
    if(connect(client_socket,(struct sockaddr*)&server_addr, server_addr_length) < 0)
    {
        exit(1);
    }
    
    return client_socket;
}

char* fileNameClientRecv(int client_socket)
{
    static char file_name[FILE_NAME_MAX_SIZE+1];
    bzero(file_name, FILE_NAME_MAX_SIZE+1);
    int length;
    
    length = recv(client_socket, file_name, FILE_NAME_MAX_SIZE, 0);
    if(length > 0)
        file_name[length] = '\0';
    else
        return 0;
    
    printf("Recieve FileName: %s, length: %d \n", file_name, length);
    
    return file_name;
}

void fileNameClientUnit(int client_socket)
{ 
    close(client_socket);
}

// int main(int argc, char** argv)
// {
    // int s = fileNameClientInit(argv[1]);

    // char* filepath = fileNameClientRecv(s);
    // printf("filepath is :%s\n", filepath);

    // fileNameClientUnit(s);


    // return 0;
// }
