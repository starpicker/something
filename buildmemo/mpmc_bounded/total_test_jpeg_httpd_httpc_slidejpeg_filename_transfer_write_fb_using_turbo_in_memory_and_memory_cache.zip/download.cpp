#include "http_download.h"

#include <iostream>

#include <string.h>

using std::cout;
using std::endl;

int download(const char* netUrl, unsigned char** jpeg_buffer, int* image_size)
{
#define MAX_IP_LEN                  16
#define MAX_HOST_SIZE               100
#define HTTP_STATUS_OK              200
#define MAX_RECV_SIZE               200*1024

    char ip[MAX_IP_LEN]             = {0};
    int  port                       = 80;
    char host[MAX_HOST_SIZE]        = {0};

    char* domain = strstr(const_cast<char*>(netUrl), "://");
    if(domain)
    {
        domain += strlen("://");
        char* fileAddress = strstr(domain, "/");
        if(fileAddress)
        {
            char* tmp = strchr(domain, ':');
            if(tmp && tmp < fileAddress)
            {
                memcpy(ip, domain, tmp - domain);
                tmp++;
                char portStr[10] = {0};
                memcpy(portStr, tmp, fileAddress - tmp);
                port = atoi(portStr);
            }
            else
            {
                memcpy(ip, domain, fileAddress - domain);
                port = 80;
            }
        }
        else
        {
            return -1;
        }

    }

    Http_Download hd;
    hd.OpenSocket();
    hd.SetTimeout(10*1000);
    
    //printf("download test: ip: %s, port: %d\n", ip, port);
    
    hd.Connect(ip, port);
    
    sprintf(host, "%s:%d", ip, port);
    const char* header = hd.FormatRequestHeader(host, netUrl);
    
    //printf("download test: header:\n%s\n", header);
    
    hd.SendRequest();
    hd.ParseResponseHeader();

    int ret = 0;

    if(hd.GetResponseCode() == HTTP_STATUS_OK)
    {
        int    count                      = 0;
        long   totalCount                 = 0;

        long   fileSize                   = 0;
        char   mBuffer[MAX_RECV_SIZE + 1] = {0};
        
        fileSize     = hd.GetContentLength();
        count        = hd.GetResponseBody(mBuffer);
        
        *jpeg_buffer = (unsigned char*)malloc(fileSize);
        *image_size = fileSize;
        
        memcpy(*jpeg_buffer+totalCount, mBuffer, count);
        totalCount   += count;
        
        while(true)
        {
            if(totalCount == fileSize)
            {
                printf("threadProc download suc\n");
                break;
            }

            count = hd.RecvDownloadData(mBuffer, MAX_RECV_SIZE);

            //if chunked download,may only receive data whose body num is 0. So pass it.
            if(count == 0)
            {
                continue;
            }

            if(count < 0)
            {
                printf("threadProc Receive failed,ret %d\n", count);
                break;
            }

            memcpy(*jpeg_buffer+totalCount, mBuffer, count);
            totalCount += count;
            

        }

        ret = 0;
    }
    else
    {
        ret = -1;
    }

    hd.CloseSocket();

    return ret;
}
