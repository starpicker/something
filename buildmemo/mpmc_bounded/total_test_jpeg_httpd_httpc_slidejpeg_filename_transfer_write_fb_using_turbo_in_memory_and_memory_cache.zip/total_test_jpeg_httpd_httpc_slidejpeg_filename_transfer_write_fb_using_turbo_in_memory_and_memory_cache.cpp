#include <string>

#include <pthread.h>

#include "client.cpp"
#include "fbwrite_jpeg.h"
#include "lrucache.h"

using std::string;

void* download_wrapper(void* filename);

int main(int argc, char** argv)
{
    if(argc != 2)
    {
        printf("usage: %s serverIP\n", argv[0]);
        exit(-1);
    }
    
    int s = fileNameClientInit(argv[1]);
    
    pthread_t tid;
    char filename[256];
    
    while(true)
    {
        string filepath = string("http://") + argv[1] + ":8080/";
        
        char* p = fileNameClientRecv(s);
        
        if(!p)break;
        
        filepath += p;
        printf("filepath is %s\n", filepath.c_str());
        
        memcpy(filename, filepath.c_str(), strlen(filepath.c_str()));
        filename[strlen(filepath.c_str())] = '\0';
        
        pthread_create(&tid, NULL, download_wrapper, (void*)filename);
        pthread_detach(tid);
    }
    
    fileNameClientUnit(s);

    return 0;
}

class JpegInfo
{
public:
	JpegInfo():argb32_buffer(NULL),width(0),height(0){}
	unsigned char* argb32_buffer;
	int width;
	int height;
};

#define JPEG_CACHE_SIZE 5
LRUCache<string, JpegInfo> fblru(JPEG_CACHE_SIZE, false);

int download(const char* netUrl, unsigned char** jpeg_buffer, int* image_size);
void* download_wrapper(void* filename)
{
    
    JpegInfo info;
    info = fblru.Get((const char*)filename);
    if((info.argb32_buffer != NULL) && (info.width != 0) && (info.height != 0))
    {
        FBWriter::GetInstance()->myself_write_argb32_buffer_fb(info.argb32_buffer, info.width, info.height);
    }
    else
    {
        unsigned char* jpeg_buffer;
        int image_size;
        
        download((const char*)filename, &jpeg_buffer, &image_size);
        
        unsigned char* argb_buffer;
        int image_width;
        int image_height;
        
        FBWriter::GetInstance()->myself_write_jpeg_buffer_fb_return_info(jpeg_buffer, image_size, &argb_buffer, &image_width, &image_height);
        
        JpegInfo info;
        info.argb32_buffer = argb_buffer;
        info.width = image_width;
        info.height = image_height;
        
        fblru.Put((const char*)filename, info);
    }
    
    return 0;
}
