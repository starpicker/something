/*******************************************************************************
Copyright(c) ArcSoft, All right reserved.

This file is ArcSoft's property. It contains ArcSoft's trade secret, proprietary 
and confidential information. 

The information and code contained in this file is only for authorized ArcSoft 
employees to design, create, modify, or review.

DO NOT DISTRIBUTE, DO NOT DUPLICATE OR TRANSMIT IN ANY FORM WITHOUT PROPER 
AUTHORIZATION.

If you are not an intended recipient of this file, you must not copy, 
distribute, modify, or take any action in reliance on it. 

If you have received this file in error, please immediately notify ArcSoft and 
permanently delete the original and any copy of any file and any printout 
thereof.
*******************************************************************************/

//./lls_test 20180101091242_LLS_input_0_4032x3000_iso_2518.nv21 20180101091242_LLS_input_1_4032x3000_iso_2518.nv21 20180101091242_LLS_input_2_4032x3000_iso_2518.nv21 output.nv21 4000 3000 2518 50 10 50 20 4032

//./lls_test 20180101091242_LLS_input_0_4032x3000_iso_2518.nv21 20180101091242_LLS_input_1_4032x3000_iso_2518.nv21 20180101091242_LLS_input_2_4032x3000_iso_2518.nv21 output.nv21 4000 3000 0 0 0 0 0 4032

#include <android/log.h>
#include <sys/time.h>
#include <stdlib.h>
#include <stdio.h>
#include <unistd.h>

#include "ammem.h"
#include "asvloffscreen.h"
#include "arcsoft_low_light_shot.h"

#define LOGE(...) __android_log_print(ANDROID_LOG_ERROR, "maleitest", __VA_ARGS__)

struct MLTIME {
    void (*pNew_MLTIME)(const char* l, struct MLTIME* this);
    void (*pDelete_MLTIME)(struct MLTIME* this);

    struct timeval t_start;
    struct timeval t_end;
    const char* label;
};

void con_MLTIME(const char* l, struct MLTIME* this)
{
    this->label = l;
    gettimeofday(&this->t_start, 0);
}

void des_MLTIME(struct MLTIME* this)
{
    gettimeofday(&this->t_end, 0);
    long time_diff = (this->t_end.tv_sec - this->t_start.tv_sec)*1000 + (this->t_end.tv_usec - this->t_start.tv_usec)/1000;
    LOGE("%s cost time is %ld ms", this->label, time_diff);
    printf("%s cost time is %ld ms\n", this->label, time_diff);
}

// Please replace this function by your code
MVoid LoadImage(MLong *plWidth, MLong *plHeight, MByte **ppImgData, int index, char** argv, int* stride)
{
	// Load image information and data here
    
    *plWidth = atoi(argv[5]);
    *plHeight = atoi(argv[6]);
    *stride = atoi(argv[12]);
    int size = (*stride) * (*plHeight) * 3 / 2;
    *ppImgData = malloc(size);
    
    FILE* fp = fopen(argv[index + 1], "r");
    fread(*ppImgData, size, 1, fp);
    fclose(fp);
}

#define ARC_LLS_MAX_INPUT_IMAGE_NUM_BAK ARC_LLS_MAX_INPUT_IMAGE_NUM
#undef ARC_LLS_MAX_INPUT_IMAGE_NUM
#define ARC_LLS_MAX_INPUT_IMAGE_NUM 3

int main(int argc, char** argv)
{
    if(argc != 13)
    {
        printf("usage: %s intput0.nv21, input1.nv21, input2.nv21, output.nv21, width, height, iso, intensity, lightIntensity, saturation, sharpenIntensity, stride",
                argv[0]);
                
        LOGE("usage: %s intput0.nv21, input1.nv21, input2.nv21, output.nv21, width, height, iso, intensity, lightIntensity, saturation, sharpenIntensity",
                argv[0]);
                
        return -1;
    }
    
    	//Get The ISO
	MInt32 iso = atoi(argv[7]);
    
	MRESULT res = MOK;	
	MHandle hEnhancer = MNull;
	ARC_LLS_INPUTINFO SrcInput;
	ASVLOFFSCREEN SrcImgs[ARC_LLS_MAX_INPUT_IMAGE_NUM];
	ASVLOFFSCREEN DstImg;
	ARC_LLS_PARAM param;

    
    param.i32Intensity = atoi(argv[8]);      
    param.i32LightIntensity = atoi(argv[9]);   
    param.i32Saturation = atoi(argv[10]);       
    param.i32SharpenIntensity = atoi(argv[11]); 

	MLong i, lWidth, lHeight, stride;
	MByte *pImgData;

	// Fill source images off-screen
	for(i = 0; i < ARC_LLS_MAX_INPUT_IMAGE_NUM; i++)
	{
		LoadImage(&lWidth, &lHeight, &pImgData, i, argv, &stride);

		SrcImgs[i].i32Width = lWidth;
		SrcImgs[i].i32Height = lHeight;
		SrcImgs[i].u32PixelArrayFormat = ASVL_PAF_NV21;
		SrcImgs[i].pi32Pitch[0] = stride;
		SrcImgs[i].pi32Pitch[1] = stride;
		SrcImgs[i].pi32Pitch[2] = 0;
		SrcImgs[i].ppu8Plane[0] = pImgData;
		SrcImgs[i].ppu8Plane[1] = SrcImgs[i].ppu8Plane[0] + lHeight*SrcImgs[i].pi32Pitch[0];
		SrcImgs[i].ppu8Plane[2] = 0;
	}
	// Fill source images off-screen
	DstImg.i32Width = lWidth;
	DstImg.i32Height = lHeight;
	DstImg.u32PixelArrayFormat = ASVL_PAF_NV21;
	DstImg.pi32Pitch[0] = stride;
	DstImg.pi32Pitch[1] = stride;
	DstImg.pi32Pitch[2] = 0;
	DstImg.ppu8Plane[0] =(MByte*)MMemAlloc(MNull, lHeight * DstImg.pi32Pitch[0] * 3 / 2);
	DstImg.ppu8Plane[1] = DstImg.ppu8Plane[0] + lHeight*DstImg.pi32Pitch[0];
	DstImg.ppu8Plane[2] = 0;

	res = ARC_LLS_Init(&hEnhancer);
	if(MOK != res)
		goto exit;
    
	SrcInput.i32ImgNum = 0;
	for(i = 0; i < ARC_LLS_MAX_INPUT_IMAGE_NUM; i++)
	{
		SrcInput.i32ImgNum++;
		SrcInput.pImages[i] = &SrcImgs[i];
	}
	MInt32 nCamreaType = ARC_LLS_CAMERA_REAR;

	//ARC_LLS_GetDefaultParam(&param,nISO,nCamreaType);
	//MInt32 nRetIndex = -1;
	//if the pDstImg == NULL,the nRetIndex will save in the pSrcImgs->pImages[nRetIndex]
    struct MLTIME tt;
    tt.pNew_MLTIME = con_MLTIME;
    tt.pDelete_MLTIME = des_MLTIME;
    
    tt.pNew_MLTIME("ARC_LLS_Process", &tt);

	res = ARC_LLS_Process(hEnhancer, &SrcInput, &DstImg, NULL, &param, iso, nCamreaType);

    tt.pDelete_MLTIME(&tt);

    printf("ARC_LLS_Process res = %ld, iso: %d, param:{%2d, %2d, %2d, %2d}\n", res, iso, param.i32Intensity, param.i32LightIntensity, param.i32Saturation, param.i32SharpenIntensity);
    
    LOGE("ARC_LLS_Process res = %ld, iso: %d, param:{%2d, %2d, %2d, %2d}\n", res, iso, param.i32Intensity, param.i32LightIntensity, param.i32Saturation, param.i32SharpenIntensity);
    
	if(MOK != res)
		goto exit;

	// Save DstImg to file or other operations

    FILE* fp = fopen(argv[4], "w");
    fwrite(DstImg.ppu8Plane[0], stride*lHeight*3/2, 1, fp);
    fclose(fp);
    
exit:
	ARC_LLS_Uninit(&hEnhancer);
	if(DstImg.ppu8Plane[0])
		MMemFree(MNull, DstImg.ppu8Plane[0]);
	for(i = 0; i < ARC_LLS_MAX_INPUT_IMAGE_NUM; i++) {
		if(SrcImgs[i].ppu8Plane[0])
			MMemFree(MNull, SrcImgs[i].ppu8Plane[0]);
	}
	return res;
}

#undef ARC_LLS_MAX_INPUT_IMAGE_NUM
#define ARC_LLS_MAX_INPUT_IMAGE_NUM ARC_LLS_MAX_INPUT_IMAGE_NUM_BAK 