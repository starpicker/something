/*******************************************************************************
Copyright(c) ArcSoft, All right reserved.

This file is ArcSoft's property. It contains ArcSoft's trade secret, proprietary 
and confidential information. 

The information and code contained in this file is only for authorized ArcSoft 
employees to design, create, modify, or review.

DO NOT DISTRIBUTE, DO NOT DUPLICATE OR TRANSMIT IN ANY FORM WITHOUT PROPER 
AUTHORIZATION.

If you are not an intended recipient of this file, you must not copy, 
distribute, modify, or take any action in reliance on it. 

If you have received this file in error, please immediately notify ArcSoft and 
permanently delete the original and any copy of any file and any printout 
thereof.
*******************************************************************************/
#ifndef _ARCSOFT_LOW_LIGHT_SHOT_H_
#define _ARCSOFT_LOW_LIGHT_SHOT_H_

#include "amcomdef.h"
#include "asvloffscreen.h"
#include "merror.h"
#include "ammem.h"


#ifdef LOWLIGHTSHOTDLL_EXPORTS
#define LOWLIGHTSHOT_API __declspec(dllexport)
#else
#define LOWLIGHTSHOT_API
#endif

#ifdef __cplusplus
extern "C" {
#endif

/************************************************************************
* This function is implemented by the caller, registered with
* any time-consuming processing functions, and will be called
* periodically during processing so the caller application can
* obtain the operation status (i.e., to draw a progress bar),
* as well as determine whether the operation should be canceled or not
************************************************************************/
typedef MRESULT (*ARC_LLS_FNPROGRESS) (
	MLong		i32Progress,			// The percentage of the current operation
	MLong		i32Status,				// The current status at the moment
	MVoid		*pUserData				// Caller-defined data
);

/************************************************************************
* This function is used to get version information of library
************************************************************************/
LOWLIGHTSHOT_API const MPBASE_Version *ARC_LLS_GetVersion();

/************************************************************************
* This function is used to get default parameters of library
************************************************************************/
typedef struct _tag_ARC_LLS_PARAM {
	MInt32      i32Intensity; 		//Range is [0,100], default is 40.
	MInt32      i32LightIntensity; 	//Range is [0,100], default is 30.
	MInt32      i32Saturation; 		//Range is [0,100], default is 50.
	MInt32		i32SharpenIntensity;//Range is [0,100], default is 40
} ARC_LLS_PARAM, *LPARC_LLS_PARAM;

//the camera type
#define ARC_LLS_CAMERA_REAR		0
#define ARC_LLS_CAMERA_FRONT	1

// [in]  cameratype ,ARC_LLS_CAMERA_REAR and ARC_LLS_CAMERA_FRONT
LOWLIGHTSHOT_API MRESULT ARC_LLS_GetDefaultParam(LPARC_LLS_PARAM pParam,MInt32 isoValue,MInt32 cameratype);

/************************************************************************
* The functions is used to perform image night shot
************************************************************************/
#define ARC_LLS_MAX_INPUT_IMAGE_NUM		6
typedef struct _tag_ARC_LLS_INPUTINFO {
	MInt32				i32ImgNum;
	LPASVLOFFSCREEN		pImages[ARC_LLS_MAX_INPUT_IMAGE_NUM];
} ARC_LLS_INPUTINFO, *LPARC_LLS_INPUTINFO;


LOWLIGHTSHOT_API MRESULT ARC_LLS_Init(	// return MOK if success, otherwise fail
	MHandle				*phHandle		// [out] The algorithm engine will be initialized by this API
);

LOWLIGHTSHOT_API MRESULT ARC_LLS_Uninit(	// return MOK if success, otherwise fail
	MHandle				*phHandle			// [in/out] The algorithm engine will be un-initialized by this API
);

LOWLIGHTSHOT_API MRESULT ARC_LLS_Process(	// return MOK if success, otherwise fail
	MHandle				hHandle,			// [in]  The algorithm engine
	LPARC_LLS_INPUTINFO	pSrcImgs,			// [in]  The offscreen of source images
	LPASVLOFFSCREEN		pDstImg,			// [out] The offscreen of result image,this can be NULL
	MInt32				*pRetIndexInSrcImgs,// [out] if the pDstImg == NULL,the result will save in the pSrcImgs->pImages[*pRetIndexInSrcImgs]
	LPARC_LLS_PARAM		pParam,				// [in]  The parameters for algorithm engine
	MInt32 				isoValue,       	// [in]  The Value of ISO
	MInt32 				cameratype     		// [in]  The Camera type,ARC_LLS_CAMERA_REAR and ARC_LLS_CAMERA_FRONT

);

LOWLIGHTSHOT_API MVoid  ARC_LLS_SetCallback(
	MHandle				hHandle,			// [in]  The algorithm engine
	ARC_LLS_FNPROGRESS	fnCallback,			// [in]  The callback function
	MVoid				*pUserData	);

#ifdef __cplusplus
}
#endif

#endif // _ARCSOFT_LOWLIGHTSHOT_H_
