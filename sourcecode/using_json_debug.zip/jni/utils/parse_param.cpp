#include <vector>

#include<stdio.h>
#include<string.h>
#include<stdlib.h>

#include"cJSON.h"

#include "param.h"

using std::vector;
using std::pair;

#include <sys/stat.h>
unsigned long get_file_size(const char *path)
{
    unsigned long filesize = -1;
    struct stat statbuff;
    if(stat(path, &statbuff) < 0){
        return filesize;
    }else{
        filesize = statbuff.st_size;
    }
    return filesize;
}

map<string, string> g_strMap;
map<string, int> g_intMap;

int parse_param(const char* jsonPath)
{
    const char* json = jsonPath;
    int size = get_file_size(json);
    char* param =  (char*)malloc(size);
    FILE* fp = fopen(json, "r");
    fread(param, size, 1, fp);
    fclose(fp);

    
    cJSON *jsonData = cJSON_Parse(param);
    cJSON *node = NULL;
    
    vector<string> strV;
    
    strV.push_back("calibration data" );
                   
    strV.push_back("teleRTB.nv21"     );
    strV.push_back("wideRTB.nv21"     );
    strV.push_back("outRTB.nv21"      );
                   
    strV.push_back("telePP.nv21"      );
    strV.push_back("widePP.nv21"      );
    strV.push_back("outPP.nv21"       );
    strV.push_back("fov"              );
    
    for(auto iv = strV.begin(); iv != strV.end(); ++iv)
    {
        node = cJSON_GetObjectItem(jsonData, iv->c_str());
        printf("node : %p, str: %s\n", node, iv->c_str());
        if(node == NULL)
        {
            g_strMap[*iv] = "";
        }
        else
        {
            g_strMap.insert(pair<string, string>(*iv, node->valuestring));
        }
    }
    
    // for(auto im = g_strMap.begin(); im != g_strMap.end(); ++im)
    // {
        // printf("%-22s: %s\n", im->first.c_str(), im->second.c_str());
    // }
        
    
    vector<string> intV;
    
    intV.push_back("teleWidthRTB"       );
    intV.push_back("teleHeightRTB"      );
    intV.push_back("teleStrideRTB"      );
    intV.push_back("teleScanlineRTB"    );
    intV.push_back("wideWidthRTB"       );
    intV.push_back("wideHeightRTB"      );
    intV.push_back("wideStrideRTB"      );
    intV.push_back("wideScanlineRTB"    );

    intV.push_back("teleWidthPP"        );
    intV.push_back("teleHeightPP"       );
    intV.push_back("teleStridePP"       );
    intV.push_back("teleScanlinePP"     );
    intV.push_back("wideWidthPP"        );
    intV.push_back("wideHeightPP"       );
    intV.push_back("wideStridePP"       );
    intV.push_back("wideScanlinePP"     );
    
    intV.push_back("degreeRTB"          );
    intV.push_back("degreePP"           );
           
    intV.push_back("refocus"            );
           
    intV.push_back("intensityRTB"       );
    intV.push_back("intensityPP"        );
           
    intV.push_back("focuXRTB"           );
    intV.push_back("focuYRTB"           );
           
    intV.push_back("focuXPP"            );
    intV.push_back("focuYPP"            );
    
    intV.push_back("fullTeleWidthRTB"   );
    intV.push_back("fullTeleHeightRTB"  );
                                       
    intV.push_back("fullWideWidthRTB"   );
    intV.push_back("fullWideHeightRTB"  );
                                       
    intV.push_back("fullTeleWidthPP"    );
    intV.push_back("fullTeleHeightPP"   );
                                       
    intV.push_back("fullWideWidthPP"    );
    intV.push_back("fullWideHeightPP"    );
    
    intV.push_back("facenum"            );
    intV.push_back("face0x"             );
    intV.push_back("face0y"             );
    intV.push_back("face0z"             );
    intV.push_back("face0w"             );
    intV.push_back("face1x"             );
    intV.push_back("face1y"             );
    intV.push_back("face1z"             );
    intV.push_back("face1w"             );
    intV.push_back("face2x"             );
    intV.push_back("face2y"             );
    intV.push_back("face2z"             );
    intV.push_back("face2w"             );
    intV.push_back("face3x"             );
    intV.push_back("face3y"             );
    intV.push_back("face3z"             );
    intV.push_back("face3w"             );
    intV.push_back("face4x"             );
    intV.push_back("face4y"             );
    intV.push_back("face4z"             );
    intV.push_back("face4w"             );
    intV.push_back("face5x"             );
    intV.push_back("face5y"             );
    intV.push_back("face5z"             );         
    intV.push_back("face5w"             );

    for(auto iv = intV.begin(); iv != intV.end(); ++iv)
    {
        node = cJSON_GetObjectItem(jsonData, iv->c_str());

        if(node == NULL)
        {
            g_intMap[*iv] = 0;
        }
        else
        {
            g_intMap.insert(pair<string, int>(*iv, atoi(node->valuestring)));
        }
    }
    
    // for(auto im = g_intMap.begin(); im != g_intMap.end(); ++im)
    // {
        // printf("%-22s: %d\n", im->first.c_str(), im->second);
    // }

    free(param);

    return 0;
}

//int main()
//{
    //parse_param("param.json");
    
    //return 0;
//}
