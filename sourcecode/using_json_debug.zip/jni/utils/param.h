#pragma once

#include <string>
#include <map>
using std::string;
using std::map;

extern map<string, string> g_strMap;
extern map<string, int> g_intMap;
