#include <stdio.h>
#include <fcntl.h>
#include <string.h>
#include <unistd.h>

#include "utils.h"

void dumpOffscreen2File(ASVLOFFSCREEN* pAsvl, const char* name)
{
    char filename[256];
    memset(filename, 0, sizeof(char)*256);

    snprintf(filename, sizeof(filename), "%s_%dx%d.nv21", name, pAsvl->i32Width, pAsvl->i32Height);

   int file_fd;
   
   file_fd = open(filename, O_RDWR | O_CREAT, 0777);
   
   if(file_fd > 0)
   {
     ssize_t writen_bytes = 0;
     writen_bytes = write(file_fd, pAsvl->ppu8Plane[0], pAsvl->pi32Pitch[0] * pAsvl->i32Height);//only for NV21 or NV12
     writen_bytes = write(file_fd, pAsvl->ppu8Plane[1], pAsvl->pi32Pitch[1] * (pAsvl->i32Height >> 1));//only for NV21 or NV12
     close(file_fd);
   }
}
