#ifndef __IMAGE_REFOCUS_H__
#define __IMAGE_REFOCUS_H__

#include "utils.h"
#include "arcsoft_dualcam_image_refocus.h"

class ImageFocus
{
public:
    ImageFocus();
    ~ImageFocus();
    
public:
    MRESULT init(MInt32 focusMode);
    
    void setCaldata(MVoid* data, MInt32 size);
    
    void setImgDegree(MInt32 degree);
    void setMaxFov(MFloat maxFov);
    void setFaceParam(PMRECT faces, MInt32* faceAngles, MInt32 faceNum);
    
    MRESULT calcDispMap(ASVLOFFSCREEN& leftImg, ASVLOFFSCREEN& rightImg);
    
    void setFocusPoint(MPOINT focusPoint);
    void setBlurIntensity(MInt32 blurIntensity);
    MRESULT process(ASVLOFFSCREEN& leftImg, ASVLOFFSCREEN& dstImg);
    void setCameraImageInfo(int leftwidth, int leftheight, int rightwidth, int rightheight);
    void reset(void);

private:

private:
    MHandle engine_;
    MInt32 focusMode_;
    ARC_DCIR_PARAM dcirParam_;
    ARC_DCIR_REFOCUS_PARAM rfParam_;
};

#endif /* __IMAGE_REFOCUS_H__ */