#include <stdlib.h>
#include <string.h>
#include "utils.h"
#include "video_refocus.h"

VideoFocus::VideoFocus()
{
    engine_ = MNull;
    memset(&vrParam_, 0, sizeof(vrParam_));
    
    ARC_DCVR_GetDefaultParam (&vrParam_);
}

VideoFocus::~VideoFocus()
{
    ARC_DCVR_Uninit (&engine_);
}

MRESULT VideoFocus::init(void)
{
    MRESULT res;
    
    res = ARC_DCVR_Init(&engine_);
    
    return res;
}

void VideoFocus::setCaldata(MVoid* data, MInt32 size)
{
    ARC_DC_CALDATA caldata = {data, size};
    
    log("ARC_DCVR_SetCaliData size :%d", size);
    
    ARC_DCVR_SetCaliData(engine_, &caldata);
}

void VideoFocus::setImgDegree(MInt32 degree)
{
    log("ARC_DCVR_SetImageDegree degree :%d", degree);
    
    ARC_DCVR_SetImageDegree(engine_, degree);
}

void VideoFocus::setFocusPoint(MPOINT focusPoint)
{
    vrParam_.ptFocus = focusPoint;
}

void VideoFocus::setBlurLevel(MInt32 blurLevel)
{
    vrParam_.i32BlurLevel = blurLevel;
}

void VideoFocus::setRefocusOn(bool refocusOn)
{
    vrParam_.bRefocusOn = refocusOn;
}

void VideoFocus::setCameraImageInfo(int leftwidth, int leftheight, int rightwidth, int rightheight)
{
    ARC_REFOCUSCAMERAIMAGE_PARAM param = {leftwidth, leftheight, rightwidth, rightheight};
    
    ARC_DCVR_SetCameraImageInfo(engine_, &param);
}

/*	
#include <pthread.h>
#include <stdio.h>
#include <unistd.h>

void* fun(void*)
{
    printf("pthread_self(): %lu, gettid(): %d\n",  pthread_self(), gettid());
    usleep(300*1000*1000);
}
*/
MRESULT VideoFocus::process(ASVLOFFSCREEN& leftImg, ASVLOFFSCREEN& rightImg, ASVLOFFSCREEN& dstImg)
{
    MRESULT res;
    //log("ARC_DCVR_Process engine=0x%X, leftimg=%dx%d_%d, rightimg=%dx%d_%d, dstimg=%dx%d_%d",
    //                engine_, leftImg.i32Width, leftImg.i32Height, leftImg.pi32Pitch[0],
    //                rightImg.i32Width, rightImg.i32Height, rightImg.pi32Pitch[0],
    //                dstImg.i32Width, dstImg.i32Height, dstImg.pi32Pitch[0]);
    
    //pthread_t tid;
    //pthread_create(&tid, NULL, fun, NULL);
    //printf("tid before ARC_DCVR_Process: %lu\n", tid);
    
    res = ARC_DCVR_Process(engine_, &leftImg, &rightImg, &dstImg, &vrParam_);
	log("ARC_DCVR_Process engine=%p, leftimg=%dx%d, stride: %d, rightimg=%dx%d, stride: %d, dstimg=%dx%d, stride: %d, res=%ld",
                   engine_, leftImg.i32Width, leftImg.i32Height, leftImg.pi32Pitch[0],
                   rightImg.i32Width, rightImg.i32Height, rightImg.pi32Pitch[0],
                   dstImg.i32Width, dstImg.i32Height, dstImg.pi32Pitch[0],res);
    
    //pthread_create(&tid, NULL, fun, NULL);
    //printf("tid after ARC_DCVR_Process: %lu\n", tid);
    
    log("ARC_DCVR_Process res: %ld, focuspoint: (%d,%d), blurlevel: %d, refocuson: %ld",
                          res, vrParam_.ptFocus.x, vrParam_.ptFocus.y,
                          vrParam_.i32BlurLevel, vrParam_.bRefocusOn);
    
    //pthread_join(tid, NULL);
    
    return res;
}
