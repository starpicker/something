#include <stdlib.h>
#include <stddef.h>
#include <stdio.h>

#include "video_refocus.h"
#include "utils.h"
#include "param.h"

namespace
{
long nativeInit()
{
    VideoFocus* e = new VideoFocus;
    
    e->init();

    return (long)e;
}

int nativeSetCalibrationData(long engine, char* data, int length)
{
    VideoFocus* e = (VideoFocus*)engine;
    
    //log("nativeSetCalibrationData data length is %d", length);
    
    e->setCaldata(data, length);
        
    return 0;
}

int nativeSetImgDegree(long engine, int degree)
{
    VideoFocus* e = (VideoFocus*)engine;
    
    e->setImgDegree(degree);
    
    return 0;
}

int nativeSetFocusPoint(long engine, int x, int y)
{
    VideoFocus* e = (VideoFocus*)engine;
    
    MPOINT p = {x, y};
    e->setFocusPoint(p);
    
    return 0;
}

int nativeSetBlurLevel(long engine, int blurLevel)
{
    VideoFocus* e = (VideoFocus*)engine;
    
    e->setBlurLevel(blurLevel);
    
    return 0;
}

int nativeSetRefocusOn(long engine, int reFocusOn)
{
    VideoFocus* e = (VideoFocus*)engine;

    bool reFocus = (reFocusOn == 1)?true:false;

    e->setRefocusOn(reFocus);

    return 0;
}

int nativeProcess(long engine,
                             char* leftImg, int leftImgWidth, int leftImgHeight,
                             int leftImgStride, int leftImgScanline,
                             char* rightImg, int rightImgWidth, int rightImgHeight,
                             int rightImgStride, int rightImgScanline, char* dst)
{
    VideoFocus* e = (VideoFocus*)engine;

    ASVLOFFSCREEN imgLeft  = {0};
    ASVLOFFSCREEN imgRight = {0};
    ASVLOFFSCREEN imgDst   = {0};

    int imgLeft_uv_offset = leftImgStride * leftImgScanline;

    imgLeft.u32PixelArrayFormat   = ASVL_PAF_NV21;
    imgLeft.i32Width              = leftImgWidth;
    imgLeft.i32Height             = leftImgHeight;
    imgLeft.ppu8Plane[0]          = (unsigned char*)leftImg;
    imgLeft.ppu8Plane[1]          = imgLeft.ppu8Plane[0] + imgLeft_uv_offset;
    imgLeft.ppu8Plane[2]          = 0;
    imgLeft.pi32Pitch[0]          = leftImgStride;
    imgLeft.pi32Pitch[1]          = leftImgStride;
    imgLeft.pi32Pitch[2]          = leftImgStride;

    int imgRight_uv_offset = rightImgStride * rightImgScanline;

    imgRight.u32PixelArrayFormat  = ASVL_PAF_NV21;
    imgRight.i32Width             = rightImgWidth;
    imgRight.i32Height            = rightImgHeight;
    imgRight.ppu8Plane[0]         = (unsigned char*)rightImg;
    imgRight.ppu8Plane[1]         = imgRight.ppu8Plane[0] + imgRight_uv_offset;
    imgRight.ppu8Plane[2]         = 0;
    imgRight.pi32Pitch[0]         = rightImgStride;
    imgRight.pi32Pitch[1]         = rightImgStride;
    imgRight.pi32Pitch[2]         = 0;

    imgDst.u32PixelArrayFormat    = ASVL_PAF_NV21;
    imgDst.i32Width               = leftImgWidth;
    imgDst.i32Height              = leftImgHeight;
    imgDst.ppu8Plane[0]           = (unsigned char*)dst;
    imgDst.ppu8Plane[1]           = imgDst.ppu8Plane[0] + imgLeft_uv_offset;
    imgDst.ppu8Plane[2]           = 0;
    imgDst.pi32Pitch[0]           = leftImgStride;
    imgDst.pi32Pitch[1]           = leftImgStride;
    imgDst.pi32Pitch[2]           = 0;

    e->process(imgLeft, imgRight, imgDst);
            
    return 0;
}

int nativeUnit(long engine)
{
    VideoFocus* e = (VideoFocus*)engine;

    delete e;

    return 0;
}

int nativeSetCameraImageInfo(long engine, int leftWidth, int leftHeight, int rightWidth, int rightHeight)
{
    VideoFocus* e = (VideoFocus*)engine;
    
    e->setCameraImageInfo(leftWidth, leftHeight, rightWidth, rightHeight);
    
    return 0;
}
}
int test_preview(void)
{   
    const char* cali   = g_strMap["calibration data"].c_str();
    
    const char* tele   = g_strMap["teleRTB.nv21"].c_str(); 
    int teleW          = g_intMap["teleWidthRTB"];
    int teleH          = g_intMap["teleHeightRTB"];
    int teleSt         = g_intMap["teleStrideRTB"];
    int teleSc         = g_intMap["teleScanlineRTB"];
    
    const char* wide   = g_strMap["wideRTB.nv21"].c_str();
    int wideW          = g_intMap["wideWidthRTB"];
    int wideH          = g_intMap["wideHeightRTB"];
    int wideSt         = g_intMap["wideStrideRTB"];
    int wideSc         = g_intMap["wideScanlineRTB"];
    
    const char* out    = g_strMap["outRTB.nv21"].c_str();
    int degree         = g_intMap["degreeRTB"];
    int reFocusOn      = g_intMap["refocus"];
    
    int focuX          = g_intMap["focuXRTB"];
    int focuY          = g_intMap["focuYRTB"];
    
    int fullTeleW      = g_intMap["fullTeleWidthRTB"];
    int fullTeleH      = g_intMap["fullTeleHeightRTB"];
    
    int fullWideW      = g_intMap["fullWideWidthRTB"];
    int fullWideH      = g_intMap["fullWideHeightRTB"];
    
    int intensity      = g_intMap["intensityRTB"];
    
    if(teleSt == 0)teleSt = teleW;
    if(teleSc == 0)teleSc = teleH;
    if(wideSt == 0)wideSt = wideW;
    if(wideSc == 0)wideSc = wideH;
    if(fullTeleW == 0)fullTeleW = teleW;
    if(fullTeleH == 0)fullTeleH = teleH;
    if(fullWideW == 0)fullWideW = wideW;
    if(fullWideH == 0)fullWideH = wideH;
    
    
    printf("preview bokeh params:\n");
    printf("%-22s: %s\n", "cali", cali);
    
    printf("%-22s: %s\n", "tele", tele);
    printf("%-22s: %d\n", "teleW", teleW);
    printf("%-22s: %d\n", "teleH", teleH);
    printf("%-22s: %d\n", "teleSt", teleSt);
    printf("%-22s: %d\n", "teleSc", teleSc);
    
    printf("%-22s: %s\n", "wide", wide);
    printf("%-22s: %d\n", "wideW", wideW);
    printf("%-22s: %d\n", "wideH", wideH);
    printf("%-22s: %d\n", "wideSt", wideSt);
    printf("%-22s: %d\n", "wideSc", wideSc);
    
    printf("%-22s: %s\n", "out", out);
    printf("%-22s: %d\n", "degree", degree);
    printf("%-22s: %d %s\n", "reFocusOn", reFocusOn, (reFocusOn==0)?"has no meaning":"");
    
    printf("%-22s: %d\n", "focuX", focuX);
    printf("%-22s: %d\n", "focuY", focuY);
    
    printf("%-22s: %d\n", "fullTeleW", fullTeleW);
    printf("%-22s: %d\n", "fullTeleH", fullTeleH);
    
    printf("%-22s: %d\n", "fullWideW", fullWideW);
    printf("%-22s: %d\n", "fullWideH", fullWideH);
    
    printf("%-22s: %d\n", "intensity", intensity);
    
    
    printf("press enter to continue\n");
    
    getchar();
    
	long h = nativeInit();
        
    FILE* fp = fopen(cali, "r");
    char calidata[2048];
    fread(calidata, 1, 2048, fp);
    fclose(fp);

    nativeSetCalibrationData(h, calidata, sizeof(calidata));
    nativeSetImgDegree(h, degree);
    nativeSetCameraImageInfo(h, fullTeleW, fullTeleH, fullWideW, fullWideH);
    nativeSetBlurLevel(h, intensity);
    nativeSetRefocusOn(h, reFocusOn);
    nativeSetFocusPoint(h, focuX, focuY);
    
    fp = fopen(tele, "r");
    char* teledata = (char*)malloc(teleSt*teleSc*3/2);
    char* outdata = (char*)malloc(teleSt*teleSc*3/2);
    fread(teledata, 1, teleSt*teleSc*3/2, fp);
    fclose(fp);

    fp = fopen(wide, "r");
    char* widedata = (char*)malloc(wideSt*wideSc*3/2);
    fread(widedata, 1, wideSt*wideSc*3/2, fp);
    fclose(fp);
                            
    nativeProcess(h, teledata, teleW, teleH, teleSt, teleSc,
                     widedata, wideW, wideH, wideSt, wideSc,
                     outdata);
    
    nativeUnit(h);
        
    fp = fopen(out, "w");
    fwrite(outdata, 1, teleSt*teleSc*3/2, fp);
    fclose(fp);

    return 0;
}
