#include <stdlib.h>
#include <stddef.h>
#include <stdio.h>
#include <string.h>

#include "image_refocus.h"
#include "utils.h"
#include "param.h"

long nativeInit(int focusMode)
{
    ImageFocus* e = new ImageFocus;

    e->init(focusMode);

    return (long)e;
}

int nativeSetCalibrationData(long engine, char* data, int len)
{
    ImageFocus* e = (ImageFocus*)engine;

    char* arr = data;
    int length = len;

    //log("nativeSetCalibrationData data length is %d", length);

    e->setCaldata(arr, length);

    return 0;
}

int nativeSetImgDegree(long engine, int degree)
{
    ImageFocus* e = (ImageFocus*)engine;

    e->setImgDegree(degree);

    return 0;
}

int nativeSetMaxFov(long engine, float maxFov)
{
    ImageFocus* e = (ImageFocus*)engine;

    e->setMaxFov(maxFov);

    return 0;
}

int nativeSetCameraImageInfo(long engine, int leftWidth, int leftHeight, int rightWidth, int rightHeight)
{
    ImageFocus* e = (ImageFocus*)engine;

    e->setCameraImageInfo(leftWidth, leftHeight, rightWidth, rightHeight);

    return 0;
}

int nativeReset(long engine)
{
    ImageFocus* e = (ImageFocus*)engine;

    e->reset();

    return 0;
}

int nativeSetFaceParam(long engine, int* faceRects, int faceNUm, int* faceAngles)
{
    ImageFocus* e = (ImageFocus*)engine;

    int length = faceNUm;

    // hard code now to ease work
    static MRECT st_faces[32];
    static MInt32 st_faceAngles[32];
    if(length > 32) return -1;

    int* rects = faceRects;
    int* angles = faceAngles;

    memcpy(st_faces, rects, length * sizeof(MRECT));
    memcpy(st_faceAngles, angles, length * sizeof(MInt32));

    e->setFaceParam(st_faces, st_faceAngles, length);

    return 0;
}

int nativeCalcDisparityMap(long engine,
                                      char* leftImg, int leftImgWidth, int leftImgHeight,
                                      int leftImgStride, int leftImgScanline,
                                      char* rightImg, int rightImgWidth, int rightImgHeight,
                                      int rightImgStride, int rightImgScanline)
{
    ImageFocus* e = (ImageFocus*)engine;

    char* left_data  = leftImg;
    char* right_data = rightImg;

    ASVLOFFSCREEN imgLeft  = {0};
    ASVLOFFSCREEN imgRight = {0};

    int imgLeft_uv_offset = leftImgStride*leftImgScanline;

    imgLeft.u32PixelArrayFormat  = ASVL_PAF_NV21;
    imgLeft.i32Width             = leftImgWidth;
    imgLeft.i32Height            = leftImgHeight;
    imgLeft.ppu8Plane[0]         = (unsigned char*)left_data;
    imgLeft.ppu8Plane[1]         = imgLeft.ppu8Plane[0] + imgLeft_uv_offset;
    imgLeft.ppu8Plane[2]         = 0;
    imgLeft.pi32Pitch[0]         = leftImgStride;
    imgLeft.pi32Pitch[1]         = leftImgStride;
    imgLeft.pi32Pitch[2]         = 0;

    int imgRight_uv_offset = rightImgStride * rightImgScanline;

    imgRight.u32PixelArrayFormat = ASVL_PAF_NV21;
    imgRight.i32Width            = rightImgWidth;
    imgRight.i32Height           = rightImgHeight;
    imgRight.ppu8Plane[0]        = (unsigned char*)right_data;
    imgRight.ppu8Plane[1]        = imgRight.ppu8Plane[0] + imgRight_uv_offset;
    imgRight.ppu8Plane[2]        = 0;
    imgRight.pi32Pitch[0]        = rightImgStride;
    imgRight.pi32Pitch[1]        = rightImgStride;
    imgRight.pi32Pitch[2]        = 0;

    log("left image left_data: %p, width: %d, height: %d, stride: %d, scanline: %d",
            left_data, leftImgWidth, leftImgHeight, leftImgStride, leftImgScanline);
    log("right image right_data: %p,  width: %d, height: %d, stride: %d, scanline: %d",
            right_data, rightImgWidth, rightImgHeight, rightImgStride, rightImgScanline);

    e->calcDispMap(imgLeft, imgRight);

    return 0;
}

int nativeSetFocusPoint(long engine, int x, int y)
{
    ImageFocus* e = (ImageFocus*)engine;

    MPOINT p = {x, y};
    e->setFocusPoint(p);

    return 0;
}

int nativeSetBlurIntensity(long engine, int blurIntensity)
{
    ImageFocus* e = (ImageFocus*)engine;

    e->setBlurIntensity(blurIntensity);

    return 0;
}

int nativeProcessGetNV21(long engine,
                                    char* leftImg, int leftImgWidth, int leftImgHeight,
                                    int leftImgStride, int leftImgScanline,
                                    char* dstImg, int dstImgStride, int dstImgScanline)
{
    ImageFocus* e = (ImageFocus*)engine;

    char* dst_data = dstImg;

    char* left_data = leftImg;

    ASVLOFFSCREEN imgLeft = {0};
    ASVLOFFSCREEN imgDst  = {0};

    int imgLeft_uv_offset = leftImgStride*leftImgScanline;

    imgLeft.u32PixelArrayFormat  = ASVL_PAF_NV21;
    imgLeft.i32Width             = leftImgWidth;
    imgLeft.i32Height            = leftImgHeight;
    imgLeft.ppu8Plane[0]         = (unsigned char*)left_data;
    imgLeft.ppu8Plane[1]         = imgLeft.ppu8Plane[0] + imgLeft_uv_offset;
    imgLeft.ppu8Plane[2]         = 0;
    imgLeft.pi32Pitch[0]         = leftImgStride;
    imgLeft.pi32Pitch[1]         = leftImgStride;
    imgLeft.pi32Pitch[2]         = 0;

    imgDst.u32PixelArrayFormat   = ASVL_PAF_NV21;
    imgDst.i32Width              = leftImgWidth;
    imgDst.i32Height             = leftImgHeight;
    imgDst.ppu8Plane[0]          = (unsigned char*)dst_data;
    imgDst.ppu8Plane[1]          = imgDst.ppu8Plane[0] + dstImgStride*dstImgScanline;
    imgDst.ppu8Plane[2]          = 0;
    imgDst.pi32Pitch[0]          = dstImgStride;
    imgDst.pi32Pitch[1]          = dstImgStride;
    imgDst.pi32Pitch[2]          = 0;

    e->process(imgLeft, imgDst);

    return 0;
}

int nativeUnit(long engine)
{
    ImageFocus* e = (ImageFocus*)engine;

    delete e;

    return 0;
}

int test_capture(void)
{   
    const char* cali   = g_strMap["calibration data"].c_str();
    
    const char* tele   = g_strMap["telePP.nv21"].c_str(); 
    int teleW          = g_intMap["teleWidthPP"];
    int teleH          = g_intMap["teleHeightPP"];
    int teleSt         = g_intMap["teleStridePP"];
    int teleSc         = g_intMap["teleScanlinePP"];
    
    const char* wide   = g_strMap["widePP.nv21"].c_str();
    int wideW          = g_intMap["wideWidthPP"];
    int wideH          = g_intMap["wideHeightPP"];
    int wideSt         = g_intMap["wideStridePP"];
    int wideSc         = g_intMap["wideScanlinePP"];
    
    float fov          = atof(g_strMap["fov"].c_str());
    
    const char* out    = g_strMap["outPP.nv21"].c_str();
    int degree         = g_intMap["degreePP"];
    
    int focuX          = g_intMap["focuXPP"];
    int focuY          = g_intMap["focuYPP"];
    
    int fullTeleW      = g_intMap["fullTeleWidthPP"];
    int fullTeleH      = g_intMap["fullTeleHeightPP"];
    
    int fullWideW      = g_intMap["fullWideWidthPP"];
    int fullWideH      = g_intMap["fullWideHeightPP"];
    
    int intensity      = g_intMap["intensityPP"];
    
    int facenum        = g_intMap["facenum"];
    
    if(teleSt == 0)teleSt = teleW;
    if(teleSc == 0)teleSc = teleH;
    if(wideSt == 0)wideSt = wideW;
    if(wideSc == 0)wideSc = wideH;
    if(fullTeleW == 0)fullTeleW = teleW;
    if(fullTeleH == 0)fullTeleH = teleH;
    if(fullWideW == 0)fullWideW = wideW;
    if(fullWideH == 0)fullWideH = wideH;
    
    
    printf("capture bokeh params:\n");
    printf("%-22s: %s\n", "cali", cali);
    
    printf("%-22s: %s\n", "tele", tele);
    printf("%-22s: %d\n", "teleW", teleW);
    printf("%-22s: %d\n", "teleH", teleH);
    printf("%-22s: %d\n", "teleSt", teleSt);
    printf("%-22s: %d\n", "teleSc", teleSc);
    
    printf("%-22s: %s\n", "wide", wide);
    printf("%-22s: %d\n", "wideW", wideW);
    printf("%-22s: %d\n", "wideH", wideH);
    printf("%-22s: %d\n", "wideSt", wideSt);
    printf("%-22s: %d\n", "wideSc", wideSc);
    
    printf("%-22s: %s\n", "out", out);
    printf("%-22s: %d\n", "degree", degree);
    
    printf("%-22s: %d\n", "focuX", focuX);
    printf("%-22s: %d\n", "focuY", focuY);
    
    printf("%-22s: %d\n", "fullTeleW", fullTeleW);
    printf("%-22s: %d\n", "fullTeleH", fullTeleH);
    
    printf("%-22s: %d\n", "fullWideW", fullWideW);
    printf("%-22s: %d\n", "fullWideH", fullWideH);
    
    printf("%-22s: %d\n", "intensity", intensity);
    printf("%-22s: %f %s\n", "fov", fov, (fov==0)?"using default!!!":"");
    printf("%-22s: %d ignored!!!\n", "facenum", facenum);
    
    
    printf("press enter to continue\n");
    
    getchar();

	long h = nativeInit(1);

    FILE* fp = fopen(cali, "r");
    char calidata[2048];
    fread(calidata, 1, 2048, fp);
    fclose(fp);

    nativeSetCalibrationData(h, calidata, sizeof(calidata));
    nativeSetImgDegree(h, degree);
    nativeSetMaxFov(h, fov);
    nativeSetCameraImageInfo(h, fullTeleW, fullTeleH, fullWideW, fullWideH);

    fp = fopen(tele, "r");
    char* teledata = (char*)malloc(teleSt*teleSc*3/2);
    char* outdata = (char*)malloc(teleSt*teleSc*3/2);
    memset(outdata, 0, teleSt*teleSc*3/2);
    
    fread(teledata, 1, teleSt*teleSc*3/2, fp);
    fclose(fp);
    fp = fopen(wide, "r");
    char* widedata = (char*)malloc(wideSt*wideSc*3/2);
    fread(widedata, 1, wideSt*wideSc*3/2, fp);
    fclose(fp);
    nativeCalcDisparityMap(h, teledata, teleW, teleH, teleSt, teleSc,
                              widedata, wideW, wideH, wideSt, wideSc);
    nativeSetBlurIntensity(h, intensity);
    nativeSetFocusPoint(h, focuX, focuY);
    //nativeSetFaceParam(...);
    nativeProcessGetNV21(h, teledata, teleW, teleH, teleSt, teleSc,
                            outdata, teleSt, teleSc);
    nativeUnit(h);

    fp = fopen(out, "w");
    fwrite(outdata, 1, teleSt*teleSc*3/2, fp);
    fclose(fp);

    return 0;
}
