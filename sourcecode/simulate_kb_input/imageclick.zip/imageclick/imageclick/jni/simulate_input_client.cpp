//鍙傝�冧簡Linux楂樻�ц兘鏈嶅姟鍣ㄧ紪绋�,chapter-16,16-4stress_client.cpp
#include <stdlib.h>
#include <stdio.h>
#include <assert.h>
#include <unistd.h>
#include <sys/types.h>
#include <sys/epoll.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <string.h>
#include <errno.h>
#include <signal.h>
#include <fcntl.h> //daemonize
// #include <termio.h>
#include <netinet/tcp.h>

#include <mutex>  
#include <condition_variable>  
std::mutex m;  
std::condition_variable cv;  
bool ready = false;
char c = 0;
// #define bool  int
// #define false 0
// #define true  1

int stop = 0;

#include <android/log.h>

#define mllog(...) //__android_log_print(ANDROID_LOG_ERROR, "nativesend", __VA_ARGS__)

//#define mllog(...) {FILE* fp = fopen("/sdcard/0/log.txt", "a");fprintf(fp, __VA_ARGS__);fclose(fp);}

// struct termios stored_settings;
// void initkeyboard(void)
// {
    // struct termios new_settings;
    // tcgetattr(0, &stored_settings);
    // new_settings = stored_settings;
    // new_settings.c_lflag &= (~ICANON);
    // new_settings.c_lflag &= (~ECHO);
    // new_settings.c_cc[VTIME] = 0;
    // tcgetattr(0, &stored_settings);
    // new_settings.c_cc[VMIN] = 1;
    // tcsetattr(0, TCSANOW, &new_settings);
// }

// void unitkeyboard(void)
// {
    // tcsetattr(0, TCSANOW, &stored_settings);
// }

int setnonblocking(int fd)
{
    int old_option = fcntl(fd, F_GETFL);
    int new_option = old_option | O_NONBLOCK;
    fcntl(fd, F_SETFL, new_option);
    return old_option;
}

void addfd(int epoll_fd, int fd)
{
    struct epoll_event event;
    event.data.fd = fd;
    //event.events = EPOLLOUT | EPOLLET | EPOLLERR;
    event.events = EPOLLOUT | EPOLLERR;
    epoll_ctl(epoll_fd, EPOLL_CTL_ADD, fd, &event);
    setnonblocking(fd);
}

bool write_nbytes(int sockfd, const char* buffer, int len)
{
    int bytes_write = 0;

    while(1)
    {
        bytes_write = send(sockfd, buffer, len, 0);

        if(bytes_write == -1)
        {
            return false;
        }
        else if(bytes_write == 0)
        {
            return false;
        }

        len -= bytes_write;
        buffer = buffer + bytes_write;

        if(len <= 0)
        {
            return true;
        }
    }
}

bool read_once(int sockfd, char* buffer, int len)
{
    int bytes_read = 0;
    memset(buffer, '\0', len);
    bytes_read = recv(sockfd, buffer, len, 0);

    if(bytes_read == -1)
    {
        return false;
    }
    else if(bytes_read == 0)
    {
        return false;
    }

    //printf("read in %d bytes from socket %d with content: %s\n",
           //bytes_read, sockfd, buffer);
    return true;
}

int start_conn(int epoll_fd, const char* ip, int port)
{
    struct sockaddr_in address;
    bzero(&address, sizeof(address));
    address.sin_family = AF_INET;
    inet_pton(AF_INET, ip, &address.sin_addr);
    address.sin_port = htons(port);
    int sockfd = socket(PF_INET, SOCK_STREAM, 0);

    if(sockfd < 0)
    {
        printf("socket fail\n");
        return -1;
    }

    int on = 1;
    setsockopt(sockfd, IPPROTO_TCP, TCP_NODELAY, (void*)&on,
               sizeof(on));
    int sndlowat = 1;
    setsockopt(sockfd, SOL_SOCKET, SO_SNDLOWAT,
               (const void*) &sndlowat, sizeof(int));

    if(connect(sockfd, (struct sockaddr*)&address,
               sizeof(address)) == 0)
    {
        //printf( "build connection\n");
        addfd(epoll_fd, sockfd);
    }
    else
    {
        perror("create fail\n");
    }

    return 0;
}

void close_conn(int epoll_fd, int sockfd)
{
    epoll_ctl(epoll_fd, EPOLL_CTL_DEL, sockfd, 0);
    close(sockfd);
}

// void signal_exit_func(int signo)
// {
    // printf("exit sig is %d\n", signo);
    // stop = 1;
// }

// void signal_exit_handler()
// {
    // if(0)
    // {
        // struct sigaction sa;
        // memset(&sa, 0, sizeof(sa));
        // sa.sa_handler = signal_exit_func;
        // sigaction(SIGINT, &sa,
                  // NULL);//褰撴寜涓媍trl+c鏃讹紝瀹冪殑鏁堟灉灏辨槸鍙戦�丼IGINT淇″彿
        // sigaction(SIGTERM, &sa, NULL);//kill pid
        // sigaction(SIGQUIT, &sa, NULL);//ctrl+\浠ｈ〃閫�鍑篠IGQUIT
        // //SIGSTOP鍜孲IGKILL淇″彿鏄笉鍙崟鑾风殑,鎵�浠ヤ笅闈袱鍙ヨ瘽鍐欎簡绛変簬娌℃湁鍐�
        // sigaction(SIGKILL, &sa, NULL);//kill -9 pid
        // sigaction(SIGSTOP, &sa, NULL);//ctrl+z浠ｈ〃鍋滄
    // }

    // //#define    SIGTERM        15
    // //#define    SIGKILL        9
    // //kill鍜宬ill -9锛屼袱涓懡浠ゅ湪linux涓兘鏈夋潃姝昏繘绋嬬殑鏁堟灉锛岀劧鑰屼袱鍛戒护鐨勬墽琛岃繃绋嬪嵈澶ф湁涓嶅悓锛屽湪绋嬪簭涓鏋滅敤閿欎簡锛屽彲鑳戒細閫犳垚鑾悕鍏跺鐨勭幇璞°��
    // //鎵цkill pid鍛戒护锛岀郴缁熶細鍙戦�佷竴涓猄IGTERM淇″彿缁欏搴旂殑绋嬪簭銆�
    // //鎵цkill -9 pid鍛戒护锛岀郴缁熺粰瀵瑰簲绋嬪簭鍙戦�佺殑淇″彿鏄疭IGKILL锛屽嵆exit銆俥xit淇″彿涓嶄細琚郴缁熼樆濉烇紝鎵�浠ill -9鑳介『鍒╂潃鎺夎繘绋嬨��
// }

//int main(int argc, char* argv[])
int connect_server(const char* ip, int port)
{
    mllog("connect_server ip: %s, port: %d", ip, port);
    // if(argc != 3)
    // {
        // printf("usage: %s ip port \n", argv[0]);
        // exit(-1);
    // }

    //signal(SIGHUP, SIG_IGN); //寮�鍚殑璇濓紝灏辨崟鑾蜂笉鍒扮粓绔獥鍙ｅ叧闂殑淇″彿浜嗐�傚嵆绐楀彛鍏抽棴锛岃繘绋嬩粛鐒惰繘琛屻��
    //signal(SIGPIPE, SIG_IGN);
    //initkeyboard();
    //signal_exit_handler();
    int maxclients = 1;
    int epoll_fd = epoll_create(
                   1024);  /* 1024 is just a hint for the kernel */
    int res = start_conn(epoll_fd, ip, port);
    if(res != 0)
    {
        std::unique_lock<std::mutex> lk(m);
        cv.wait(lk, []{return false;});
    }
    //epoll_event events[ 10000 ];
    struct epoll_event* events = (struct epoll_event*)malloc(
                                 sizeof(struct epoll_event) * (maxclients));
    char buffer[ 2048 ];

    while(!stop)
    {
        int fds = epoll_wait(epoll_fd, events, maxclients, 2000);

        for(int i = 0; i < fds; i++)
        {
            int sockfd = events[i].data.fd;

            if(events[i].events & EPOLLIN)
            {
                if(! read_once(sockfd, buffer, 2048))
                {
                    close_conn(epoll_fd, sockfd);
                }

                struct epoll_event event;

                //event.events = EPOLLOUT | EPOLLET | EPOLLERR;
                event.events = EPOLLOUT | EPOLLERR;

                event.data.fd = sockfd;

                epoll_ctl(epoll_fd, EPOLL_CTL_MOD, sockfd, &event);
            }
            else if(events[i].events & EPOLLOUT)
            {
                //char c = getchar();
                std::unique_lock<std::mutex> lk(m);  
                cv.wait(lk, []{return ready;});
                
                mllog("sending %c...", c);
                
                if(! write_nbytes(sockfd, &c, 1))
                {
                    close_conn(epoll_fd, sockfd);
                }
                
                ready = false;
                 
                struct epoll_event event;

                //event.events = EPOLLIN | EPOLLET | EPOLLERR;
                //event.events = EPOLLIN | EPOLLERR;
                event.events = EPOLLOUT | EPOLLERR;

                event.data.fd = sockfd;

                epoll_ctl(epoll_fd, EPOLL_CTL_MOD, sockfd, &event);
            }
            else if(events[i].events & EPOLLERR)
            {
                close_conn(epoll_fd, sockfd);
            }
        }
    }

    close(epoll_fd);

    if(events)
    {
        free(events);
    }

    //unitkeyboard();
    //printf("exit!\n");
    return 0;
}
