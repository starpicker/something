#include <jni.h>

#include <stdlib.h>
#include <stddef.h>
#include <stdio.h>
#include <thread>
#include <android/log.h>

#define mllog(...) //__android_log_print(ANDROID_LOG_ERROR, "nativesend", __VA_ARGS__)

#ifndef mllog
//#define mllog(...) {FILE* fp = fopen("/sdcard/0/log.txt", "a");fprintf(fp, __VA_ARGS__);fclose(fp);}
#endif

const char* ipfilepath = "/sdcard/0/ipfilepath.txt";

int connect_server(const char* ip, int port);
char ip[24];
int port;

std::thread worker;
JNIEXPORT void nativeInit(JNIEnv* env, jobject obj)
{
    FILE* fp = fopen(ipfilepath, "r");

    fscanf(fp, "%s %d", ip, &port);
    fclose(fp);
    
    worker = std::thread(connect_server, ip, port);
}

JNIEXPORT void nativeUnit(JNIEnv * env, jobject obj)
{
    worker.join();
}

extern bool ready;
extern char c;
#include <condition_variable>  
extern std::condition_variable cv;  

JNIEXPORT void native_send(JNIEnv* env, jobject obj, jint ch)
{
    ready = true;
    c = static_cast<char>(ch);
    cv.notify_one();
}

const char* const Java_class = "com/example/imageclick/nativesend";

static JNINativeMethod gMethods[] = {
    {"nativeInit", "()V", (void*) nativeInit},
    {"native_send", "(I)V", (void*) native_send},
    {"nativeUnit", "()V", (void*) nativeUnit},
	
};

static int RegisterNativeMethods(JNIEnv* env, const char* className,
                                 JNINativeMethod* gMethods, int numMethods)
{
    jclass clazz;
    clazz = env->FindClass(className);
    
    if (clazz == NULL)
    {
        return JNI_FALSE;
    }
    if (env->RegisterNatives(clazz, gMethods, numMethods) < 0)
    {
        return JNI_FALSE;
    }
    return JNI_TRUE;
}

static void UnregisterNativeMethods(JNIEnv* env, const char* className)
{
    jclass clazz;
    clazz = env->FindClass(className);

    if(clazz == NULL)
        return;

    if(NULL != env)
    {
        env->UnregisterNatives(clazz);
    }
}

JNIEXPORT jint JNICALL JNI_OnLoad(JavaVM* vm, void* reserved)
{
    JNIEnv* env = NULL;

    if(vm->GetEnv((void**)&env, JNI_VERSION_1_4) != JNI_OK)
    {
        return -1;
    }

    jint ret = RegisterNativeMethods(env, Java_class, gMethods,
            sizeof(gMethods) / sizeof(gMethods[0]));

    if(ret != JNI_TRUE)
    {
        return -1;
    }
    
    return JNI_VERSION_1_4;
}

JNIEXPORT void JNICALL JNI_OnUnload(JavaVM* vm, void* reserved)
{
    JNIEnv* env = NULL;
    if(vm->GetEnv((void**)&env, JNI_VERSION_1_4) != JNI_OK)
        return;

    UnregisterNativeMethods(env, Java_class);
}
