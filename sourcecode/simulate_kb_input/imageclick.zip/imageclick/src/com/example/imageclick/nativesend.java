package com.example.imageclick;

public class nativesend {
	public native void nativeInit();
	public native void native_send(int ch);
	public native void nativeUnit();
}
