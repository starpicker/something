package com.example.imageclick;

import android.os.Bundle;
import android.app.Activity;
import android.view.Menu;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.ImageView;

public class MainActivity extends Activity implements OnClickListener{

	private nativesend ns = new nativesend();
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        
        ns.nativeInit();
        //ns.native_send(0);
        //ns.nativeUnit();  
        
        ImageView iv0 = (ImageView) findViewById(R.id.image_view_0);
        iv0.setOnClickListener(this);
        ImageView iv1 = (ImageView) findViewById(R.id.image_view_1);
        iv1.setOnClickListener(this);
        ImageView iv2 = (ImageView) findViewById(R.id.image_view_2);
        iv2.setOnClickListener(this);
        ImageView iv3 = (ImageView) findViewById(R.id.image_view_3);
        iv3.setOnClickListener(this);
        ImageView iv4 = (ImageView) findViewById(R.id.image_view_4);
        iv4.setOnClickListener(this);
        ImageView iv5 = (ImageView) findViewById(R.id.image_view_5);
        iv5.setOnClickListener(this);
    }
    
    int ch;
    @Override
    public void onClick(View v) {
        // TODO Auto-generated method stub
        switch (v.getId()) {
        case R.id.image_view_0:
        	ch = 'h';
            break;
        case R.id.image_view_1:
        	ch = 'j';
            break;
        case R.id.image_view_2:
        	ch = 'l';
            break;
        case R.id.image_view_3:
        	ch = 'k';
            break;
        case R.id.image_view_4:
        	ch = 'v';
            break;
        case R.id.image_view_5:
        	ch = 10;
            break;
        }
        
        ns.native_send(ch);
    }
    
    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.main, menu);
        return true;
    }
    
    static {
        System.loadLibrary("native_send");
    }
    
}
