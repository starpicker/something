#include <stdio.h>
#include <unistd.h>
#include <stdlib.h>

#include "backward.cpp"
// #include "backward.hpp"

void func_bad_luck(void)
{
    char* p1 = (char*)0x888;
        
    printf("*p1 is %d\n", *p1);
}

int main(int argc, char*argv[])
{
    int a = 0;
    
    printf("a is %d\n", a);
    
    printf("*a is %d\n", *((char*)a));
    
    char* p = 0;
    
    printf("*p is %d\n", *p);
    
    
    func_bad_luck();

    
    return 0;
}
