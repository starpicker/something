#ifndef TIMEOUT_ML_
#define TIMEOUT_ML_

#include "timeout_mgr.h"

//instead of using this to avoid multi inherit problem
// dont use timeoutML in sdk now
class timeoutML
{
public:
    timeoutML(void* object, time_t timeoutSpan)
    {
        if(timeoutSpan <= 0)
        {
           bCheck_ = false; 
        }
        else
        {
            bCheck_ = true;
            tmd = SINGLETON_INSTANCE(TimeoutMgr);
            tmd->addTimeoutCheck(object, timeoutSpan);   
        }
    }
    
    timeoutML()
    {
        bCheck_ = false;
    }
    
virtual ~timeoutML()
    {
        // for direct inherit
        if(bCheck_)tmd->removeTimeoutCheck(this);
    }

protected:
    __attribute__((unused))
    int breathe_air(void)
    {
        // no time
        if(bCheck_)
        {
            tmd->updateActiveTime(this, time(NULL));
            return 0;
        }
        else
        {
            return -1;   
        }
    }
    
public:
    __attribute__((unused))
    bool dead_still(void)
    {
        if(!bCheck_)
        {
            return false;
        }
        else
        {
            return tmd->getTimeoutResult(this);
        }
    }

private:
    TimeoutMgr* tmd;
    bool bCheck_;
    
private:
    timeoutML(timeoutML&&) = delete;
    timeoutML& operator =(timeoutML&&) = delete;
    timeoutML(const timeoutML&) = delete;
    timeoutML& operator =(const timeoutML&) = delete;
};

class timerML
{
public:
    timerML():bCheck_(false){}
    timerML(bool iter, TimeoutMgr::handler_t handler, void* object)
    {
        bCheck_ = true;
        tmd = SINGLETON_INSTANCE(TimeoutMgr);
        tmd->addTimer(object, handler, iter);
    }

    // for multi inherit
    void removeTimeoutCheck(void* p){if(bCheck_)tmd->removeTimeoutCheck(p);}
virtual ~timerML()
    {
        // for single inherit
        // this may has problem, comment it out
        //if(bCheck_)tmd->removeTimeoutCheck(this);
    }

private:
    TimeoutMgr* tmd;
    bool bCheck_;
    
private:
    timerML(timerML&&) = delete;
    timerML& operator =(timerML&&) = delete;
    timerML(const timerML&) = delete;
    timerML& operator =(const timerML&) = delete;
};

#endif // TIMEOUT_ML_
