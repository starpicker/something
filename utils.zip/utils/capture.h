#include <string>
using std::string;

int capture(const string srcIp, short sourcePort,
               const string dstIp, short dstPort,
               int number, const string keyword);
