#ifndef UTILS_H__
#define UTILS_H__

class Utils
{
public:
    static int uchar2Int(unsigned char* b, int len);
    static void Int2uchar(int value, unsigned char dst[4]);
private:
    Utils();
    ~Utils();
};

#endif // UTILS_H__
