/*----------------------------------------------------------------------------------------------
*
* This file is ArcSoft's property. It contains ArcSoft's trade secret, proprietary and
* confidential information.
*
* The information and code contained in this file is only for authorized ArcSoft employees
* to design, create, modify, or review.
*
* DO NOT DISTRIBUTE, DO NOT DUPLICATE OR TRANSMIT IN ANY FORM WITHOUT PROPER AUTHORIZATION.
*
* If you are not an intended recipient of this file, you must not copy, distribute, modify,
* or take any action in reliance on it.
*
* If you have received this file in error, please immediately notify ArcSoft and
* permanently delete the original and any copy of any file and any printout thereof.
*
*---------------------------------------------------------------------------------------------*/
#ifndef _HTTP_SOCKET
#define _HTTP_SOCKET

#include "def.h"

#include <string>

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <errno.h>
#include <unistd.h>
#include <netinet/in.h>
#include <limits.h>
#include <netdb.h>
#include <arpa/inet.h>
#include <ctype.h>

#define MAX_HEADER_SIZE 1024
#define HTTP_PROTOCOL_MAX_LINE_LENGTH  8192

class  CHttpSocket
{
public:
    int                               GetResponseCode();
    int                               GetField(const char* szSession, char* szValue);
    int                               GetResponseLine(char* pLine, int nMaxLength);
    bool                              ParseResponseHeader(int sock = -1);

    const char*                       FormatRequestHeader(const char* pServer,const char* url,long& Length,
                                                                  char* pCookie = NULL, char* pReferer = NULL);

    int                               GetRequestHeader(char* pHeader, int nMaxLength) const;
    bool                              SendRequest(const char* pRequestHeader = NULL, long Length = 0);
    
                                      CHttpSocket();
    virtual                           ~CHttpSocket();
    
    bool                              SetTimeout(int nTime, int nType = 0);
    long                              Receive(char* pBuffer, long nMaxLength);
    long                              RecvDownloadData(char* pBuffer, long nMaxLength);
    bool                              Connect(const char* szHostName, int nPort = 80);
    bool                              Socket();
    bool                              CloseSocket();
    long                              getContentLength();
    int                               GetResponseBody(char* body);
    bool                              isChunked();
    long                              Send(const char* pRequestHeader, long Length);
    const char*                       FormatPostHeader(const char* url, const char* host, long contentLen, long& Length);
    int                               SocketServer(int port);
    int                               Accept();

protected:
    char                              m_requestheader[MAX_HEADER_SIZE];
    char                              m_ResponseHeader[MAX_HEADER_SIZE];
    char                              m_ResponseBody[MAX_HEADER_SIZE];
    int                               m_port;
    char                              m_ipaddr[256];
    bool                              m_bConnected;
    int                               m_socket;
    hostent*                          m_phostent;
    int                               m_nCurIndex;//GetResponsLine();
    bool                              m_bResponsed;
    int                               m_nResponseHeaderSize;
    int                               m_nResponseBodySize;
    long                              mChunkSize;
    long                              mRecvSize;
    long                              mContentLen;
    bool                              mChunkOverFlag;
    bool                              mIsChunked;

private:
    const static int                  TIME_OUT_TIME = 5; // 5 seconds
};

#endif
