#include "mutils.h"

int Utils::uchar2Int(unsigned char* b, int len)
{
    int value = 0;
    int i;
    for(i= 0; i< len; i++)
    {
        value += (*(b+i)& 0xFF) << (8*(3-i));
    }
    return value;
}

void Utils::Int2uchar(int value, unsigned char dst[4])
{
    dst[3] = (unsigned char) ((value & 0x000000ff));
    dst[2] = (unsigned char) ((value & 0x0000ff00) >> 8);
    dst[1] = (unsigned char) ((value & 0x00ff0000) >> 16);
    dst[0] = (unsigned char) ((value & 0xff000000) >> 24);
}
