/*----------------------------------------------------------------------------------------------
*
* This file is ArcSoft's property. It contains ArcSoft's trade secret, proprietary and
* confidential information.
*
* The information and code contained in this file is only for authorized ArcSoft employees
* to design, create, modify, or review.
*
* DO NOT DISTRIBUTE, DO NOT DUPLICATE OR TRANSMIT IN ANY FORM WITHOUT PROPER AUTHORIZATION.
*
* If you are not an intended recipient of this file, you must not copy, distribute, modify,
* or take any action in reliance on it.
*
* If you have received this file in error, please immediately notify ArcSoft and
* permanently delete the original and any copy of any file and any printout thereof.
*
*---------------------------------------------------------------------------------------------*/
#include "httpSocket.h"

#include <ctype.h>

#include <stdlib.h>
#include <netinet/tcp.h>
#include <sys/ioctl.h>
#include <sys/time.h>


CHttpSocket::CHttpSocket()
{
    m_socket                = 0;
    m_phostent              = NULL;
    m_port                  = 80;
    m_bConnected            = false;
    m_nCurIndex             = 0;
    m_bResponsed            = false;
    m_nResponseHeaderSize   = 0;
    m_nResponseBodySize     = 0;
    mChunkSize              = 0;
    mContentLen             = 0;
    mRecvSize               = 0;
    mChunkOverFlag          = false;
    mIsChunked              = false;
    
    memset(m_ipaddr,0,256);
    memset(m_requestheader,0,MAX_HEADER_SIZE);
    memset(m_ResponseHeader,0,MAX_HEADER_SIZE);
    memset(m_ResponseBody,0,MAX_HEADER_SIZE);
}

CHttpSocket::~CHttpSocket()
{
    CloseSocket();
}

bool CHttpSocket::Socket()
{
    struct protoent* ppe;
    ppe = getprotobyname("tcp");
    m_socket = socket(AF_INET, SOCK_STREAM, ppe->p_proto);
    if(m_socket == -1)
    {
        return false;
    }
    
#if 0
    /* Disable the Nagle (TCP No Delay) algorithm */
    int flag , ret;
    ret = setsockopt( m_socket, IPPROTO_TCP, TCP_NODELAY, (char *)&flag, sizeof(flag) );
    if(ret == -1)
    {
        printf("Couldn't setsockopt(TCP_NODELAY)\n");
    }
#endif

    return true;
}

int CHttpSocket::SocketServer(int port)
{
    struct sockaddr_in servaddr;
    if((m_socket = socket(AF_INET, SOCK_STREAM, 0)) == -1)
    {
        printf("create socket error: %s(errno: %d)\n", strerror(errno), errno);
        return -1;
    }
    memset(&servaddr, 0, sizeof(servaddr));
    servaddr.sin_family = AF_INET;
    servaddr.sin_addr.s_addr = htonl(INADDR_ANY);
    servaddr.sin_port = htons(port);

    if(bind(m_socket, (struct sockaddr*)&servaddr, sizeof(servaddr)) == -1)
    {
        printf("bind socket error: %s(errno: %d)\n", strerror(errno), errno);
        return -1;
    }
    if(listen(m_socket, 10) == -1)
    {
        printf("listen socket error: %s(errno: %d)\n", strerror(errno), errno);
        return -1;
    }

    //-Wreturn-type
    return 0;
}

int CHttpSocket::Accept()
{
    return accept(m_socket, (struct sockaddr*)NULL, NULL);
}

bool CHttpSocket::Connect(const char* szHostName, int nPort)
{
    if(szHostName == NULL)
    {
        return false;
    }

    m_port = nPort;

    m_phostent = gethostbyname(szHostName);
    if(m_phostent == NULL)
    {
        printf("connect can't found host\n");
        
        return false;
    }

    struct in_addr ip_addr;
    memcpy(&ip_addr, m_phostent->h_addr_list[0], 4);
    
    struct sockaddr_in destaddr;
    destaddr.sin_family = AF_INET;
    destaddr.sin_port = htons(m_port);
    destaddr.sin_addr = ip_addr;

#if 0

    if(connect(m_socket, (sockaddr*)&destaddr, sizeof(sockaddr)) != 0)
    {
        return false;
    }

#else

    int error = -1;
    int len = sizeof(int);
    timeval tm;
    fd_set set;
    unsigned long ul = 1;

    ioctl(m_socket, FIONBIO, &ul);
    bool ret = false;

    if(connect(m_socket, (struct sockaddr*)&destaddr, sizeof(sockaddr)) == -1)
    {
        tm.tv_sec = TIME_OUT_TIME;
        tm.tv_usec = 0;
        
        FD_ZERO(&set);
        FD_SET(m_socket, &set);
        
        if(select(m_socket+1, NULL, &set, NULL, &tm) > 0)
        {
            if(getsockopt(m_socket, SOL_SOCKET, SO_ERROR, &error, (socklen_t*)&len) == -1)
            {
                RED_PRINTF("connect getsockopt SO_ERROR fail %s", strerror(errno));
            }
            else if(error == 0)
            {
                CGREEN_PRINTF("connect successful in %d ms", (tm.tv_sec - TIME_OUT_TIME)*1000 + tm.tv_usec / 1000);
                ret = true;   
            }
            else
            {
                errno = error;
                RED_PRINTF("connect fail %s", strerror(errno));
                ret = false;   
            }
        }
        else
        {
            RED_PRINTF("connect timeout");
            ret = false;
        }
    }
    else
    {
        CGREEN_PRINTF("connect successful directly");
        ret = true;
    }
        
    ul = 0;
    ioctl(m_socket, FIONBIO, &ul);
    if(!ret)
    {
        RED_PRINTF("Cannot Connect the server");
        
        return false;
    }
    
#endif
    
    return true;
}

const char* CHttpSocket::FormatRequestHeader(const char* pServer,const char* url, long& Length,
                                                     char *pCookie,char *pReferer)
{
    memset(m_requestheader, 0, MAX_HEADER_SIZE);
    strcat(m_requestheader, "GET ");
    strcat(m_requestheader, url);
    strcat(m_requestheader, " HTTP/1.1");
    strcat(m_requestheader, "\r\n");
    strcat(m_requestheader, "Host:");
    strcat(m_requestheader, pServer);
    strcat(m_requestheader, "\r\n");
    if(pReferer != NULL)
    {
        strcat(m_requestheader, "Referer:");
        strcat(m_requestheader, pReferer);
        strcat(m_requestheader, "\r\n");
    }
    strcat(m_requestheader, "Accept:*/*");
    strcat(m_requestheader, "\r\n");
    strcat(m_requestheader, "User-Agent:Dalvik/1.6.0 (Linux; U; Android 4.1.2; SH-02E Build/A2200)");
    strcat(m_requestheader, "\r\n");
    strcat(m_requestheader, "Connection:Keep-Alive");
    strcat(m_requestheader, "\r\n");
    if(pCookie != NULL)
    {
        strcat(m_requestheader, "Set Cookie:0");
        strcat(m_requestheader, pCookie);
        strcat(m_requestheader, "\r\n");
    }
    strcat(m_requestheader, "\r\n");
    Length = strlen(m_requestheader);
    logToFile("FormatRequestHeader SendRequest m_requestheader %s,Length %d", m_requestheader, Length);
    
    return m_requestheader;
}

const char* CHttpSocket::FormatPostHeader(const char* url, const char* host, long contentLen, long& Length)
{
    memset(m_requestheader, 0, MAX_HEADER_SIZE);
    strcat(m_requestheader, "POST ");
    strcat(m_requestheader, url);
    strcat(m_requestheader, " HTTP/1.1");
    strcat(m_requestheader, "\r\n");
    strcat(m_requestheader, "Host:");
    strcat(m_requestheader, host);
    strcat(m_requestheader, "\r\n");
    strcat(m_requestheader, "Content-Type:image/jpg");
    strcat(m_requestheader, "\r\n");
    strcat(m_requestheader, "Content-Length:");
    //-Wformat=
    sprintf(m_requestheader + strlen(m_requestheader), "%ld", contentLen);
    strcat(m_requestheader, "\r\n");
    strcat(m_requestheader, "Connection:Keep-Alive");
    strcat(m_requestheader, "\r\n");
    strcat(m_requestheader, "\r\n");
    Length = strlen(m_requestheader);
    logToFile("FormatRequestHeader SendRequest m_requestheader %s,Length %d", m_requestheader, Length);
    
    return m_requestheader;
}


bool CHttpSocket::SendRequest(const char* pRequestHeader, long Length)
{
    if(pRequestHeader == NULL)
    {
        pRequestHeader = m_requestheader;
    }

    if(Length == 0)
    {
        Length = strlen(m_requestheader);
    }
//  logToFile("SendRequest pRequestHeader %s,Length %d", pRequestHeader, Length);

    if(send(m_socket, pRequestHeader, Length, 0) == -1)
    {
        return false;
    }

    return true;
}

long CHttpSocket::Send(const char* pRequestHeader, long Length)
{
    long count = 0;

    if(pRequestHeader == NULL || Length == 0)
    {
        return -2;
    }

    count = send(m_socket, pRequestHeader, Length, 0);

    return count;
}

long CHttpSocket::Receive(char* pBuffer, long nMaxLength)
{
    return recv(m_socket, pBuffer, nMaxLength, 0);
}


long CHttpSocket::RecvDownloadData(char* pBuffer, long nMaxLength)
{
    int recvLen = 0;
    recvLen = recv(m_socket, pBuffer, nMaxLength, 0);
    mRecvSize += recvLen;

    if(recvLen <= 0)
    {
        return -1;
    }

    if(isChunked())
    {
        if(mChunkOverFlag)
        {
            long chunkSize = strtol(pBuffer, NULL, 16);
            if(chunkSize == 0)
            {
                logToFile("RecvDownloadData chunk over");
                mRecvSize    -= recvLen;    //Current recv data is an end flag,not save them.
                recvLen      = -1;
                mContentLen  = mRecvSize;
            }
            else
            {
                mChunkSize   += chunkSize;
                char* pChunk = strstr(pBuffer, "\r\n");
                if(pChunk)
                {
                    pChunk      += strlen("\r\n");
                    int bodyLen = recvLen - (pChunk - pBuffer);
                    char* pBody = (char*)malloc(bodyLen);
                    memcpy(pBody, pChunk, bodyLen);
                    memcpy(pBuffer, pBody, bodyLen);
                    recvLen = bodyLen;
                    free(pBody);
                    mRecvSize -= (pChunk - pBuffer);    //ignore chunk header
                }
            }
            mChunkOverFlag = false;

        }
        //current chunk is over.
        if(recvLen > 0 && mRecvSize > mChunkSize)
        {
            if((pBuffer[recvLen - 5] == '0') && (pBuffer[recvLen - 4] == '\r') && (pBuffer[recvLen - 3] == '\n'))
            {
                recvLen     -= 7;  //ignore chunk End flag "\r\n0\r\n\r\n"
                mRecvSize   -= 7;
                mContentLen = mRecvSize;
                logToFile("#####Receive  chunk End and ignore the last five character");
            }
            else
            {
                int ignoreLen = 2;
                if(mRecvSize - mChunkSize == 2)
                {
                    mChunkOverFlag = true;
                }
                else if(mRecvSize - mChunkSize > 2)
                {
                    //separate recv data to three part: PartA.ignorePart.PartB, and PartA will be reserved
                    int recvPartALen = recvLen - (mRecvSize - mChunkSize);  //the len of before chunk over flag "\r\n".
                    char* ckSize = strstr(pBuffer + recvPartALen + 2, "\r\n");

                    //fetch chunk size
                    if(ckSize)
                    {
                        int recvPartBLen = 0;
                        int chunkSize = strtol(pBuffer + recvPartALen + 2, NULL, 16);
                        ignoreLen = (ckSize + 2 - (pBuffer + recvPartALen));
                        recvPartBLen = mRecvSize - mChunkSize - ignoreLen;

                        char* tmpBuf = (char*)malloc(recvPartBLen);
                        memcpy(tmpBuf, pBuffer + recvPartALen + ignoreLen, recvPartBLen);
                        memcpy(pBuffer + recvPartALen, tmpBuf, recvPartBLen);
                        mChunkSize += chunkSize;
                        free(tmpBuf);
                    }
                }
                recvLen   -= ignoreLen;  //ignore chunk OVER flag "\r\n"
                mRecvSize -= ignoreLen;

                logToFile("#####Receive one chunk over and ignore %d character", ignoreLen);
            }
        }
    }
    
    return recvLen;
}

bool CHttpSocket::CloseSocket()
{
    if(m_socket != 0)
    {
        if(close(m_socket) == -1)
        {
            return false;
        }
    }
    m_socket = 0;
    
    return true;
}

int CHttpSocket::GetRequestHeader(char* pHeader, int nMaxLength) const
{
    int nLength;
    if((int)(strlen(m_requestheader)) > nMaxLength)
    {
        nLength = nMaxLength;
    }
    else
    {
        nLength = strlen(m_requestheader);
    }
    memcpy(pHeader, m_requestheader, nLength);
    
    return nLength;
}

bool CHttpSocket::SetTimeout(int nTime, int nType)
{
    if(nType == 0)
    {
        nType = SO_RCVTIMEO;
    }
    else
    {
        nType = SO_SNDTIMEO;
    }
    int dwErr;

    struct timeval timeout = {nTime, 0};
    
    dwErr = setsockopt(m_socket, SOL_SOCKET, nType, &timeout, sizeof(timeout));
    if(dwErr)
    {
        RED_PRINTF("setsockopt %s set failed", (nType == SO_RCVTIMEO)?"SO_RCVTIMEO":"SO_SNDTIMEO");
        
        return false;
    }
    
    return true;
}

bool CHttpSocket::ParseResponseHeader(int sock)
{
    char   buffer[MAX_HEADER_SIZE]  = {0};
    char*  pHeaderEnd               = NULL;
    int    headerLen                = 0;

    //clear header
    m_nResponseHeaderSize           = 0;
    m_nResponseBodySize             = 0;

    if(sock <= 0)
    {
        sock = m_socket;
    }

    while(1)
    {
        int nBytes;
        nBytes = recv(sock, buffer, MAX_HEADER_SIZE, 0);

        if(nBytes <= 0)
        {
            logToFile("ParseResponseHeader failed");
            return false;
        }

        pHeaderEnd = strstr(buffer, "\r\n\r\n") ;
        if(pHeaderEnd)
        {
            pHeaderEnd += strlen("\r\n\r\n");
            headerLen  = pHeaderEnd - buffer;
            memcpy(m_ResponseHeader + m_nResponseHeaderSize, buffer, headerLen);
            m_nResponseHeaderSize += headerLen;
            m_nResponseBodySize   = nBytes - headerLen;
            memcpy(m_ResponseBody, pHeaderEnd, m_nResponseBodySize);
            break;
        }
        else
        {
            headerLen = nBytes;
            memcpy(m_ResponseHeader + m_nResponseHeaderSize, buffer, headerLen);
            m_nResponseHeaderSize += headerLen;
        }
    }

    for(int i = 0; i < m_nResponseHeaderSize; i++)
    {
        m_ResponseHeader[i] = tolower(m_ResponseHeader[i]);
    }
    logToFile("ParseResponseHeader  %s", m_ResponseHeader);

    char* encode = strstr(m_ResponseHeader, "transfer-encoding:");
    if(encode)
    {
        if(strstr(encode, "chunked"))
        {
            mIsChunked = true;
        }
    }

    return true;
}

int CHttpSocket::GetResponseBody(char* body)
{
    int   size         = 0;
    char* chunkSize    = NULL;
    if(isChunked() && (chunkSize = strstr(m_ResponseBody, "\r\n")))
    {
        char* pBody = chunkSize + strlen("\r\n");
        char  strSize[10]  = {0};
        memcpy(strSize, m_ResponseBody, chunkSize - m_ResponseBody);
        memcpy(body, pBody, m_nResponseBodySize - (pBody - m_ResponseBody));
        mChunkSize = strtol(strSize, NULL, 16);
        size       = m_nResponseBodySize - (pBody - m_ResponseBody);
        mRecvSize  += size;
    }
    else
    {
        memcpy(body, m_ResponseBody, m_nResponseBodySize);
        size = m_nResponseBodySize;
    }

    return size;
}

int CHttpSocket::GetResponseLine(char* pLine, int nMaxLength)
{
    if(m_nCurIndex >= m_nResponseHeaderSize)
    {
        m_nCurIndex = 0;
        
        return -1;
    }
    
    int nIndex = 0;
    char c = 0;
    do
    {
        c = m_ResponseHeader[m_nCurIndex++];
        pLine[nIndex++] = c;
    } while(c != '\n' && m_nCurIndex < m_nResponseHeaderSize && nIndex < nMaxLength);
    
    return nIndex;
}

int CHttpSocket::GetField(const char* szSession, char* szValue)
{
    std::string strRespons;
    strRespons = m_ResponseHeader;
    int nPos;
    nPos = strRespons.find(szSession, 0);
    if(nPos != -1)
    {
        nPos += strlen(szSession);
        nPos += 2;
        int nCr = strRespons.find("\r\n", nPos);
        std::string strValue = strRespons.substr(nPos, nCr - nPos);
        strcpy(szValue, strValue.c_str());
        
        return (nCr - nPos);
    }
    else
    {
        return -1;
    }
}

int CHttpSocket::GetResponseCode()
{
    char szState[3] = {0};

    if(m_nResponseHeaderSize > 12)
    {
        szState[0] = m_ResponseHeader[9];
        szState[1] = m_ResponseHeader[10];
        szState[2] = m_ResponseHeader[11];
    }

    return atoi(szState);
}

long CHttpSocket::getContentLength()
{
    char* contentLen = strstr(m_ResponseHeader, "content-length:");
    if(contentLen)
    {
        char size[20] = {0};
        contentLen += strlen("Content-Length:");
        char* stop = strstr(contentLen, "\r\n");
        memcpy(size, contentLen, stop - contentLen);
        mContentLen = atoi(size);
    }
    logToFile("getContentLength Length %ld", mContentLen);
    
    return mContentLen;
}

bool CHttpSocket::isChunked()
{
    return mIsChunked;
}

