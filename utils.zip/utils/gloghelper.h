#ifndef GLOGHELPER_H
#define GLOGHELPER_H

struct GLogHelper
{
    GLogHelper();
    ~GLogHelper();
};

#endif // GLOGHELPER_H