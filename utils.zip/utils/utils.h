#ifndef __UTILS_H__
#define __UTILS_H__

#include <android/log.h>
#include <sys/time.h>

#include "ammem.h"
#include "asvloffscreen.h"

#define log(...) printf(__VA_ARGS__);printf("\n")//__android_log_print(ANDROID_LOG_ERROR, "maleitest", __VA_ARGS__)

struct MLTIME {
        MLTIME(const char* l = 0):label(l)
        {
            gettimeofday(&t_start, 0);
        }

        ~MLTIME()
        {
            gettimeofday(&t_end, 0);
            long time_diff = (t_end.tv_sec - t_start.tv_sec)*1000 + (t_end.tv_usec - t_start.tv_usec)/1000;
            log("%s cost time is %ld ms", label, time_diff);
        }
private:
        MLTIME operator =(const MLTIME&);

private:
    struct timeval t_start;
    struct timeval t_end;
    const char* label;
};


void dumpOffscreen2File(ASVLOFFSCREEN* pAsvl, const char* name);

#endif /* __UTILS_H__ */
