#include "timeout_mgr.h"

#include <exception>

#include <sys/prctl.h>

#include "def.h"

// this lock is for add and remove
// but the most need is remove and handle timeout
// because when object is freed, it MUST be lock before resource dont need

// this will slow performance, need redesign structure

#undef ALK_TIMEOUT_MGR
#define ALK_TIMEOUT_MGR std::lock_guard<std::mutex> lck (mutex_);

SINGLETON_DEFINITION(TimeoutMgr)

TimeoutMgr::TimeoutMgr()
{
    // this may happens an exception by lvji's core file
    try
    {
        t_ = std::move(std::thread(&TimeoutMgr::check_timeoutWrap, this));
    }
    catch(std::exception& e)
    {
        DLOG(ERROR) << "TimeoutMgr::TimeoutMgr exception: " << e.what();
    }
}

TimeoutMgr::~TimeoutMgr()
{
    io_context.stop();
    t_.join();
    
    activeList_.erase(activeList_.begin(), activeList_.end());
    checkList_.erase(checkList_.begin(), checkList_.end());
    timeoutList_.erase(timeoutList_.begin(), timeoutList_.end());
    timerList_.erase(timerList_.begin(), timerList_.end());
}

void TimeoutMgr::check_timeoutWrap(TimeoutMgr* tmgr)
{
    tmgr->check_timeout();
}

void TimeoutMgr::check_timeout(void)
{
    prctl(PR_SET_NAME, "monitor thread");
    
    try
    {
        time_t_timer timer(io_context);
        timer.expires_from_now(checkFrequency_);
        timer.async_wait(bind(&TimeoutMgr::handle_timeout, this, std::placeholders::_1, std::ref(timer)));
        io_context.run();
    }
    catch(std::exception& e)
    {
        DLOG(ERROR) << "check_timeout exception: " << e.what();
    }
}

void TimeoutMgr::handle_timeout(const arcio::error_code&, time_t_timer& timer)
{
ALK_TIMEOUT_MGR

    // for timeout
    for(auto it = activeList_.begin(); it != activeList_.end(); it++)
    {
        if(std::difftime(time(NULL), it->second) > checkList_[it->first])
        {
            timeoutList_[it->first] = time(NULL);
        }
    }
    
    for(auto it = timeoutList_.begin(); it != timeoutList_.end(); it++)
    {
        auto itt = activeList_.find(it->first);
        if(itt != activeList_.end())
            activeList_.erase(itt);
    }

    // for timer
    //for(auto it = timerList_.begin(); it != timerList_.end(); it++)
    //{
        //it->second.first(it->first);
        
        //if(it->second.second == false)
        //{
           //timerList_.erase(it);
        //}
    //}

    // better by sonar
    auto it = timerList_.begin();
    while(it != timerList_.end())
    {
        // do real check work here
        //RED_PRINTF("handle_timeout object:%p", it->first);
        
        it->second.first(it->first);

        //RED_PRINTF("handle_timeout after object:%p", it->first);
        
        if(it->second.second == false)
        {
            timerList_.erase(it++);
        }
        else
        {
            ++it;
        }
    }
    
    timer.expires_from_now(checkFrequency_);
    timer.async_wait(bind(&TimeoutMgr::handle_timeout, this, std::placeholders::_1, std::ref(timer)));
}

__attribute__((unused))
void TimeoutMgr::updateActiveTime(void* object, time_t timepoint)
{
//AL
//atomic_int / atomic_long or just let it be
    activeList_[object] = timepoint;
}

void TimeoutMgr::removeTimeoutCheck(void* object)
{
    RED_PRINTF("removeTimeoutCheck object:%p", object);

ALK_TIMEOUT_MGR

    {    
        auto it = activeList_.find(object);
        if(it != activeList_.end())
            activeList_.erase(it);
    }

    {
        auto it = checkList_.find(object);
        if(it != checkList_.end())
            checkList_.erase(it);
    }
    
    {
        auto it = timeoutList_.find(object);
        if(it != timeoutList_.end())
            timeoutList_.erase(it);
    }

    {
        auto it = timerList_.find(object);
        if(it != timerList_.end())
        {
            RED_PRINTF("removeTimeoutCheck object:%p has been erased from timer", object);
            
            timerList_.erase(it);
        }
    }
}    

__attribute__((unused))
void TimeoutMgr::addTimeoutCheck(void* object, time_t timeoutSpan)
{
//ALK_TIMEOUT_MGR

    checkList_[object] = timeoutSpan;
}

__attribute__((unused))
bool TimeoutMgr::getTimeoutResult(void* object)
{
//ALK_TIMEOUT_MGR

    auto it = timeoutList_.find(object);
    if(it != timeoutList_.end())
    {
        return true;
    }
    else
    {
        return false;
    }
}

void TimeoutMgr::addTimer(void* object, handler_t handler, bool iter)
{
ALK_TIMEOUT_MGR

    //YELLOW_PRINTF("add timer obj: %p, iter: %d", object, iter);
    timerList_[object] = std::make_pair(handler, iter);
}