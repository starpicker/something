/*----------------------------------------------------------------------------------------------
*
* This file is ArcSoft's property. It contains ArcSoft's trade secret, proprietary and
* confidential information.
*
* The information and code contained in this file is only for authorized ArcSoft employees
* to design, create, modify, or review.
*
* DO NOT DISTRIBUTE, DO NOT DUPLICATE OR TRANSMIT IN ANY FORM WITHOUT PROPER AUTHORIZATION.
*
* If you are not an intended recipient of this file, you must not copy, distribute, modify,
* or take any action in reliance on it.
*
* If you have received this file in error, please immediately notify ArcSoft and
* permanently delete the original and any copy of any file and any printout thereof.
*
*---------------------------------------------------------------------------------------------*/

// let it be
// no time to refine

#ifndef _DOWNLOAD_MANAGER
#define _DOWNLOAD_MANAGER

#include <map>
#include <mutex>
#include <string>
#include <memory>

#include "macro.h"
#include "dmrEngine.h"

using std::map;
using std::mutex;
using std::string;
using std::shared_ptr;

class DownloadNotify
{
public:
    virtual ~DownloadNotify() = default;
    virtual void onDownloadResult(bool result, const string& path, DMR_ScreenIndex index, const string& uuid, const string& url, bool show) = 0;
};


class DownloadManager
{
public:
    void                         removeTask(DMR_ScreenIndex index);
    int                          addTask(const string& url, DMR_ScreenIndex index, const string& path, const string& uuid, bool show);
    void                         setNotify(DownloadNotify* notify);

private:

    DownloadNotify*              notify_;

    const static int             timeout_ = 15*1000; // 15 seconds
    
    void                         download();
private:
struct TaskNode{
    DMR_ScreenIndex    index_;
    int                port_;
    string             url_;
    string             uuid_;
    string             path_;
    string             ip_;
    bool               cancel_;
    bool               show_;
};
    
typedef shared_ptr<TaskNode> TaskNodePtr;
typedef map<int, TaskNodePtr> taskM;
typedef map<string, TaskNodePtr> taskNoShowM;

    taskM              map_;
    taskNoShowM        mapNoShow_;
    mutex              mutex_;

SINGLETON(DownloadManager)
DELETE_NOUSE_TRIVIAL_FUNC(DownloadManager)
};

#endif
