#include "version.h"

#include <stdio.h>
#include <unistd.h>

#include "def.h"

void print_version(void)
{
#if(defined DMR_VERSION) || (defined SVN_VERSION)

    printf("\n\n\nDMR Engine Version : %s\n\n\n", DMR_VERSION);

    if(access(DMR_LOG_PATH, F_OK) == 0)
        printf("\n\n\n\033[1;32;40mDMR Engine Version : %s, SVN Version : %s\033[0m\n\n\n", DMR_VERSION, SVN_VERSION);

#else

    printf("\n\n\n\033[1;32;40mTEST VERSION, NOT FOR DELIVERY, BUILD TIME: %s\033[0m\n\n\n", BUILD_TIME);
    sleep(2);

#endif
}
