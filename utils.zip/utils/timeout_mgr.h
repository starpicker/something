#ifndef TIMEOUT_MGR_H
#define TIMEOUT_MGR_H

#include <map>
#include <thread>
#include <mutex>

#include <time.h>

#include "time_t_timer.h"
#include "macro.h"

class TimeoutMgr
{
public:
    void setCheckFrequency(time_t frequency){checkFrequency_ = frequency;}
    void removeTimeoutCheck(void* object);
    // for timeout
    __attribute__((unused))
    void updateActiveTime(void* object, time_t timepoint);
    void addTimeoutCheck(void* object, time_t timeoutSpan);
    __attribute__((unused))
    bool getTimeoutResult(void* object);

    // for timer
    using handler_t = void* (*)(void*);
    void addTimer(void* object, handler_t handler, bool iter);
    
    // for timeout
private:
    std::mutex mutex_;
    
    // object, lastActiveTimePoint
    std::map<void*, time_t> activeList_;
    // object, timeoutTimeSpan
    std::map<void*, time_t> checkList_;
    // object, timeoutTimePoint
    std::map<void*, time_t> timeoutList_;
    
    // for timer
private:
    std::map<void*, std::pair<handler_t, bool>> timerList_;
    
private:
    arcio::io_context io_context;
    time_t checkFrequency_ = 2;
    std::thread t_;
    
private:
static void check_timeoutWrap(TimeoutMgr* tmgr);
    void check_timeout(void);
    
public:
    void handle_timeout(const arcio::error_code&, time_t_timer& timer);

private:
    TimeoutMgr(TimeoutMgr&&) = delete;
    TimeoutMgr& operator =(TimeoutMgr&&) = delete;
    TimeoutMgr(const TimeoutMgr&) = delete;
    TimeoutMgr& operator =(const TimeoutMgr&) = delete;
    
SINGLETON(TimeoutMgr)
};

#endif // TIMEOUT_MGR_H
