/*----------------------------------------------------------------------------------------------
*
* This file is ArcSoft's property. It contains ArcSoft's trade secret, proprietary and
* confidential information.
*
* The information and code contained in this file is only for authorized ArcSoft employees
* to design, create, modify, or review.
*
* DO NOT DISTRIBUTE, DO NOT DUPLICATE OR TRANSMIT IN ANY FORM WITHOUT PROPER AUTHORIZATION.
*
* If you are not an intended recipient of this file, you must not copy, distribute, modify,
* or take any action in reliance on it.
*
* If you have received this file in error, please immediately notify ArcSoft and
* permanently delete the original and any copy of any file and any printout thereof.
*
*---------------------------------------------------------------------------------------------*/
#include "downloadManager.h"

#include <sys/time.h>

#include "def.h"
#include "httpSocket.h"
#include "dmrEngine.h"
#include "hitachi_context.h"
#include "player.h"

SINGLETON_DEFINITION(DownloadManager)

#undef AL
#define AL std::lock_guard<std::mutex> lck (mutex_);

DownloadManager::DownloadManager()
{
}

DownloadManager::~DownloadManager()
{
AL
    for(auto it = map_.begin(); it != map_.end();)
    {
        it->second->cancel_ = true;
        it = map_.erase(it);
    }

    for(auto it = mapNoShow_.begin(); it != mapNoShow_.end();)
    {
        it->second->cancel_ = true;
        it = mapNoShow_.erase(it);
    }
}

void DownloadManager::removeTask(DMR_ScreenIndex index)
{
AL    
    for(auto it = map_.begin(); it != map_.end();)
    {
        if(it->second->index_ == index)
        {
            it->second->cancel_ = true;
            it = map_.erase(it);
        }
        else
        {
            ++it;
        }
    }

    for(auto it = mapNoShow_.begin(); it != mapNoShow_.end();)
    {
        if(it->second->index_ == index)
        {
            it->second->cancel_ = true;
            it = mapNoShow_.erase(it);
        }
        else
        {
            ++it;
        }
    }
}

int DownloadManager::addTask(const string& url, DMR_ScreenIndex index, const string& path, const string& uuid, bool show)
{
    auto t = TaskNodePtr(new TaskNode());

    t->index_  = index;
    t->url_    = url;
    t->uuid_   = uuid;
    t->path_   = path;
    t->cancel_ = false;
    t->show_   = show;

    int ret = ERR_OK;

    
    char* domain = strstr(const_cast<char*>(url.c_str()), "://");
    if(domain)
    {
        domain += strlen("://");
        char* fileAddress = strstr(domain, "/");
        if(fileAddress)
        {
            char* tmp = strchr(domain, ':');
            if(tmp && tmp < fileAddress)
            {
                t->ip_ = string(domain, tmp - domain);
                tmp++;
                char port[10] = {0};
                memcpy(port, tmp, fileAddress - tmp);
                t->port_ = atoi(port);
            }
            else
            {
                t->ip_ = string(domain, fileAddress- domain);
                t->port_ = 80;
            }
        }
        else
        {
            ret = ERR_FAILED;
        }
    }
    else
    {
        ret = ERR_FAILED;
    }

    //YELLOW_PRINTF("DownloadManager::addTask submit");

    HitachiContext* context = SINGLETON_INSTANCE(HitachiContext);
    thread_pool_ptr tpp = context->get_thread_pool();

    {
AL    
        if(show)
        {
            auto it = map_.find(t->index_);
            if(it != map_.end())
            {
                it->second->cancel_ = true;
            }
            
            map_[t->index_] = t;

            JUMP(thread_pool::submit)
            
            tpp->submit(std::bind(&DownloadManager::download, this));
        }
        else
        {
            mapNoShow_[t->url_] = t;

            JUMP(thread_pool::submit)
            
            tpp->submit(std::bind(&DownloadManager::download, this), false);
        }
    }
    
    return ret;
}

#define MAX_RECV_SIZE 1024*512
void DownloadManager::download()
{
    int          count = 0;
    long         totalCount = 0;

    FILE*        pFile = NULL;
    int          code = 0;
    long         reqLen = 0;
    char         host[100] = {0};
    long         fileSize = 0;
    MChar        mBuffer[MAX_RECV_SIZE + 1] = {0};

    struct timeval st;
    struct timeval et;
    
    TaskNodePtr  node;
    
    {
AL        
        if(map_.size())
        {
            node = map_.begin()->second;
            map_.erase(map_.begin());
        }
        else if(mapNoShow_.size())
        {
            node = mapNoShow_.begin()->second;
            mapNoShow_.erase(mapNoShow_.begin());
        }
        else
        {
            return;
        }
    }
    
    gettimeofday(&st, NULL);
                
    CHttpSocket sock;
    if(!sock.Socket())
    {
        logToFile("DownloadTask start Socket failed");
        goto done ;
    }
    sock.SetTimeout(timeout_);
    if(!sock.Connect(node->ip_.c_str(), node->port_))
    {
        logToFile("DownloadTask Connect failed");
        
        RED_PRINTF("DownloadTask Connect failed");
        
        goto done ;
    }
    if(node->cancel_)
    {
        sock.CloseSocket();
        goto done ;
    }
    sprintf(host, "%s:%d", node->ip_.c_str(), node->port_);
    logToFile("DownloadTask Connect host %s", host);
    
    sock.FormatRequestHeader(host, node->url_.c_str(), reqLen);
    sock.SendRequest();
    if(node->cancel_)
    {
        sock.CloseSocket();
        goto done ;
    }
    logToFile("send request");

    if(!sock.ParseResponseHeader())
    {
        goto done ;
    }

    code = sock.GetResponseCode();
    fileSize = sock.getContentLength();
    logToFile("threadProc code %d",code);
    
    if(code == 200)
    {
        if(node->cancel_)
        {
            goto done ;
        }

        count = sock.GetResponseBody(mBuffer);
        if(strlen(node->path_.c_str()) == 0)
        {
            node->path_ = "/tmp/dmr/TEMP_FILE";
        }
        if(node->cancel_)
        {
            goto done ;
        }
        pFile = fopen(node->path_.c_str(), "w");
        if(!pFile)
        {
            goto done ;
        }
        count = fwrite(mBuffer, 1, count, pFile);
        totalCount += count;
        if(node->cancel_)
        {
            goto done ;
        }
    }
    else
    {
        goto done ;
    }
    logToFile("threadProc Receive body %ld, size %ld", totalCount, fileSize);
    
    while(!node->cancel_)
    {
        if(totalCount == fileSize)
        {
            logToFile("threadProc download suc");
            break;
        }

        count = sock.RecvDownloadData(mBuffer, MAX_RECV_SIZE);
        if(node->cancel_)
        {
            break;
        }
        //if chunked download,may only receive data whose body num is 0. So pass it.
        if(count == 0)
        {
            continue;
        }

        if(count < 0)
        {
            logToFile("threadProc Receive failed,ret %d", count);
            break;
        }
        count = fwrite(mBuffer, 1, count, pFile);
        totalCount += count;

    }
done:

    sock.CloseSocket();

    if(pFile)
    {
        fclose(pFile);
    }

    if(totalCount > 0 && totalCount == fileSize && !node->cancel_)
    {
        gettimeofday(&et, NULL);
        float tt = (et.tv_sec - st.tv_sec)*1000.0f + (et.tv_usec - st.tv_usec)/1000.0f;

        YELLOW_PRINTF("!!!!!!!!!!!!!!!!download finished cost time: %f ms, current time is: %s", tt, getCurrentSystemTime().c_str());

        if(notify_ && node->cancel_ == false)
        {
            JUMP(Render::onDownloadResult)

            notify_->onDownloadResult(true, node->path_, node->index_, node->uuid_, node->url_, node->show_);
        }
    }
    else
    {
        if(notify_ && node->cancel_ == false)
        {
            notify_->onDownloadResult(false, node->path_, node->index_, node->uuid_, node->url_, node->show_);
        }

        if(access(node->path_.c_str(), F_OK) == 0)
        {
            unlink(node->path_.c_str());
        }
    }
}

void DownloadManager::setNotify(DownloadNotify* notify)
{
    notify_ = notify;
}

