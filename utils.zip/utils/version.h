#ifndef HITACHI_DMR_SDK_VERSION_H__
#define HITACHI_DMR_SDK_VERSION_H__

void print_version(void);

#endif // HITACHI_DMR_SDK_VERSION_H__