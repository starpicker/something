#include "gloghelper.h"

#include <glog/logging.h>
#include <stdlib.h>
#include <sys/stat.h>
#include <stdio.h>
#include <dirent.h>

#include "def.h"

#ifndef NDEBUG

int is_dir(char* filename)
{
    struct stat buf;
    int ret = stat(filename,&buf);
    if(0 == ret)
    {
            if(buf.st_mode & S_IFDIR)
            {
                    //printf("%s is folder\n",filename);
                    return 0;
            }
            else
            {
                    //printf("%s is file\n",filename);
                    return 1;
            }
    }

    return -1;
}

int delete_dir(const char* dirname)
{
    char chBuf[256];
    DIR* dir = NULL;
    struct dirent* ptr;
    int ret = 0;
    dir = opendir(dirname);
    if(NULL == dir)
    {
        return -1;
    }
    while((ptr = readdir(dir)) != NULL)
    {
        ret = strcmp(ptr->d_name, ".");
        if(0 == ret)
        {
            continue;
        }

        ret = strcmp(ptr->d_name, "..");
        if(0 == ret)
        {
            continue;
        }

        snprintf(chBuf, 256, "%s/%s", dirname, ptr->d_name);

        ret = is_dir(chBuf);
        if(0 == ret)
        {
            //printf("%s is dir\n", chBuf);
            ret = delete_dir(chBuf);
            if(0 != ret)
            {
                return -1;
            }
        }
        else if(1 == ret)
        {
            //printf("%s is file\n", chBuf);
            ret = remove(chBuf);
            if(0 != ret)
            {
                return -1;
            }
        }
    }

    (void)closedir(dir);

    ret = remove(dirname);
    if(0 != ret)
    {
        return -1;
    }

    return 0;
}
void SignalHandle(const char* data, int size)
{
    std::string str = std::string(data,size);
    GLOG(FATAL) << str;
}

#endif // NDEBUG

GLogHelper::GLogHelper()
{

#ifndef NDEBUG

    #define LOG_PATH "HITACHI_LOG"

    delete_dir(LOG_PATH);
    mkdir(LOG_PATH, S_IRWXU);

    remove("memory.txt");

    // If specified, logfiles are written into this directory instead of the
    // default logging directory.
    FLAGS_log_dir = LOG_PATH;

    google::InitGoogleLogging("dmrsink");

    // Set whether log messages go to stderr instead of logfiles
    FLAGS_logtostderr = false;//void LogToStderr()

    // Set whether log messages go to stderr in addition to logfiles.
    FLAGS_alsologtostderr = false;

    // Set color messages logged to stderr (if supported by terminal).
    FLAGS_colorlogtostderr = true;

    // Log messages at a level >= this flag are automatically sent to
    // stderr in addition to log files.
    FLAGS_stderrthreshold = google::ERROR; //google::FATAL;//void SetStderrLogging(LogSeverity min_severity

    // Set whether the log prefix should be prepended to each line of output.
    FLAGS_log_prefix = "";

    // Log messages at a level <= this flag are buffered.
    // Log messages at a higher level are flushed immediately.
    FLAGS_logbuflevel = google::INFO;

    // Sets the maximum number of seconds which logs may be buffered for.
    FLAGS_logbufsecs = 0;

    // Log suppression level: messages logged at a lower level than this
    // are suppressed.
    FLAGS_minloglevel = google::INFO;

    // Set the log file mode.
    FLAGS_logfile_mode = S_IRUSR | S_IWUSR | S_IRGRP | S_IWGRP |S_IROTH | S_IWOTH;

    // Sets the path of the directory into which to put additional links
    // to the log files.
    FLAGS_log_link = "";

    FLAGS_v = 3;  // in vlog_is_on.cc

    // Sets the maximum log file size (in MB).
    FLAGS_max_log_size = 100;

    // Sets whether to avoid logging to the disk if the disk is full.
    FLAGS_stop_logging_if_full_disk = false;

    google::SetLogDestination(google::INFO, APP_HOME "" LOG_PATH "/info_");
    google::SetLogDestination(google::WARNING, "" /*APP_HOME "" LOG_PATH "/warning_"*/);
    google::SetLogDestination(google::ERROR, APP_HOME "" LOG_PATH "/error_");
    google::SetLogDestination(google::FATAL, APP_HOME "" LOG_PATH "/fatal_");
    google::SetLogFilenameExtension("dmrsink_");

    google::InstallFailureSignalHandler();
    google::InstallFailureWriter(&SignalHandle);

#endif // NDEBUG

}

GLogHelper::~GLogHelper()
{
#ifndef NDEBUG

    google::ShutdownGoogleLogging();
#endif // NDEBUG  
}
