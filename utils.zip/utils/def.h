/*----------------------------------------------------------------------------------------------
*
* This file is ArcSoft's property. It contains ArcSoft's trade secret, proprietary and
* confidential information.
*
* The information and code contained in this file is only for authorized ArcSoft employees
* to design, create, modify, or review.
*
* DO NOT DISTRIBUTE, DO NOT DUPLICATE OR TRANSMIT IN ANY FORM WITHOUT PROPER AUTHORIZATION.
*
* If you are not an intended recipient of this file, you must not copy, distribute, modify,
* or take any action in reliance on it.
*
* If you have received this file in error, please immediately notify ArcSoft and
* permanently delete the original and any copy of any file and any printout thereof.
*
*---------------------------------------------------------------------------------------------*/

#ifndef _DEF_H
#define _DEF_H

#include "amcomdef.h"
#include <mutex>
#include <future>
#include "glog/logging.h"

#define WQINFO(...) /*printf( __VA_ARGS__)*/
#define WQERROR(...) /*printf( __VA_ARGS__)*/

const static int CLOSED_INDICATION_VALUE = 0x12345678;

// real product cwd is /
#define APP_HOME "/usr/Federer/main_app/"

//#define VIDEO_DUMP_PATH APP_HOME
#define VIDEO_DUMP_PATH "/tmp/dumpvideo/"
#define AUDIO_DUMP_PATH "/tmp/dumpaudio/"

#define JUMP(a)

#ifndef NDEBUG

void initLogger();
void logToFile(const char * fmt, ...);
void uninitLogger();

#else

inline void initLogger(){}
#define logToFile
inline void uninitLogger(){}

#endif

//void* memcpy_debug(const char* file, const char* func, int line, void* dest, const void* src, unsigned int n);


#define ERR_OK  0
#define ERR_FAILED  1
#define FAILED(x)   ( x !=  ERR_OK )
#define SUCCESS(x)  ( x ==  ERR_OK )
#define CheckPointer(p, ret) do{if(!p){return ret;}}while(0);

typedef MVoid* MPVoidProc(MVoid* lpPara);



struct EnterExit {
        EnterExit(const char* l = 0):label(l)
        {
            logToFile("%s enter", label);
            DLOG(INFO) << label << " enter";
        }

        ~EnterExit()
        {
            logToFile("%s exit", label);
            DLOG(INFO) << label << " exit";
        }

private:
    const char* label;
};

#define EE  EnterExit ee = __func__;

#ifndef NULL
#define NULL 0
#endif

//#define ML620 "malei test 620:"

#define DMR_LOG_PATH "/tmp/dmrlog"

#ifndef NDEBUG

#include <string>
#include <iostream>
#include <map>
#include <mutex>

#include <stdio.h>
#include <unistd.h>
#include <stdarg.h>
#include <pthread.h>

using std::string;
using std::map;
using std::getline;
using std::cin;
using std::mutex;
using std::lock_guard;


extern map<string, bool> g_log_tag_map;
extern mutex g_log_mutex;

#define LLG lock_guard<mutex> llg(g_log_mutex);

#define filename(x) strrchr(x,'/')?strrchr(x,'/')+1:x

#define FILENAME filename(__FILE__)

#define CYELLOW_PRINTF(...)         do {LLG\
                                        if(g_log_tag_map[FILENAME] && g_log_tag_map[FILENAME])\
                                           {\
                                                yellow_printf(__VA_ARGS__);\
                                           }\
                                        else if(g_log_tag_map[__func__] && g_log_tag_map[__func__])\
                                           {\
                                                yellow_printf(__VA_ARGS__);\
                                           }\
                                        else \
                                           ;\
                                        }while(0)

                                        
#define CRED_PRINTF(...)            do {LLG\
                                        if(g_log_tag_map[FILENAME] && g_log_tag_map[FILENAME])\
                                           {\
                                                red_printf(__VA_ARGS__);\
                                           }\
                                        else if(g_log_tag_map[__func__] && g_log_tag_map[__func__])\
                                           {\
                                                red_printf(__VA_ARGS__);\
                                           }\
                                        else \
                                           ;\
                                        }while(0)
                                      
#define CGREEN_PRINTF(...)          do {LLG\
                                        if(g_log_tag_map[FILENAME] && g_log_tag_map[FILENAME])\
                                           {\
                                                green_printf(__VA_ARGS__);\
                                           }\
                                        else if(g_log_tag_map[__func__] && g_log_tag_map[__func__])\
                                           {\
                                                green_printf(__VA_ARGS__);\
                                           }\
                                        else \
                                           ;\
                                      }while(0)
                                      
#define CPURPLE_PRINTF(...)         do {LLG\
                                        if(g_log_tag_map[FILENAME] && g_log_tag_map[FILENAME])\
                                           {\
                                                purple_printf(__VA_ARGS__);\
                                           }\
                                        else if(g_log_tag_map[__func__] && g_log_tag_map[__func__])\
                                           {\
                                                purple_printf(__VA_ARGS__);\
                                           }\
                                        else \
                                           ;\
                                      }while(0)

#define CBLUE_PRINTF(...)           do {LLG\
                                        if(g_log_tag_map[FILENAME] && g_log_tag_map[FILENAME])\
                                           {\
                                                blue_printf(__VA_ARGS__);\
                                           }\
                                        else if(g_log_tag_map[__func__] && g_log_tag_map[__func__])\
                                           {\
                                                blue_printf(__VA_ARGS__);\
                                           }\
                                        else \
                                           ;\
                                      }while(0)
                                      
#define CCYAN_PRINTF(...)           do {LLG\
                                        if(g_log_tag_map[FILENAME] && g_log_tag_map[FILENAME])\
                                           {\
                                                cyan_printf(__VA_ARGS__);\
                                           }\
                                        else if(g_log_tag_map[__func__] && g_log_tag_map[__func__])\
                                           {\
                                                cyan_printf(__VA_ARGS__);\
                                           }\
                                        else \
                                           ;\
                                      }while(0)
                                      

#define CYPRINTF(...)               do {LLG\
                                        if(g_log_tag_map[FILENAME] && g_log_tag_map[FILENAME])\
                                           {\
                                                yprintf(__VA_ARGS__);\
                                           }\
                                        else if(g_log_tag_map[__func__] && g_log_tag_map[__func__])\
                                           {\
                                                yprintf(__VA_ARGS__);\
                                           }\
                                        else \
                                           ;\
                                      }while(0)

                                                                                
#define CRPRINTF(...)               do {LLG\
                                        if(g_log_tag_map[FILENAME] && g_log_tag_map[FILENAME])\
                                           {\
                                                rprintf(__VA_ARGS__);\
                                           }\
                                        else if(g_log_tag_map[__func__] && g_log_tag_map[__func__])\
                                           {\
                                                rprintf(__VA_ARGS__);\
                                           }\
                                        else \
                                           ;\
                                        }while(0)
                                                                              
#define CGPRINTF(...)               do {LLG\
                                        if(g_log_tag_map[FILENAME] && g_log_tag_map[FILENAME])\
                                           {\
                                                gprintf(__VA_ARGS__);\
                                           }\
                                        else if(g_log_tag_map[__func__] && g_log_tag_map[__func__])\
                                           {\
                                                gprintf(__VA_ARGS__);\
                                           }\
                                        else \
                                           ;\
                                      }while(0)
                                                                              
#define CPPRINTF(...)               do {LLG\
                                        if(g_log_tag_map[FILENAME] && g_log_tag_map[FILENAME])\
                                           {\
                                                pprintf(__VA_ARGS__);\
                                           }\
                                        else if(g_log_tag_map[__func__] && g_log_tag_map[__func__])\
                                           {\
                                                pprintf(__VA_ARGS__);\
                                           }\
                                        else \
                                           ;\
                                      }while(0)
                                        
#define CBPRINTF(...)               do {LLG\
                                        if(g_log_tag_map[FILENAME] && g_log_tag_map[FILENAME])\
                                           {\
                                                bprintf(__VA_ARGS__);\
                                           }\
                                        else if(g_log_tag_map[__func__] && g_log_tag_map[__func__])\
                                           {\
                                                bprintf(__VA_ARGS__);\
                                           }\
                                        else \
                                           ;\
                                      }while(0)
                                                                              
#define CCPRINTF(...)               do {LLG\
                                        if(g_log_tag_map[FILENAME] && g_log_tag_map[FILENAME])\
                                           {\
                                                cprintf(__VA_ARGS__);\
                                           }\
                                        else if(g_log_tag_map[__func__] && g_log_tag_map[__func__])\
                                           {\
                                                cprintf(__VA_ARGS__);\
                                           }\
                                        else \
                                           ;\
                                      }while(0)

void* get_log_tag(void*);


#define YELLOW_PRINTF(...)         yellow_printf(__VA_ARGS__)
void yellow_printf(const char* format, ...);

#define RED_PRINTF(...)            red_printf(__VA_ARGS__)
void red_printf(const char* format, ...);

#define GREEN_PRINTF(...)          green_printf(__VA_ARGS__)
void green_printf(const char* format, ...);

#define PURPLE_PRINTF(...)         purple_printf(__VA_ARGS__)
void purple_printf(const char* format, ...);

#define BLUE_PRINTF(...)           blue_printf(__VA_ARGS__)
void blue_printf(const char* format, ...);

#define CYAN_PRINTF(...)           cyan_printf(__VA_ARGS__)
void cyan_printf(const char* format, ...);

#define YPRINTF(...)         yprintf(__VA_ARGS__)
void yprintf(const char* format, ...);

#define RPRINTF(...)         rprintf(__VA_ARGS__)
void rprintf(const char* format, ...);

#define GPRINTF(...)         gprintf(__VA_ARGS__)
void gprintf(const char* format, ...);

#define PPRINTF(...)         pprintf(__VA_ARGS__)
void pprintf(const char* format, ...);

#define BPRINTF(...)         bprintf(__VA_ARGS__)
void bprintf(const char* format, ...);

#define CPRINTF(...)         cprintf(__VA_ARGS__)
void cprintf(const char* format, ...);

void every_yellow_printf(const char* file, const int line, int interval, const char* format, ...);

#define EVERY_YELLOW_PRINTF(...) every_yellow_printf(__FILE__,  __LINE__, __VA_ARGS__)

#else

#define CYELLOW_PRINTF(...)
#define CRED_PRINTF(...)
#define CGREEN_PRINTF(...)
#define CPURPLE_PRINTF(...)
#define CBLUE_PRINTF(...)
#define CCYAN_PRINTF(...)


#define YELLOW_PRINTF(...)
#define RED_PRINTF(...)
#define GREEN_PRINTF(...)
#define PURPLE_PRINTF(...)
#define BLUE_PRINTF(...)
#define CYAN_PRINTF(...)

#define CYPRINTF(...)
#define CRPRINTF(...)
#define CGPRINTF(...)
#define CPPRINTF(...)
#define CBPRINTF(...)
#define CCPRINTF(...)


#define YPRINTF(...)
#define RPRINTF(...)
#define GPRINTF(...)
#define PPRINTF(...)
#define BPRINTF(...)
#define CPRINTF(...)

#define EVERY_YELLOW_PRINTF(...)

void ryprintf(const char* format, ...);


#endif

const std::string getCurrentSystemTime(void);

#include <string>
#include <vector>
using std::string;
using std::vector;

namespace HITACHI_PROJECT {
    
vector<string> split(const string& src, const string& delimiter);
//string& replace_all_distinct(string& str, const string& old_value, const string& new_value);

}

#include <memory>

template <typename T>  
std::shared_ptr<T> make_shared_array(size_t size)  
{   
    return std::shared_ptr<T>(new T[size], std::default_delete<T[]>());  
}

const string getLocalIP(const char* device);
const string getLocalMac(const char* device);

unsigned long get_timepoint(void);

// true play
// false discard
bool check_play_or_sleep_discard(long ts,  long timeSpan, long deltaSpan, bool video);

#ifndef NDEBUG

//#define CAPTURE_PACKET

#ifdef CAPTURE_PACKET

#include "capture.h"

#endif

#endif

#undef DUMP_VIDEO_TEST

#ifndef NDEBUG
#define DUMP_VIDEO_TEST
#endif

#ifdef DUMP_VIDEO_TEST

#include <fstream>
using std::ofstream;
using std::ios_base;
using std::to_string;

#endif

#endif

