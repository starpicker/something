/*----------------------------------------------------------------------------------------------
*
* This file is ArcSoft's property. It contains ArcSoft's trade secret, proprietary and
* confidential information.
*
* The information and code contained in this file is only for authorized ArcSoft employees
* to design, create, modify, or review.
*
* DO NOT DISTRIBUTE, DO NOT DUPLICATE OR TRANSMIT IN ANY FORM WITHOUT PROPER AUTHORIZATION.
*
* If you are not an intended recipient of this file, you must not copy, distribute, modify,
* or take any action in reliance on it.
*
* If you have received this file in error, please immediately notify ArcSoft and
* permanently delete the original and any copy of any file and any printout thereof.
*
*---------------------------------------------------------------------------------------------*/


#include "def.h"

#include <chrono>

#include <stdio.h>
#include <stdarg.h>
#include <unistd.h>
#include <string.h>
#include <stdlib.h>
#include <sys/time.h>
#include <sys/prctl.h>

#ifndef NDEBUG

static FILE *fp = NULL;
void initLogger()
{
    char * path = NULL;
    path = getenv("ADMR_LOGPATH");
    if(path)
    {
        remove(path);

        if(!fp)
        {
            fp = fopen(path, "a");
        }
    }
    else
    {
        fp = NULL;
    }
}

void logToFile(const char * fmt, ...)
{
    if(fp)
    {
        va_list arg;
        char buf[1024 * 4] = {0};
        va_start(arg, fmt);
        vsprintf(buf, fmt,arg);
        va_end(arg);
        fwrite(buf,1,strlen(buf),fp);
        if(buf[strlen(buf)-1] != '\n')
            fwrite("\n",1,1,fp);
        fflush(fp);
    }
}

void uninitLogger()
{
    if(fp)
    {
        fclose(fp);
        fp = NULL;
    }
}

#else

#endif

const std::string getCurrentSystemTime(void)
{
  auto tt = std::chrono::system_clock::to_time_t
  (std::chrono::system_clock::now());
  struct tm* ptm = localtime(&tt);
  struct timeval t;
  gettimeofday(&t, 0);
  char date[60] = {0};
  sprintf(date, "%d-%02d-%02d %02d:%02d:%02d:%02d",
    (int)ptm->tm_year + 1900,(int)ptm->tm_mon + 1,(int)ptm->tm_mday,
    (int)ptm->tm_hour,(int)ptm->tm_min,(int)ptm->tm_sec,(int)(t.tv_usec/1000));
  
  return std::string(date);
}

namespace HITACHI_PROJECT {

int comp(const void* a, const void* b)
{
    return *(int*)a-*(int*)b;
}

// for name end has \ or \\\\\ like this case
bool check_back_slash_ending(const string& src, string::size_type start, string::size_type end)
{
    int countOfBackSlash = 0;
    for(string::size_type s = end; s >= start; --s)
    {
        if(src[s] == '\\')
        {
            ++countOfBackSlash;
        }
        else
        {
            break;
        }
    }

    return !(countOfBackSlash%2);
}

vector<string> split(const string& src, const string& delimiter)
{
    int maxSubstrNum = src.size();
    int* pos = new int[maxSubstrNum];
    memset(pos, 0, maxSubstrNum*sizeof(int));

    int j = 0;
    for(size_t i = 0; i < delimiter.size(); ++i)
    {
        string::size_type index = src.find(delimiter[i]);
        while(index != string::npos)
        {
            if(check_back_slash_ending(src, pos[j], index-1))
                pos[j++] = index;
            index = src.find(delimiter[i], index+1);
        }       
    }

    // means no delimiter
    if(j == 0)
    {
        // fix leak detected by sonar
        delete[] pos;
        return vector<string>{src};
    }
    
    qsort(pos, j, sizeof(int), comp);

    vector<string> strRes;
    string substrFir = src.substr(0, pos[0]);
    
    // passwd sometimes is ""
    //if(substrFir != "")
    strRes.push_back(substrFir);

    for(int i = 0; i < j-1; ++i)
    {
        string substr = src.substr(pos[i]+1, pos[i+1]-pos[i]-1);
        //if(substr != "")
        strRes.push_back(substr);
    }

    string substrLast = src.substr(pos[j-1]+1, src.size()-pos[j-1]-1);
    //if(substrLast != "")
    strRes.push_back(substrLast);   
    delete[] pos;
    
    return strRes;
}

/*
string& replace_all(string& str, const string& old_value, const string& new_value)
{
    while(true)
    {
        string::size_type pos(0);
        if((pos=str.find(old_value)) != string::npos)
            str.replace(pos, old_value.length(), new_value);
        else
            break;   
    }
    
    return str;
}
string& replace_all_distinct(string& str, const string& old_value, const string& new_value)
{   
    for(string::size_type pos(0); pos!=string::npos; pos += new_value.length()) 
    {
        if((pos = str.find(old_value, pos)) !=string::npos)
            str.replace(pos, old_value.length(), new_value);
        else
            break;
    }
    
    return str;
}
*/

}

unsigned long get_timepoint(void)
{
    struct timeval t;
    gettimeofday(&t, NULL);

    return (t.tv_sec*1000+t.tv_usec/1000);
}




#ifdef NDEBUG

#define print_none         printf("\033[0m\n");fflush(stdout);
#define print_red          printf("\033[1;31;40m");
#define print_green        printf("\033[1;32;40m");
#define print_yellow       printf("\033[1;33;40m");

void ryprintf(const char* format, ...)
{

    va_list args;
    va_start(args, format);
    print_yellow
    vprintf(format, args);
    print_none
    va_end(args);
}

#else

#ifndef STDIN_LOG

#include <stdio.h>//printf
#include <string.h> //strcmp
#include <sys/inotify.h>//inotify_init inotify_add_watch....
#include <sys/select.h>//select timeval
#include <unistd.h>//close
#include <sys/stat.h>

#define EVENT_SIZE  ( sizeof (struct inotify_event) )
#define BUF_LEN     ( 1024 * ( EVENT_SIZE + 16 ) )
#define ERR_EXIT(msg,flag)  {perror(msg);goto flag;}

int delete_dir(const char* dirname);

#endif

map<string, bool> g_log_tag_map;
mutex g_log_mutex;

void* get_log_tag(void*)
{
    prctl(PR_SET_NAME, "get_log_tag");

#ifdef STDIN_LOG
    while(true)
    {
        string tag;
        getline(cin, tag); 

        RED_PRINTF("tag is :%s\n", tag.c_str());

        if(tag.size() >= 4)
        {
            if(g_log_tag_map[tag])
                g_log_tag_map.erase(tag);
            else
                g_log_tag_map[tag] = true;
        }
    }
#else
    {
        
#define LOG_CONTROL_DIR "/tmp/dmr_sink_log/"

        delete_dir(LOG_CONTROL_DIR);
        mkdir(LOG_CONTROL_DIR, S_IRWXU);
    
        //-Wunused-variable
        //int length, i = 0;
        int length;
        int fd;
        int wd;
        char buffer[BUF_LEN];

        if((fd = inotify_init()) < 0)
            ERR_EXIT("inotify_init", inotify_init_err);
        
        if((wd = inotify_add_watch(fd, LOG_CONTROL_DIR, IN_MODIFY | IN_CREATE | IN_DELETE )) < 0)
            ERR_EXIT("inofity_add_watch", inotify_add_watch_err);
        
        fd_set rfd;
        struct timeval tv;

        while(true)
        {
            int retval;
            FD_ZERO(&rfd);
            FD_SET(fd, &rfd);
            
            /*
                On Linux, select() modifies timeout to reflect the amount of  time  not
                slept;  most  other  implementations  do not do this.  (POSIX.1 permits
                either behavior.)  This causes problems  both  when  Linux  code  which
                reads  timeout  is  ported to other operating systems, and when code is
                ported to Linux that reuses a struct timeval for multiple select()s  in
                a  loop  without  reinitializing  it.  Consider timeout to be undefined
                after select() returns.

                If not reset timeval, cause [sched_delayed] sched: RT throttling activated issue occurs
            */
            
            tv.tv_sec = 1;
            tv.tv_usec = 0;
            retval = select(fd + 1, &rfd, NULL, NULL, &tv);
            if(retval == 0) continue;
            else if(retval == -1)
                ERR_EXIT("select", select_err);

            // retval > 0
            length = read(fd, buffer, BUF_LEN);  
            if(length < 0)
                ERR_EXIT("read", read_err);

            //length >= 0
            int i = 0;
            while(i < length) 
            {
                struct inotify_event* event = (struct inotify_event*)&buffer[i];
                if(event->len) 
                {
                    if(event->mask & IN_CREATE) 
                    {
                        string tag(event->name);
                        g_log_tag_map[tag] = true;

                    }
                    else if(event->mask & IN_DELETE) 
                    {
                        string tag(event->name);
                        g_log_tag_map[tag] = false;
                    }
                    else if(event->mask & IN_MODIFY) 
                    {
                    }
                }else
                {
                }
                
                i += EVENT_SIZE + event->len;
            }
        }
    //-Wunused-label
//success_exit:
        (void)inotify_rm_watch(fd, wd);
        (void)close(fd);
        return 0;

read_err:
select_err:
inotify_add_watch_err:
        (void)inotify_rm_watch(fd, wd);
        (void)close(fd);
inotify_init_err:
        ;
    }

#endif

    return 0;
}

#include <thread>

bool logon = true;

// no use, use link+ name instead, sign
/*
__attribute__((constructor)) void disable_icsapp_stdin(void)
{
   RED_PRINTF("disable_icsapp_stdin");
   
   int fd = dup(0);
   close(0);

   std::thread t([=]
                 {
                    dup2(fd, 0);
                    char ch;
                    while(ch = cin.get() != EOF)
                    {
                        if(ch == 'l')
                        {
                            log_on = true;
                            GREEN_PRINTF("log is on");
                        }
                        else if(ch == 'L')
                        {
                            GREEN_PRINTF("log is off");
                            log_on = false;
                        }
                        else
                        {
                            continue;
                        }

                    }
                }
               );
   
   t.detach();
}
*/

#define PRINT_NONE         printf("\033[0m\n\n\n");fflush(stdout);
#define PRINT_RED          printf("\n\n\n\033[1;31;40m");
#define PRINT_GREEN        printf("\n\n\n\033[1;32;40m");
#define PRINT_YELLOW       printf("\n\n\n\033[1;33;40m");
#define PRINT_BLUE         printf("\n\n\n\033[1;34;40m");
#define PRINT_PURPLE       printf("\n\n\n\033[1;35;40m");
#define PRINT_CYAN         printf("\n\n\n\033[1;36;40m");

#define print_none         printf("\033[0m");fflush(stdout);
#define print_red          printf("\033[1;31;40m");
#define print_green        printf("\033[1;32;40m");
#define print_yellow       printf("\033[1;33;40m");
#define print_blue         printf("\033[1;34;40m");
#define print_purple       printf("\033[1;35;40m");
#define print_cyan         printf("\033[1;36;40m");


void yellow_printf(const char* format, ...)
{
    if(logon == false)return;
    
    va_list args;
    va_start(args, format);
    PRINT_YELLOW
    vprintf(format, args);
    PRINT_NONE
    va_end(args);
}

void red_printf(const char* format, ...)
{
    if(logon == false)return;

    va_list args;
    va_start(args, format);
    PRINT_RED
    vprintf(format, args);
    PRINT_NONE
    va_end(args);
}

void green_printf(const char* format, ...)
{
    if(logon == false)return;

    va_list args;
    va_start(args, format);
    PRINT_GREEN
    vprintf(format, args);
    PRINT_NONE
    va_end(args);
}

void purple_printf(const char* format, ...)
{
    if(logon == false)return;

    va_list args;
    va_start(args, format);
    PRINT_PURPLE
    vprintf(format, args);
    PRINT_NONE
    va_end(args);
}

void blue_printf(const char* format, ...)
{
    if(logon == false)return;

    va_list args;
    va_start(args, format);
    PRINT_BLUE
    vprintf(format, args);
    PRINT_NONE
    va_end(args);
}

void cyan_printf(const char* format, ...)
{
    if(logon == false)return;

    va_list args;
    va_start(args, format);
    PRINT_CYAN
    vprintf(format, args);
    PRINT_NONE
    va_end(args);
}

void yprintf(const char* format, ...)
{
    if(logon == false)return;

    va_list args;
    va_start(args, format);
    print_yellow
    vprintf(format, args);
    print_none
    va_end(args);
}

void rprintf(const char* format, ...)
{
    if(logon == false)return;

    va_list args;
    va_start(args, format);
    print_red
    vprintf(format, args);
    print_none
    va_end(args);
}

void gprintf(const char* format, ...)
{
    if(logon == false)return;

    va_list args;
    va_start(args, format);
    print_green
    vprintf(format, args);
    print_none
    va_end(args);
}

void pprintf(const char* format, ...)
{
    if(logon == false)return;

    va_list args;
    va_start(args, format);
    print_purple
    vprintf(format, args);
    print_none
    va_end(args);
}

void bprintf(const char* format, ...)
{
    if(logon == false)return;

    va_list args;
    va_start(args, format);
    print_blue
    vprintf(format, args);
    print_none
    va_end(args);
}

void cprintf(const char* format, ...)
{
    if(logon == false)return;

    va_list args;
    va_start(args, format);
    print_cyan
    vprintf(format, args);
    print_none
    va_end(args);
}

void every_yellow_printf(const char* file, const int line, int interval, const char* format, ...)
{
    static map<string, int> m;

    struct timeval tv_current;
    gettimeofday(&tv_current, NULL);

    const string key = string(file) + to_string(line);
    if(m.find(key) != m.end() && m[key] + interval > tv_current.tv_sec)
    {
        return;
    }

    if(m.find(key) != m.end())
    {
        va_list args;
        va_start(args, format);
        PRINT_YELLOW
        vprintf(format, args);
        PRINT_NONE
        va_end(args);
    }
    
    m[key] = tv_current.tv_sec;
}

#include <sys/socket.h>
#include <sys/ioctl.h>
#include <net/if.h>
#include <stdio.h>
#include <netinet/in.h>
#include <arpa/inet.h>

const string getLocalIP(const char* device)
{
    int sock_get_ip;
    char ipaddr[50];

    struct sockaddr_in* sin;
    struct ifreq ifr_ip;

    if((sock_get_ip = socket(AF_INET, SOCK_STREAM, 0)) == -1)
    {
        return "";
    }

    memset(&ifr_ip, 0, sizeof(ifr_ip));     
    strncpy(ifr_ip.ifr_name, device, sizeof(ifr_ip.ifr_name) - 1);
   
    if(ioctl(sock_get_ip, SIOCGIFADDR, &ifr_ip) < 0)
    {    
        close(sock_get_ip);
        return "";
    }
    sin = (struct sockaddr_in*)&ifr_ip.ifr_addr;
    strcpy(ipaddr, inet_ntoa(sin->sin_addr));

    close(sock_get_ip);

    return ipaddr;
}

const string getLocalMac(const char* device)
{
    int sock_mac;
    struct ifreq ifr_mac;
    char mac_addr[30];
    sock_mac = socket(AF_INET, SOCK_STREAM, 0);
    if(sock_mac == -1)
    {
        return "";
    }

    memset(&ifr_mac, 0, sizeof(ifr_mac));
    strncpy(ifr_mac.ifr_name, device, sizeof(ifr_mac.ifr_name) - 1);

    if(ioctl(sock_mac, SIOCGIFHWADDR, &ifr_mac) < 0)
    {
        close(sock_mac);
        return "";
    }

    sprintf(mac_addr, "%02x%02x%02x%02x%02x%02x",
        (unsigned char)ifr_mac.ifr_hwaddr.sa_data[0],
        (unsigned char)ifr_mac.ifr_hwaddr.sa_data[1],
        (unsigned char)ifr_mac.ifr_hwaddr.sa_data[2],
        (unsigned char)ifr_mac.ifr_hwaddr.sa_data[3],
        (unsigned char)ifr_mac.ifr_hwaddr.sa_data[4],
        (unsigned char)ifr_mac.ifr_hwaddr.sa_data[5]
    );

    close(sock_mac);

    return mac_addr;
}

#endif
